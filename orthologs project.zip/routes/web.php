<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



// Superadmin part ends
// Hospital start
Route::get('/', 'UnitadminController@properredirect');
Route::get('/scoliosis', 'UnitadminController@dashboard')->name('scoliodash');
Route::post('/scoliosis/dashboardfilter', 'UnitadminController@dashboardfilter');
Route::get('/scoliosis/patients', 'UnitadminController@patientrecords')->name('scoliosispatients');
Route::get('/scoliosis/patient/new', 'UnitadminController@newpatient');
Route::post('/newpatient', 'UnitadminController@addpatient');
Route::post('/deletepatientrecord', 'UnitadminController@deletepatientrecord');
Route::post('/checkuniqueuhid', 'UnitadminController@checkuniqueuhid');
// Route::get('/scoliosis/proforma/new/{id}', 'UnitadminController@newproforma');
Route::get('/proforma/new/{stage}/{id}', 'UnitadminController@newproforma');
Route::post('/newproforma', 'UnitadminController@addproforma');
Route::get('/proforma/edit/{stage}/{id}', 'UnitadminController@editproforma');
Route::post('/editproforma', 'UnitadminController@updateproforma');
// Route::get('/scoliosis/proforma/new/{id}', 'UnitadminController@newproforma');
// Route::get('/scoliosis/questionnaire/new/{id}', 'UnitadminController@newquestionnaire');
Route::get('/srs22/new/{stage}/{id}', 'UnitadminController@newsrs');
Route::get('/srs22/edit/{stage}/{id}', 'UnitadminController@editsrs');
Route::post('/newsrs22', 'UnitadminController@addsrs');
// Route::post('/editsrs22', 'UnitadminController@updatesrs');
Route::get('/scoliosis/proforma/edit/{id}', 'UnitadminController@editproforma');
Route::get('/scoliosis/patient/{id}', 'UnitadminController@viewrecord');

Route::post('/deleteorthorecord', 'OrthoLogController@deleteorthorecord');
Route::get("/ortho", "OrthoLogController@dashboard")->name('orthodash');
Route::post('/ortho/dashboardfilter', 'OrthoLogController@dashboardfilter');

Route::get('/ortho/ortholog/', 'OrthoLogController@index')->name('logindex');
Route::post('/ortho/getfilteredlog/', 'OrthoLogController@getfilteredlog');
Route::get('/ortho/ortholog/new', 'OrthoLogController@newortholog');
Route::post('/ortho/ortholog/store', 'OrthoLogController@storeortholog');
Route::get('/ortho/ortholog/{id}/view', 'OrthoLogController@orthologprofile');
Route::get('/ortho/ortholog/{id}/edit', 'OrthoLogController@orthologedit');
Route::patch('/ortho/ortholog/{id}/update', 'OrthoLogController@updateortholog');

// 
Route::get('/users', 'SuperadminController@index')->name('users');
Route::get('/user/new', 'SuperadminController@newuser');
Route::get('/user/{id}/view', 'SuperadminController@edituser');
Route::post('/user/{id}/edit', 'SuperadminController@updateuser');
Route::post('/user/new', 'SuperadminController@createuser');
Route::post('/deleteusers', 'SuperadminController@deleteusers');


// Hospital end
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
