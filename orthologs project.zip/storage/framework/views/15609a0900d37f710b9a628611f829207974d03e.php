<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="foreachtr">
    <td>
        <?php if($patient->ortholog!=1): ?>
            <div class="custom-control custom-checkbox">
            <input type="checkbox"  name='ids[]' class="idcheckbox custom-control-input idcheckbox" id="customCheck<?php echo e($patient->id); ?>" value="<?php echo e($patient->id); ?>" name='ids[]'>
            <label class="custom-control-label" for="customCheck<?php echo e($patient->id); ?>">&nbsp;</label>
            </div>
        <?php endif; ?>
    </td>
    <td><a href="/scoliosis/patient/<?php echo e($patient->id); ?>"><?php echo e($patient->name); ?></a></td>
    <td><?php echo e($patient->age); ?></td>
    <td><?php echo e($patient->sex); ?></td>
    <td><a href="/scoliosis/patient/<?php echo e($patient->id); ?>"><?php echo e($patient->uhid); ?></a></td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <!-- <td>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-check-circle text-success"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="far fa-circle"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="far fa-circle"></i><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="far fa-circle"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-circle text-muted"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-circle text-muted"></i>
    </td> -->
    <?php for($i=1; $i< 5 ;$i++): ?>
        <td>
            <?php if($patient->srsExist($i)): ?>
                <a href="/srs22/edit/<?php echo e($i); ?>/<?php echo e($patient->id); ?>"><i class="fas fa-check-circle text-success"></i></a><br>
            <?php else: ?>
                <?php if($i>1): ?>
                    <?php if($patient->srsExist($i-1)): ?>
                        <a href="/srs22/new/<?php echo e($i); ?>/<?php echo e($patient->id); ?>"><i class="far fa-circle "></i></a><br>
                    <?php else: ?>
                        <i class="far fa-circle"></i><br>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="/srs22/new/<?php echo e($i); ?>/<?php echo e($patient->id); ?>"><i class="far fa-circle "></i></a><br>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($patient->proformaExist($i)): ?>
                <a href="/proforma/edit/<?php echo e($i); ?>/<?php echo e($patient->id); ?>"><i class="fas fa-check-circle text-success"></i></a>
            <?php else: ?>
                <a href="/proforma/new/<?php echo e($i); ?>/<?php echo e($patient->id); ?>"><i class="far fa-circle"></i></a>
            <?php endif; ?>
        </td>
    <?php endfor; ?>
    <!-- <td>
        <a href="/srs22/edit/1/<?php echo e($patient->id); ?>"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/proforma/edit/1/<?php echo e($patient->id); ?>"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/srs22/edit/2/<?php echo e($patient->id); ?>"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/proforma/new/2/<?php echo e($patient->id); ?>"><i class="far fa-circle"></i></a>
    </td>
    <td>    
        <a href="srs22/edit/3/<?php echo e($patient->id); ?>"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/proforma/new/3/<?php echo e($patient->id); ?>"><i class="far fa-circle"></i></a>
    </td>
    <td>    
        <a href="/srs22/new/4/<?php echo e($patient->id); ?>"><i class="far fa-circle "></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td> -->
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- <tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Amit Jain</a></td>
    <td>25-05-1987</td>
    <td>Male</td>
    <td>102547859</td>
    <td>12th Feb, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle "></i></a>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Ajit Singh</a></td>
    <td>25-05-1977</td>
    <td>Male</td>
    <td>102547852</td>
    <td>14th Mar, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>
    <td>
    <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Rinki kapoor</a></td>
    <td>25-05-1995</td>
    <td>Female</td>
    <td>103265987</td>
    <td>29th Mar, 2019<br><span class="badge badge-danger">Overdue</span></td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
    <td>
        <i class="far fa-circle"></i><br>
        <i class="far fa-circle"></i>
    </td>
    <td>
        <i class="far fa-circle"></i><br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Indira sharma</a></td>
    <td>18-05-1965</td>
    <td>Female</td>
    <td>106554878</td>
    <td>5th Apr, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Rishi Jain</a></td>
    <td>25-05-1966</td>
    <td>Male</td>
    <td>102547859</td>
    <td>16th Jun, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle "></i></a>
        <br>
        <i class="far fa-circle "></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Vinod Pal</a></td>
    <td>25-05-1954</td>
    <td>Male</td>
    <td>102356897</td>
    <td>16th Jun, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle "></i></a>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Kripa Sharma</a></td>
    <td>25-05-1992</td>
    <td>Female</td>
    <td>102509750</td>
    <td>2nd Jul, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Rinki Manchanda</a></td>
    <td>25-07-1977</td>
    <td>Female</td>
    <td>102509734</td>
    <td>30th Dec, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
    <td>
        <i class="far fa-circle"></i><br>
        <i class="far fa-circle"></i>
    </td>
    <td>
        <i class="far fa-circle"></i><br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Kriti Goel</a></td>
    <td>02-07-1993</td>
    <td>Female</td>
    <td>106789750</td>
    <td>5th Dec, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
</tr> --><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/patientrecord/list.blade.php ENDPATH**/ ?>