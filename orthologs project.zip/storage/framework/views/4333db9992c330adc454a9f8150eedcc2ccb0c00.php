<div class="cf-container" id="cf-container">
    <br>
    <table class="table table-bordered table-striped reportform formtable">

        <tr>
            <td>Name<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="name" id="name"
                            value="<?php echo e($log->patientdetail->name); ?>" placeholder="Name" autocomplete="off" required="required">
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOB</td>
            <td>
                <div class="input-group mb-3 mr-4">
                    <select class="form-control" name="dob_date" id="dob_date">
                        <option value="">DD</option>
                        <?php for($i=1; $i <= 31; $i++): ?> 
                            <option <?php echo e(!is_null($log->patientdetail->dob)?($log->patientdetail->dob->format('d')==$i?'selected':null):null); ?>><?php echo e(sprintf('%02d', $i)); ?></option>
                        <?php endfor; ?>
                    </select>
                    <select class="form-control" name="dob_month" id="dob_month">
                        <option value="">MM</option>
                        <?php for($i=1; $i <= 12; $i++): ?> 
                            <option <?php echo e(!is_null($log->patientdetail->dob)?($log->patientdetail->dob->format('m')==$i?'selected':null):null); ?>><?php echo e(sprintf('%02d', $i)); ?></option>
                        <?php endfor; ?>
                    </select>
                    <select class="form-control" name="dob_year" id="dob_year">
                        <option value="">YYYY</option>
                        <?php for($i=date('Y'); $i > date('Y', strtotime(date('Y').'- 100 years')); $i--): ?>
                            <option <?php echo e(!is_null($log->patientdetail->dob)?($log->patientdetail->dob->format('Y')==$i?'selected':null):null); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Age<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input type="number" min="0" class="form-control" name="age" id="age"
                            value="<?php echo e($log->patientdetail->age); ?>" placeholder="Age" autocomplete="off" required="required">
                    <div class="input-group-append">
                        <span class="input-group-text">year(s)</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td>Sex<span class="text-danger">*</span></td>
            <td>
                <select class="form-control" name="sex" required="required">
                    <option value="">Select sex</option>
                    <option value="Male" <?php echo e($log->patientdetail->sex=='Male'?'SELECTED':null); ?>>Male</option>
                    <option value="Female" <?php echo e($log->patientdetail->sex=='Female'?'SELECTED':null); ?>>Female</option>
                    <option value="Others" <?php echo e($log->patientdetail->sex=='Other'?'SELECTED':null); ?>>Other</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>UHID<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input readonly type="text" class="form-control" name="uhid" id="uhid" value="<?php echo e($log->patientdetail->uhid); ?>" placeholder="UHID" autocomplete="off" required="required">
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Phone no<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="phone_no" id="phone_no" value="<?php echo e($log->patientdetail->phone); ?>" placeholder="Phone no" autocomplete="off" required="required">
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Address</td>
            <td>
                <div class="input-group mb-3">
                    <textarea class="form-control" name="address" id="address" placeholder="Address" autocomplete="off"><?php echo e($log->patientdetail->address); ?></textarea>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Email Id</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="emailid" id="emailid" value="<?php echo e($log->patientdetail->email); ?>" placeholder="Email Id" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Occupation (Parent’s occupation in case of minor)</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="occupation" id="occupation" value="<?php echo e($log->patientdetail->occupation); ?>" placeholder="Occupation" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Bed no</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="bed_no" id="bed_no"
                            value="<?php echo e($log->patientdetail->bed_no); ?>" placeholder="Bed no" autocomplete="off">
                </div>
            </td>
        </tr>

        <tr>
            <td>Operative details</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="operative_details" id="operative_details" value="<?php echo e($log->operative_details); ?>" placeholder="Operative details" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Diagnosis</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="diagnosis" id="diagnosis" value="<?php echo e($log->diagnosis); ?>" placeholder="Diagnosis" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Level</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="level" id="level" value="<?php echo e($log->level); ?>" placeholder="Level" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Treatment / Op procedure</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="treatment_procedure" id="treatment_procedure" value="<?php echo e($log->treatment_procedure); ?>" placeholder="Treatment / Op procedure" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Comorbidities</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="comorbidities" id="comorbidities" value="<?php echo e($log->comorbidities); ?>" placeholder="Comorbidities" autocomplete="off">
                </div>
            </td>
        </tr>

        <tr>
            <td class="firstcol">Surgeons</td>
            <td>
                <?php $__currentLoopData = orthologsurgeons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surgeon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox custom-control-inline mb-3">
                        <input type="checkbox" class="custom-control-input" id="specific_event_<?php echo e($surgeon); ?>" value='<?php echo e($surgeon); ?>' name='surgeons[]' <?php echo e(in_array($surgeon, explode(',',substr($log->surgeons, 1, -1)))?'checked':null); ?>>
                        <label class="custom-control-label" for="specific_event_<?php echo e($surgeon); ?>"> <?php echo e($surgeon); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
        <tr>
            <td>Implant</td>
            <td>
                <div class="input-group mb-3">
                    <textarea class="form-control" name="implant" id="implant" placeholder="Implant" autocomplete="off"><?php echo e($log->implant); ?></textarea>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Surgical duration</td>
            <td>
                <div class="input-group mb-3">
                    <input type="number" min="0" class="form-control" name="surgical_time" id="surgical_time"
                            value="<?php echo e($log->surgical_time); ?>" placeholder="Surgical time" autocomplete="off">
                    <div class="input-group-append">
                        <span class="input-group-text">minute(s)</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Blood loss</td>
            <td>
                <div class="input-group mb-3">
                    <input type="number" min="0" class="form-control" name="blood_loss" id="blood_loss"
                            value="<?php echo e($log->blood_loss); ?>" placeholder="Blood loss" autocomplete="off">
                    <div class="input-group-append">
                        <span class="input-group-text">ml</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOA </td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="doa" value="<?php echo e(!is_null($log->doa) ? $log->doa->format('d-m-Y'):null); ?>" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="doa"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOO</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="doo" value="<?php echo e(!is_null($log->doo) ? $log->doo->format('d-m-Y'):null); ?>" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="doo"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOD</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="dod" value="<?php echo e(!is_null($log->dod) ? $log->dod->format('d-m-Y'):null); ?>" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="dod"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Post op course</td>
            <td>
                <?php ($i=1); ?>
                <?php $__currentLoopData = postopcourse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postopcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="postopcourse<?php echo e($i); ?>" value='<?php echo e($postopcourse); ?>' name='postopcourses[]' <?php echo e(in_array($postopcourse, explode(',',substr($log->postopcourses, 1, -1)))?'checked':null); ?>>
                        <label class="custom-control-label" for="postopcourse<?php echo e($i); ?>"> <?php echo e($postopcourse); ?></label>
                    </div>
                    <?php ($i++); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="postopcoursesother" value='Other' name='postopcourses[]' <?php echo e(in_array("Other", explode(',',substr($log->postopcourses, 1, -1)))?'checked':null); ?>>
                    <label class="custom-control-label" for="postopcoursesother"> Other</label>
                </div>
                <input type="text" class="form-control" name="postopcourses_other" value="<?php echo e($log->postopcourses_other); ?>">
            </td>
        </tr>

    </table>
</div><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/ortholog/logs/cf/edit.blade.php ENDPATH**/ ?>