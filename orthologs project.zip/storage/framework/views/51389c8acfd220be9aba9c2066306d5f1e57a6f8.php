<?php $__env->startSection('fixedheadercontent'); ?>

<div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
        <h1 class="h2">Patient Record</h1>
    </div>

    <div class="form-inline">
        <div class="btn-group btn-group-sm" role="group">
            <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('headercontent'); ?>
<div class="px-3 py-3">
    <table>
        <tr>
            <td><b>Name</b></td>
            <td><?php echo e($patient->name); ?></td>
        </tr>
        <tr>
            <td><b>Age</b></td>
            <td><?php echo e($patient->age); ?></td>
        </tr>
        <tr>
            <td><b>Sex</b></td>
            <td><?php echo e($patient->sex); ?></td>
        </tr>
        <tr>
            <td><b>UHID</b></td>
            <td><?php echo e($patient->uhid); ?></td>
        </tr>
        <tr>
            <td><b>Diagnosis</b></td>
            <td><?php echo e($patient->diagnosis); ?></td>
        </tr>
        <tr>
            <td><b>Last updated performa</b></td>
            <td><?php echo e($patient->allPerforma->count()>0?$patient->lastUpdated()->format("d-m-Y"):"Not Available"); ?></td>
        </tr>
        <!-- <tr>
            <td colspan=2>
                <h5><span class="badge badge-success thumbsupbadge">
                 Improved</span></h5>
            </td>
        </tr> -->
    </table><br>
    <h2>Proforma</h2>
    <table class="table table-hover table-bordered table-export">
        <thead>
            <tr class="active">
                <th></th>
                <th>Preoperative</th>
                <th>Post operative</th>
                <th>Postop F/U 1st visit – 1 month</th>
                <th>Postop F/U 2nd visit – 6 months</th>
            </tr>
        </thead>
        <tbody class="tbodycontainer">
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">Clinical</td>
            </tr>
            <tr class="active">
                <td>Date of proforma</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaDate($i)?$patient->proformaDate($i)->date->format('d-m-Y'):null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Scoliosis Type</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->scoliosis_type:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Skin</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->skin:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Shoulder level difference</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->shoulder_level_difference:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Rib Hump</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->rib_hump:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Arm span</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->arm_span.' cm':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Sitting height</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->sitting_height.' cm':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Limb length R/L</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->limb_length.' cm':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">Neurological status</td>
            </tr>
            <tr class="active">
                <td>Motor/DTR</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->motor_dtr:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Sensory</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->sensory:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Autonomic</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->autonomic:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">SRS Functional score</td>
            </tr>
            <tr class="active">
                <td>Function</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->functional_score.'/5':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Self image</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->self_image.'/5':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Mental health</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->mental_health.'/5':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Pain</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->pain.'/5':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Satisfaction/dissatisfaction with management</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->satisfaction_with_management.'/5':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr >
                <td colspan="5" class="text-white bg-dark"></td>
            </tr>
            <tr>
                <td>Associated anomalies</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->associated_anomalies:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">Radiological</td>
            </tr>
            <tr class="active">
                <td>Lenke classification(AIS)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->lenke_classification:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Winters classification type</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td>
                    <?php if($patient->proformaExist($i)): ?>
                        <?php echo e($patient->performa($i)->winters_classification); ?>

                        <?php if($patient->performa($i)->winters_classification=="Failure formation"): ?>
                        <br>
                        Failure formation: <?php echo e($patient->performa($i)->failure_formation); ?>

                        <?php endif; ?>
                        <?php if($patient->performa($i)->winters_classification=="Failure of segmentation"): ?>
                        <br>
                        Failure of segmentation: <?php echo e($patient->performa($i)->failure_of_segmentation); ?>

                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">Primary curve</td>
            </tr>
            <tr class="active">
                <td>APEX</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->apex:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Apical vertical translation(AVT)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->apical_vertical_translation.' mm':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Apical rotation (NASH & MOE)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->apical_rotation:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Upper end vertebra / Lower end vertebra</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->upper_lower_end_vertebra:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Cobb's angle</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->cobb_angle.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Bending cobb's</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->bending_cobb.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">Secondary curve</td>
            </tr>
            <tr class="active">
                <td>APEX</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->secondary_apex:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Apical vertical translation(AVT)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->secondary_apical_vertical_translation.' mm':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Apical rotation (NASH & MOE)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->secondary_apical_rotation:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Upper end vertebra / Lower end vertebra</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->secondary_upper_lower_end_vertebra:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Cobb's angle</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->secondary_cobb_angle.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Bending cobb's</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->secondary_bending_cobb.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark"></td>
            </tr>
            <tr class="active">
                <td>Coronal shift/trunk shift</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->trunk_shift.' mm':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Thoracic kyphosis(T4-T12)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->thoracic_kyphosis.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Lumbar lordosis(L1-L5)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->lumbar_lordosis.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Sagittal shift (SVA)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->sagittal_shift.' mm':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Pelvic tilt(PT)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->pelvic_tilt.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Pelvic incidence(PI)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->pelvic_incidence.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Sacral slope(SS)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->sacral_slope.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Radiographic shoulder Height</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->radiographic_shoulder_height.' mm':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Pelvic Sagittal Axis(PSA)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->psa.' degree':null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Post operative findings</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->post_operative_findings:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">CT findings</td>
            </tr>
            <tr class="active">
                <td>Screw loosening/breakage</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->screw_loosening_breakage:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">MRI findings</td>
            </tr>
            <tr class="active">
                <td>Findings</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->mri_findings:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td>Other</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->mri_findings_other:null); ?></td>
                <?php endfor; ?>
            </tr>
            <tr class="active">
                <td colspan="5" class="text-white bg-dark">CT findings</td>
            </tr>
            <tr class="active">
                <td>Neurosurgical procedure (if any)</td>
                <?php for($i=1;$i <= 4; $i++): ?>
                <td><?php echo e($patient->proformaExist($i)?$patient->performa($i)->neurosurgical_procedure:null); ?></td>
                <?php endfor; ?>
            </tr>
        </tbody>
    </table>
</div>
<div class="mr-3 ml-3">
    <div class="row">
        <div class="col-sm">
            <div class="card">
                <div class="card-body">
                    <p class="card-text">
                        <span class="cardhead">Preoperative</span>
                        <br>
                        <span class="text-muted">functional score mean</span>
                    </p>
                    <h1 class="card-title"><b><?php echo e($patient->countFunctionalMeanDirect(1)); ?>/5</b></h1>
                </div>
            </div>
        </div>

        <div class="col-sm">
            <div class="card">
                <div class="card-body">
                    <p class="card-text">
                        <span class="cardhead">Postoperative</span>
                        <br>
                        <span class="text-muted">functional score mean</span>
                    </p>
                    <h1 class="card-title"><b><?php echo e($patient->countFunctionalMeanDirect(2)); ?>/5</b></h1>
                </div>
            </div>
        </div>

        <div class="col-sm">
            <div class="card">
                <div class="card-body">
                    <p class="card-text">
                        <span class="cardhead">Postop F/U 1</span>
                        <br>
                        <span class="text-muted">functional score mean</span>
                    </p>
                    <h1 class="card-title"><b><?php echo e($patient->countFunctionalMeanDirect(3)); ?>/5</b></h1>
                </div>
            </div>
        </div>

        <div class="col-sm">
            <div class="card">
                <div class="card-body">
                    <p class="card-text">
                        <span class="cardhead">Postop F/U 2</span>
                        <br>
                        <span class="text-muted">functional score mean</span>
                    </p>
                    <h1 class="card-title"><b><?php echo e($patient->countFunctionalMeanDirect(4)); ?>/5</b></h1>
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="row mt-3">

        <div class="col-6">
            <div class="card">
                <div class="card-body">
                    <p class="card-text">

                        <table class="table">
                            <tr>
                                <th>Domain (Postop F/U2)</th>
                                <th>Avg score</th>
                                <th>Standard devidation</th>
                                <th>Max</th>
                                <th>Min</th>
                            </tr>

                            <tr>
                                <td>Function</td>
                                <td>4.3</td>
                                <td>0.18</td>
                                <td>4.6</td>
                                <td>4.0</td>
                            </tr>
                            <tr>
                                <td>Pain</td>
                                <td>4.3</td>
                                <td>0.18</td>
                                <td>4.9</td>
                                <td>4.3</td>
                            </tr>
                            <tr>
                                <td>Self image</td>
                                <td>3.8</td>
                                <td>0.2</td>
                                <td>4.2</td>
                                <td>3.4</td>
                            </tr>
                            <tr>
                                <td>Mental health</td>
                                <td>4.4</td>
                                <td>0.3</td>
                                <td>5.0</td>
                                <td>3.8</td>
                            </tr>
                            <tr>
                                <td>Satisfaction with management</td>
                                <td>4.3</td>
                                <td>0.3</td>
                                <td>4.8</td>
                                <td>3.5</td>
                            </tr>
                            <tr>
                                <td>Mean</td>
                                <td>4.26</td>
                                <td>0.014</td>
                                <td>4.5</td>
                                <td>4.0</td>
                            </tr>

                        </table>

                </div>
            </div>
        </div>

        <div class="col-6">
            <div class="card">
                <div class="card-body">
                    <p class="card-text">
                        <img class="graph" src="/images/cobb.png" style="max-height: 396px;">
                </div>
            </div>
        </div>
    </div> -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hospital.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/patientrecord/viewrecord.blade.php ENDPATH**/ ?>