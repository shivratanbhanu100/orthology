<div class="cf-container dispnone" id="cf-container">
    <br>
    <table class="table table-bordered table-striped reportform formtable">

        <tr>
            <td>Name<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input required type="text" class="form-control" name="name" id="name"
                            value="<?php echo e(@old('name')); ?>" placeholder="Name" autocomplete="off" required>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOB</td>
            <td>
                <div class="input-group mb-3 mr-4">
                    <select class="form-control" name="dob_date" id="dob_date">
                        <option value="">DD</option>
                        <?php for($i=1; $i <= 31; $i++): ?> 
                            <option><?php echo e(sprintf('%02d', $i)); ?></option>
                        <?php endfor; ?>
                    </select>
                    <select class="form-control" name="dob_month" id="dob_month">
                        <option value="">MM</option>
                        <?php for($i=1; $i <= 12; $i++): ?> 
                            <option><?php echo e(sprintf('%02d', $i)); ?></option>
                        <?php endfor; ?>
                    </select>
                    <select class="form-control" name="dob_year" id="dob_year">
                        <option value="">YYYY</option>
                        <?php for($i=date('Y'); $i > date('Y', strtotime(date('Y').'- 100 years')); $i--): ?>
                            <option><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Age<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input required type="number" min="0" class="form-control" name="age" id="age"
                            value="<?php echo e(@old('age')); ?>" placeholder="Age" autocomplete="off">
                    <div class="input-group-append">
                        <span class="input-group-text">year(s)</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td>Sex<span class="text-danger">*</span></td>
            <td>
                <select class="form-control" name="sex" required="required">
                    <option value="">Select sex</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Others">Others</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>UHID<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input id="checknewuhid" type="text" class="form-control" name="uhid" id="uhid" value="<?php echo e(@old('uhid')); ?>" placeholder="UHID" autocomplete="off" required="required">
                </div>
                <span class="text-danger dangerspan dispnone">UHID already exists. Details on this form will be updated on patient's profile.</span>
                <span class="text-success successspan dispnone">UHID available</span>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Phone no<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="phone_no" id="phone_no" value="<?php echo e(@old('phone_no')); ?>" placeholder="Phone no" autocomplete="off" required="required">
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Address<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <textarea class="form-control" name="address" id="address" placeholder="Address" autocomplete="off" required="required"><?php echo e(@old('address')); ?></textarea>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Email Id</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="emailid" id="emailid" value="<?php echo e(@old('emailid')); ?>" placeholder="Email Id" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Occupation (Parent’s occupation in case of minor)</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="occupation" id="occupation" value="<?php echo e(@old('occupation')); ?>" placeholder="Occupation" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Bed no</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="bed_no" id="bed_no" value="<?php echo e(@old('bed_no')); ?>" placeholder="Bed no" autocomplete="off">
                </div>
            </td>
        </tr>

        <tr>
            <td>Operative details</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="operative_details" id="operative_details" value="<?php echo e(@old('operative_details')); ?>" placeholder="Operative details" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Diagnosis</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="diagnosis" id="diagnosis" value="<?php echo e(@old('diagnosis')); ?>" placeholder="Diagnosis" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Level</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="level" id="level" value="<?php echo e(@old('level')); ?>" placeholder="Level" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Treatment / Op procedure</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="treatment_procedure" id="treatment_procedure" value="<?php echo e(@old('treatment_procedure')); ?>" placeholder="Treatment / Op procedure" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Comorbidities</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="comorbidities" id="comorbidities" value="<?php echo e(@old('comorbidities')); ?>" placeholder="Comorbidities" autocomplete="off">
                </div>
            </td>
        </tr>

        <tr>
            <td class="firstcol">Surgeons</td>
            <td>
                <?php $__currentLoopData = orthologsurgeons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surgeon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox custom-control-inline mb-3">
                        <input type="checkbox" class="custom-control-input" id="specific_event_<?php echo e($surgeon); ?>" value='<?php echo e($surgeon); ?>' name='surgeons[]'>
                        <label class="custom-control-label" for="specific_event_<?php echo e($surgeon); ?>"> <?php echo e($surgeon); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
        <tr>
            <td>Implant</td>
            <td>
                <div class="input-group mb-3">
                    <textarea class="form-control" name="implant" id="implant" placeholder="Implant" autocomplete="off"><?php echo e(@old('implant')); ?></textarea>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Surgical duration</td>
            <td>
                <div class="input-group mb-3">
                    <input type="number" min="0" class="form-control" name="surgical_time" id="surgical_time"
                            value="<?php echo e(@old('surgical_time')); ?>" placeholder="Surgical time" autocomplete="off">
                    <div class="input-group-append">
                        <span class="input-group-text">minute(s)</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Blood loss</td>
            <td>
                <div class="input-group mb-3">
                    <input type="number" min="0" class="form-control" name="blood_loss" id="blood_loss"
                            value="<?php echo e(@old('blood_loss')); ?>" placeholder="Blood loss" autocomplete="off">
                    <div class="input-group-append">
                        <span class="input-group-text">ml</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOA</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="doa" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="doa"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOO</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="doo" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="doo"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOD</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="dod" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="dod"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Post op course</td>
            <td>
                <?php ($i=1); ?>
                <?php $__currentLoopData = postopcourse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postopcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="postopcourse<?php echo e($i); ?>" value='<?php echo e($postopcourse); ?>' name='postopcourses[]'>
                        <label class="custom-control-label" for="postopcourse<?php echo e($i); ?>"> <?php echo e($postopcourse); ?></label>
                    </div>
                    <?php ($i++); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="postopcoursesother" value='Other' name='postopcourses[]'>
                    <label class="custom-control-label" for="postopcoursesother"> Other</label>
                </div>
                <input type="text" class="form-control" name="postopcourses_other">
            </td>
        </tr>

    </table>
</div><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/ortholog/logs/cf/new.blade.php ENDPATH**/ ?>