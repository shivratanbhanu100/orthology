<?php $__env->startSection('fixedheadercontent'); ?>

  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">

      <h1 class="h2">Dashboard</h1>


    </div>

    <div class="form-inline">


      <div id="momentdaterange">
          <i class="fa fa-calendar"></i>&nbsp;
          <span></span> <i class="fa fa-caret-down"></i>
      </div>      
      <input type="hidden" class="momentstartdate" value="<?php echo e(date('Y-m-d', strtotime('-6 months', strtotime(date('Y-m-d'))))); ?>">
      <input type="hidden" class="momentenddate" value="<?php echo e(date('Y-m-d')); ?>">

      <div class="btn-group btn-group-sm" role="group">
        <a class="exportbutton btn btn-outline-secondary" exportfilename="exportfilename" data-toggle="tooltip" data-placement="bottom" title="Export">
          <i class="fas fa-download"></i>
        </a>
        <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
      </div>

      <button type="button" class="btn btn-sm btn-danger ml-2 deletebutton denominatordel">
        <i class="fas fa-trash-alt"></i> Delete
      </button>

    </div>

  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('headercontent'); ?>

<div class="dash_full">

  <div class="container">
    <div class="row">

      <div class="col-sm">
        <div class="card" >
          <div class="card-body">
            <span class="card-text">
              <span class="cardhead">Total Surgical Time</span>
              <br>
              
            <h1 class="card-title"><b><span class="totalspan"><?php echo e($total); ?></span> min</b></h1>
          </div>
        </div>        
      </div>

      <div class="col-sm">
        <div class="card" >
          <div class="card-body">
            <span class="card-text">
              <span class="cardhead">No of cases</span>
              <br>
              
            <h1 class="card-title"><b><span class="countspan"><?php echo e($count); ?></span> cases</b></h1>
          </div>
        </div>        
      </div>

      <div class="col-sm">
        <div class="card" >
          <div class="card-body">
            <span class="card-text">
              <span class="cardhead">Avg. Surgical Time</span>
              <br>
              
            <h1 class="card-title"><b><span class="meanspan"><?php echo e($mean); ?></span> min</b></h1>
          </div>
        </div>        
      </div>

    </div> 
    

    <div class="row mt-3">

      <div class="col-6">
        <div class="card" >
          <div class="card-body">
            <p class="card-text">
            <?php echo $chartsex->container(); ?>

              <?php echo $chartsex->script(); ?>

          </div>
        </div>        
      </div>       
      <div class="col-6">
        <div class="card" >
          <div class="card-body">
            <p class="card-text">
              <!-- <img class="graph" src="/images/age-bar.png"> -->
              <?php echo $chartage->container(); ?>

              <?php echo $chartage->script(); ?>

          </div>
        </div>        
      </div>       
     

    </div>

  </div>  

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('tablecontent'); ?>
  <!--table starts here-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ortho.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/ortholog/dashboard/index.blade.php ENDPATH**/ ?>