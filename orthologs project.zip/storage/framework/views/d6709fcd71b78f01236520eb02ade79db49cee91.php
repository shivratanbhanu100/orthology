<?php $__env->startSection('fixedheadercontent'); ?>

  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
      <h1 class="h2">Edit Log</h1>
    </div>

    <div class="form-inline">
      <div class="btn-group btn-group-sm" role="group">
        <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('headercontent'); ?>

<div class="px-3 py-3">
    <form method="post" action="/ortho/ortholog/<?php echo e($log->id); ?>/update" class="mw-50">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PATCH')); ?>

        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text">
                    Select Category
                </span>
            </div>
            <select class="form-control ortho_category" name="category">
                <option value="">Select Category</option>
                <?php $__currentLoopData = orthologcategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryloop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoryloop); ?>" <?php echo e($log->category==$categoryloop?'selected':null); ?>><?php echo e($categoryloop); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="<?php echo e($log->category!='Traumatic'?'dispnone':null); ?> trauma_category_div">
            <div class="mt-2 mb-2 input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        Site
                    </span>
                </div>
                <select class="form-control trauma_site" name="trauma_site">
                    <option value="">Select Site</option>
                    <?php $__currentLoopData = orthologtraumasite(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traumasite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($traumasite); ?>" <?php echo e($log->trauma_site==$traumasite?'selected':null); ?>><?php echo e($traumasite); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="<?php echo e($log->category!='Infection'?'dispnone':null); ?> infection_category_div">
            <div class="mt-2 mb-2 input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        Type
                    </span>
                </div>
                <select class="form-control infection_type" name="infection_type">
                    <option value="">Select type</option>
                    <?php $__currentLoopData = orthologinfectiontype(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infectiontype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($infectiontype); ?>" <?php echo e($log->infection_type==$infectiontype?'selected':null); ?>><?php echo e($infectiontype); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="<?php echo e($log->infection_type!='Tuberculosis'?'dispnone':null); ?> tb_div">
                <table class="table table-bordered">
                    <tr>
                        <td>MDR</td>
                        <td>
                            <div class="input-group input-group-sm mb-3">
                                <div class="custom-control custom-radio mr-1">
                                    <input type="radio" class="custom-control-input" id="tb_mdr_1" value='No' name="tb_mdr" <?php echo e($log->tb_mdr=='No'?'checked':null); ?>>
                                    <label class="custom-control-label" for="tb_mdr_1">No</label>
                                </div>
                                <div class="custom-control custom-radio mr-1">
                                    <input type="radio" class="custom-control-input" id="tb_mdr_2" value='Yes' name="tb_mdr" <?php echo e($log->tb_mdr=='Yes'?'checked':null); ?>>
                                    <label class="custom-control-label" for="tb_mdr_2">Yes</label>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>HPE</td>
                        <td><input type="text" name="tb_hpe" value="<?php echo e($log->tb_hpe); ?>" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Gene expert</td>
                        <td><input type="text" name="tb_gene" value="<?php echo e($log->tb_gene); ?>" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>C/S</td>
                        <td><input type="text" name="tb_cs" value="<?php echo e($log->tb_cs); ?>" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>TB culture</td>
                        <td><input type="text" name="tb_culture" value="<?php echo e($log->tb_culture); ?>" class="form-control"></td>
                    </tr>
                </table>
            </div>
            <div class="<?php echo e($log->infection_type!='Pyogenic'?'dispnone':null); ?> pyogenic_div">
                <table class="table table-bordered"> 
                    <tr>
                        <td>C/S</td>
                        <td>
                            <div class="mt-2 mb-2 input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        Bacteria
                                    </span>
                                </div>
                                <input type="text" class="form-control tb_pyogenic_bacteria" value="<?php echo e($log->tb_pyogenic_bacteria); ?>" name="tb_pyogenic_bacteria">
                            </div>
                            <div class="mt-2 mb-2 input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        Antibiotic sensitivity
                                    </span>
                                </div>
                                <input type="text" class="form-control tb_pyogenic_antibiotic" value="<?php echo e($log->tb_pyogenic_antibiotic); ?>" name="tb_pyogenic_antibiotic">
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="mt-2 mb-2 input-group" id="infection_site_div">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        Site
                    </span>
                </div>
                <select class="form-control infection_site" name="infection_site">
                    <option value="">Select site</option>
                    <?php $__currentLoopData = orthologinfectionsite(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infectionsite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($infectionsite); ?>" <?php echo e($log->infection_site==$infectionsite?'selected':null); ?>><?php echo e($infectionsite); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="<?php echo e($log->category!='Deformity'?'dispnone':null); ?> deformity_category_div">
            <div class="mt-2 mb-2 input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        Deformity Type
                    </span>
                </div>
                <select class="form-control deformity_type" name="deformity_type">
                    <option value="">Select type</option>
                    <option value="Scoliosis" <?php echo e($log->deformity_type=="Scoliosis"?'selected':null); ?>>Scoliosis</option>
                    <option value="Kyphosis" <?php echo e($log->deformity_type=="Kyphosis"?'selected':null); ?>>Kyphosis</option>
                </select>
            </div>
            <div class="<?php echo e($log->deformity_type!='Scoliosis'?'dispnone':null); ?> deformity_scoliosis_div">
                <div class="mt-2 mb-2 input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            Type
                        </span>
                    </div>
                    <select class="form-control scoliosis_type" name="scoliosis_type">
                        <option value="">Select type</option>
                        <?php $__currentLoopData = orthologscoliosistype(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scoliosistype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($scoliosistype); ?>" <?php echo e($log->scoliosis_type==$scoliosistype?'selected':null); ?>><?php echo e($scoliosistype); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <table class="table table-bordered table-striped">
                    <tr>
                        <th colspan="2">
                            <?php ($stage=getLastSrsStage($log->patient_id)); ?>
                            <?php if($stage==0): ?>
                                <i><u>Note:</u> You will be redirected to SRS22r questionnaire in the next step.</i>
                            <?php else: ?>
                                <i><u>Note:</u> <a href="/srs22/edit/<?php echo e($stage); ?>/<?php echo e($log->patient_id); ?>">View SRS22r questionnaire</a> | <a href="/scoliosis/patient/<?php echo e($log->patient_id); ?>">View Scoliosis profile</a></i>
                            <?php endif; ?>
                        </th>
                    </tr>
                </table>
            </div>
            <div class="<?php echo e($log->deformity_type!='Kyphosis'?'dispnone':null); ?> deformity_kyphosis_div">
                <table class="table table-bordered table-striped">
                    <tr>
                        <td>Type</td>
                        <td>
                            <select class="form-control kyphosis_type" name="kyphosis_type">
                                <option value="">Select type</option>
                                <?php $__currentLoopData = orthologkyphosistype(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kyphosistype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kyphosistype); ?>" <?php echo e($log->kyphosis_type==$kyphosistype?'selected':null); ?>><?php echo e($kyphosistype); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Kyphosis angle</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 name="kyphosis_angle" class="form-control" value="<?php echo e($log->kyphosis_angle); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Sagital shift</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="sagital_shift" class="form-control" value="<?php echo e($log->sagital_shift); ?>">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>PI</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="kyphosis_pi" class="form-control"  value="<?php echo e($log->kyphosis_pi); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>PT</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="kyphosis_pt" class="form-control" value="<?php echo e($log->kyphosis_pt); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>SS</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="kyphosis_ss" class="form-control" value="<?php echo e($log->kyphosis_ss); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>TK</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="kyphosis_tk" class="form-control" value="<?php echo e($log->kyphosis_tk); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>LL</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="kyphosis_ll" class="form-control" value="<?php echo e($log->kyphosis_ll); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="<?php echo e($log->category!='Degenerative'?'dispnone':null); ?> degenerative_category_div">
            <div class="mt-2 mb-2 input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        Site
                    </span>
                </div>
                <select class="form-control degenerative_site" name="degenerative_site">
                    <option value="">Select site</option>
                    <option value="Lumbar" <?php echo e($log->degenerative_site=='Lumbar'?'selected':null); ?>>Lumbar</option>
                    <option value="Cervical" <?php echo e($log->degenerative_site=='Cervical'?'selected':null); ?>>Cervical</option>
                </select>
            </div>
            <div class="<?php echo e($log->degenerative_site!='Lumbar'?'dispnone':null); ?> lumbar_site_div">
                <table class="table table-bordered table-striped">
                    <tr>
                        <td>Imaging findings</td>
                        <td>
                            <div class="mb-3">
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_1" value='Anterolisthesis(Grade 1,2)' name="imagefinding[]" <?php echo e(in_array('Anterolisthesis(Grade 1,2)', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_1">Anterolisthesis(Grade 1,2)</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_2" value='Anterolisthesis(Grade 3,4,5)' name="imagefinding[]" <?php echo e(in_array('Anterolisthesis(Grade 3,4,5)', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_2" >Anterolisthesis(Grade 3,4,5)</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_3" value='Spondylolysis' name="imagefinding[]" <?php echo e(in_array('Spondylolysis', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_3">Spondylolysis</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_4" value='Degeneration' name="imagefinding[]" <?php echo e(in_array('Degeneration', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_4">Degeneration</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_5" value='LCS' name="imagefinding[]" <?php echo e(in_array('LCS', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_5">LCS</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_6" value='PIVD' name="imagefinding[]" <?php echo e(in_array('PIVD', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_6">PIVD</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_7" value='LF hypertrophy' name="imagefinding[]" <?php echo e(in_array('LF hypertrophy', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_7">LF hypertrophy</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_8" value='Retrolisthesis' name="imagefinding[]" <?php echo e(in_array('Retrolisthesis', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_8">Retrolisthesis</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_9" value='Failed back / Recurrent disc' name="imagefinding[]" <?php echo e(in_array('Failed back / Recurrent disc', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_9">Failed back / Recurrent disc</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="imagefinding_10" value='Others' name="imagefinding[]" <?php echo e(in_array('Others', explode(',',$log->imagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="imagefinding_10">Others</label>
                                </div>
                                <input type="text" class="form-control" name="imagefinding_other" value="<?php echo e($log->imagefinding_other); ?>">
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td>PI</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="lumbar_pi" class="form-control" value="<?php echo e($log->lumbar_pi); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>PT</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="lumbar_pt" class="form-control" value="<?php echo e($log->lumbar_pt); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>SS</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="lumbar_ss" class="form-control" value="<?php echo e($log->lumbar_ss); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>TK</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="lumbar_tk" class="form-control" value="<?php echo e($log->lumbar_tk); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>LL</td>
                        <td>
                            <div class="input-group">
                                <input type="number" min=0 step="any" name="lumbar_ll" class="form-control" value="<?php echo e($log->lumbar_ll); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        degree
                                    </span>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>
                <!-- Oswestry low back disability (questionnaire)-->
                <table class="table table-bordered table-striped">
                    <tr >
                        <th colspan="2" class="text-white bg-dark">
                            Oswestry low back disability (questionnaire)
                        </th>
                    </tr>
                    
                    <tr >
                        <th colspan="2">
                        <i><u>Instructions:</u> This questionnaire has been designed to give us information as to how your back or leg pain is affecting your ability to manage in everyday life. Please answer by checking ONE box in each section for the statement which best applies to you. We realise you may consider that two or more statements in any one section apply but please just shade out the spot that indicates the statement which most clearly describes your problem. </i>
                        </th>
                    </tr>
                    <tr>
                        <!-- <th colspan="2">Total Score: <?php echo e($log->total_oswestry_score); ?></th> -->
                        <td colspan="2">
                        <?php if($log->category=='Degenerative' && $log->degenerative_site=='Lumbar'): ?>
                            <?php ($score=$log->countOswestryScoreFunction()); ?>
                            <span class="badge badge-success">Score:<?php echo e($score[0]); ?>/<?php echo e($score[2]); ?> = <?php echo e($score[3]*100); ?>%</span><br>
                            <?php echo e(getOswestryInterpretation($score[3]*100)); ?>

                        <?php endif; ?>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $oswestryquestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oswestryquestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="firstcol"><?php echo e($oswestryquestion->question); ?><br><span class="badge badge-primary"><?php echo e($oswestryquestion->question_category); ?></span></td>
                        <td>
                            <div class="">
                            <?php $__currentLoopData = $oswestryquestion->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oswestryoption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-radio mr-2">
                                    <input type="radio" class="custom-control-input sex" id="oswest<?php echo e($oswestryquestion->id); ?>_<?php echo e($oswestryoption->id); ?>" value='<?php echo e($oswestryoption->id); ?>' name='oswest<?php echo e($oswestryquestion->id); ?>' <?php echo e(optionSelectedByPatientOswestry($log->id, $oswestryoption->id)?'checked':null); ?>>
                                    <label class="custom-control-label" for="oswest<?php echo e($oswestryquestion->id); ?>_<?php echo e($oswestryoption->id); ?>"><?php echo e($oswestryoption->option); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <div class="<?php echo e($log->degenerative_site!='Cervical'?'dispnone':null); ?> cervical_site_div">
                <table class="table table-bordered table-striped">
                    <tr>
                        <td>Imaging findings</td>
                        <td>
                            <div class="mb-3">
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="cervicalimagefinding_1" value='PIVD' name="cervicalimagefinding[]" <?php echo e(in_array('PIVD', explode(',',$log->cervicalimagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="cervicalimagefinding_1">PIVD</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="cervicalimagefinding_2" value='OPLL' name="cervicalimagefinding[]" <?php echo e(in_array('OPLL', explode(',',$log->cervicalimagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="cervicalimagefinding_2">OPLL</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="cervicalimagefinding_3" value='Instability' name="cervicalimagefinding[]" <?php echo e(in_array('Instability', explode(',',$log->cervicalimagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="cervicalimagefinding_3">Instability</label>
                                </div>
                                <div class="custom-control custom-checkbox mr-1">
                                    <input type="checkbox" class="custom-control-input" id="cervicalimagefinding_4" value='Others' name="cervicalimagefinding[]" <?php echo e(in_array('Others', explode(',',$log->cervicalimagefinding))?'checked':null); ?>>
                                    <label class="custom-control-label" for="cervicalimagefinding_4">Others</label>
                                </div>
                                <input type="text" class="form-control" name="cervicalimagefinding_other" vaue="<?php echo e($log->cervicalimagefinding_other); ?>">
                            </div>
                        </td>
                    </tr>
                </table>
                <!-- Modified Japanese Association Score (Questionnaire)-->
                <table class="table table-bordered table-striped">
                    <tr >
                        <th colspan="2" class="text-white bg-dark">
                            Modified Japanese Association Score (Questionnaire)
                        </th>
                    </tr>
                    <tr>
                        <!-- <th colspan="2">Total Score: <?php echo e($log->total_japanese_score); ?></th> -->
                        <th colspan="2">
                            <?php if($log->category=='Degenerative' && $log->degenerative_site=='Cervical'): ?>
                                <?php ($score=$log->countJapaneseScoreFunction()); ?>
                                <span class="badge badge-success">Score:<?php echo e($score[0]); ?>/<?php echo e($score[2]); ?> = <?php echo e($score[3]*100); ?>%</span>
                            <?php endif; ?>
                        </th>
                    </tr>
                    <?php $__currentLoopData = $japanesequestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $japanesequestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="firstcol"><?php echo e($japanesequestion->id); ?>. <?php echo e($japanesequestion->question); ?><br><span class="badge badge-primary"><?php echo e($japanesequestion->question_category); ?></span></td>
                        <td>
                            <div class="">
                            <?php $__currentLoopData = $japanesequestion->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $japaneseoption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-radio mr-2">
                                    <input type="radio" class="custom-control-input sex" id="japanese<?php echo e($japanesequestion->id); ?>_<?php echo e($japaneseoption->id); ?>" value='<?php echo e($japaneseoption->id); ?>' name='japanese<?php echo e($japanesequestion->id); ?>' <?php echo e(optionSelectedByPatientJapanese($log->id, $japaneseoption->id)?'checked':null); ?>>
                                    <label class="custom-control-label" for="japanese<?php echo e($japanesequestion->id); ?>_<?php echo e($japaneseoption->id); ?>"><?php echo e($japaneseoption->option); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <div class="<?php echo e($log->category!='Tumours'?'dispnone':null); ?> tumour_category_div" id="tumour_category_div">
            <div class="mt-2 mb-2 input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        Type
                    </span>
                </div>
                <div class="input-group-append">
                    <span class="input-group-text">
                        <div class="input-group input-group-sm">
                            <div class="custom-control custom-radio mr-1">
                                <input type="radio" class="custom-control-input" id="tumour_type_1" value='Primary' name="tumour_type" <?php echo e($log->tumour_type=='Primary'?'checked':null); ?>>
                                <label class="custom-control-label" for="tumour_type_1">Primary</label>
                            </div>
                            <div class="custom-control custom-radio mr-1">
                                <input type="radio" class="custom-control-input" id="tumour_type_2" value='Metastasis' name="tumour_type" <?php echo e($log->tumour_type=='Metastasis'?'checked':null); ?>>
                                <label class="custom-control-label" for="tumour_type_2">Metastasis</label>
                            </div>
                        </div>
                    </span>
                </div>
                
            </div>
        </div>
        <div class="misc_category_div">

        </div>
        <?php echo $__env->make('hospital.ortholog.logs.cf.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <button type="submit" class="btn btn-success">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ortho.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/ortholog/logs/edit.blade.php ENDPATH**/ ?>