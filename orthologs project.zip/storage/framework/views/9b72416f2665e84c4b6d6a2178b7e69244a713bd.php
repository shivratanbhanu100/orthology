<?php if(Session::has('flash_message')): ?>

     <div class="col-lg-12 flash_msg" >

         <div class="alert alert-success"> <?php echo session('flash_message'); ?>


           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>

         </div>

     </div>

 <?php endif; ?>
 
 <?php if(Session::has('redflash_message')): ?>

     <div class="col-lg-12 flash_msg" >

         <div class="alert alert-danger"> <?php echo session('redflash_message'); ?>


           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>

         </div>

     </div>

 <?php endif; ?>
<?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/layouts/flash_msg.blade.php ENDPATH**/ ?>