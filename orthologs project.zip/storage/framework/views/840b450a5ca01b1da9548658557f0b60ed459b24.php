<?php $__currentLoopData = $selectedlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class='foreachtr'>
  <td>
    <div class="custom-control custom-checkbox">
      <input type="checkbox"  name='ids[]' class="idcheckbox custom-control-input idcheckbox" id="customCheck<?php echo e($log->id); ?>" value="<?php echo e($log->id); ?>" name='ids[]'>
      <label class="custom-control-label" for="customCheck<?php echo e($log->id); ?>">&nbsp;</label>
    </div>
  </td>
  <td><a href="/ortho/ortholog/<?php echo e($log->id); ?>/view/"><?php echo e(caseidformat($log->id)); ?></a>
    <?php if(count($log->relatedIds)>0): ?>
      <br>
      <a href="javascript:void(0)" class="showrelatedcaseidlink"><span class="badge badge-primary">Related Case IDs</span></a>
      <ul class="dispnone">
        <?php $__currentLoopData = $log->relatedIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a target="_blank" href="/ortho/ortholog/<?php echo e($relatedid); ?>/view/"><?php echo e(caseidformat($relatedid)); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    <?php endif; ?>
  </td>
  
  <td class="naclass"><?php echo e($log->patientdetail->name); ?></td>
  <td class="naclass"><?php echo e($log->patientdetail->sex); ?></td>

  <td class="naclass"><?php echo e($log->patientdetail->uhid); ?></td>
  <td class="naclass">
    <?php echo e($log->category); ?><br>
    <?php if($log->category=='Traumatic'): ?>
    <span class="badge badge-success"><?php echo e($log->trauma_site); ?></span>
    <?php endif; ?>
    <?php if($log->category=='Infection'): ?>
    <span class="badge badge-success"><?php echo e($log->infection_type); ?></span>
    <?php endif; ?>
    <?php if($log->category=='Tumours'): ?>
    <span class="badge badge-success"><?php echo e($log->tumour_type); ?></span>
    <?php endif; ?>
    <?php if($log->category=='Deformity' && $log->deformity_type=='Scoliosis'): ?>
    <a class="badge badge-success" href="/scoliosis/patient/<?php echo e($log->patient_id); ?>">Scoliosis</a>
    <?php endif; ?>
    <?php if($log->category=='Degenerative' && $log->degenerative_site=='Lumbar'): ?>
      <?php ($score=$log->countOswestryScoreFunction()); ?>
      <span class="badge badge-success">Lumbar</span>
    <?php endif; ?>
    <?php if($log->category=='Degenerative' && $log->degenerative_site=='Cervical'): ?>
      <?php ($score=$log->countJapaneseScoreFunction()); ?>
      <span class="badge badge-success">Cervical</span>
    <?php endif; ?>
  </td>
  <td class="naclass"><?php echo e(substr($log->surgeons, 1, -1)); ?></td>
  <td class="naclass">
    <?php if($log->category=='Deformity' && $log->deformity_type=='Scoliosis'): ?>
      <?php ($stage=getLastSrsStage($log->patient_id)); ?>
      <?php echo e($log->patientdetail->countScoreFunction($stage)); ?>

    <?php endif; ?>
    <?php if($log->category=='Degenerative' && $log->degenerative_site=='Lumbar'): ?>
      <?php ($score=$log->countOswestryScoreFunction()); ?>
      <?php echo e($score[3]*100); ?>%<br>
    <?php endif; ?>
    <?php if($log->category=='Degenerative' && $log->degenerative_site=='Cervical'): ?>
      <?php ($score=$log->countJapaneseScoreFunction()); ?>
      <?php echo e($score[3]*100); ?>%<br>
    <?php endif; ?>
  </td>
  <td class="naclass"><?php echo e($log->created_at->format('d M, Y')); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/ortholog/logs/list.blade.php ENDPATH**/ ?>