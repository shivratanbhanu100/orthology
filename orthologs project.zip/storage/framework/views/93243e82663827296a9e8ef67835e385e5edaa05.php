<?php $__env->startSection('fixedheadercontent'); ?>

  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">

      <h1 class="h2">Ortho logs</h1>

      <a href="/ortho/ortholog/new" class="btn btn-sm btn-success ml-2">
        <i class="fas fa-plus"></i>
        New Log
      </a>

    </div>

    <div class="form-inline">

      <div class="input-group input-group-sm mr-2 searchdiv">
        <div class="input-group-prepend border-right-0">
          <span class="input-group-text" id="inputGroup-sizing-sm">
            <i class="fas fa-search"></i>
          </span>
        </div>
        <input type="text" class="form-control searchbox extendbox superadminsearchbar" placeholder="Search" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
      </div>
      <div id="momentdaterange">
          <i class="fa fa-calendar"></i>&nbsp;
          <span></span> <i class="fa fa-caret-down"></i>
      </div>    
      <input type="hidden" class="momentstartdate" value="<?php echo e(date('Y-m-d', strtotime('-6 months', strtotime(date('Y-m-d'))))); ?>">
      <input type="hidden" class="momentenddate" value="<?php echo e(date('Y-m-d')); ?>">
      
      <div class="btn-group btn-group-sm dropleft">
        <button type="button" class="btn btn-outline-secondary dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
          Filter <i class="fas fa-filter"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-form filterdropdown">
          <li class="ml-2"><u><b>Categories</b></u></li>
          <div class="categoryloopcontent">
            <?php echo $__env->make('hospital.ortholog.logs.categoriesloopforfilter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
          <button type="button" class="btn btn-primary btn-sm logfilter">Apply Filter</button>
        </ul>

        
      </div>

      <button type="button" class="btn btn-sm btn-danger ml-2 deleteorthorecord dispnone">
        <i class="fas fa-trash-alt"></i> Delete
      </button>

    </div>

  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('headercontent'); ?>

 

<?php $__env->stopSection(); ?>


<?php $__env->startSection('tablecontent'); ?>
  <!--table starts here-->

  <div class="table-responsive">
    <table class="table table-hover table-export">
      <thead>
        <tr class="active">
          <th>
            <div class="custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input selectall" id="selectallcheckbox" value="0" name='ids[]'>
              <label class="custom-control-label" for="selectallcheckbox">&nbsp;</label>
            </div>
          </th>
          <th>Case ID</th>
          <th>Name</th>
          <th>Sex</th>
          <th>UHID</th>
          <th>Category</th>
          <th>Surgeons</th>
          <th>Functional Score</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody class="tbodycontainer">
          <?php echo $__env->make('hospital.ortholog.logs.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </tbody>
    </table>
  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ortho.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/ortholog/logs/index.blade.php ENDPATH**/ ?>