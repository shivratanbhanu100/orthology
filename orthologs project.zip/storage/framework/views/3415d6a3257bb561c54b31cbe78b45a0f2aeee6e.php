<?php $__env->startSection('fixedheadercontent'); ?>
  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
      <h1 class="h2">SRS22r Questionnaire</h1>
    </div>

    <div class="form-inline">
      <div class="btn-group btn-group-sm" role="group">
        Function: <span class="function_span">0</span>/5 |
        Pain: <span class="pain_span">0</span>/5 |
        Self image: <span class="self_image_span">0</span>/5 |
        Mental health: <span class="mental_health_span">0</span>/5 |
        Satisfaction/dissatisfaction with management: <span class="satisfation_span">0</span>/5 |
        Total SRS22r Score: <span class="total_srs_score_span">0</span>/5
        <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('headercontent'); ?>
  <div class="px-3 py-3">
    <form method="post" action="/newsrs22" id='crfform' class="form-horizontal">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
    <table class="table table-striped reportform formtable">
    <tr class="pointer togglepatientdetails">
        <th colspan="2" class="bg-dark text-white">1. PATIENT DETAILS <i class="fas fa-arrow-circle-right"></i>  <i class="fas fa-arrow-circle-down dispnone"></i></th>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td class="firstcol">UHID:<span class="text-danger">*</span></td>
        <td>
        <div class="input-group">
            <!-- <div class="input-group-prepend"> -->
                <input type="text" value="<?php echo e($patient->uhid); ?>" class="form-control" name='uhid' aria-describedby="basic-addon1" required="required" oninvalid="" autocomplete="off"/>
            <!-- </div> -->
            <!-- <input type="button" value="Load details" class="btn btn-primary loadfornewuhid"> -->
        </div>
        </td>
    </tr>

    <tr class="patientdetailrows dispnone disableclass">
        <td class="firstcol">Patient Name</td>
        <td>
        <input type="text"  value="<?php echo e($patient->name); ?>" class="form-control" aria-describedby="basic-addon1" name='patient_name' autocomplete="off"/>
        </td>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td>Sex<span class="text-danger">*</span></td>
        <td>
            <div class="input-group mb-3">
                <div class="custom-control custom-radio mb-3 mr-2">
                    <input type="radio" class="custom-control-input sex" id="sex_1" value='Male' name='sex' required <?php echo e($patient->sex=="Male"?'checked':null); ?>>
                    <label class="custom-control-label" for="sex_1">Male</label>
                </div>
                <div class="custom-control custom-radio mb-3 mr-2">
                    <input type="radio" class="custom-control-input sex" id="sex_2" value='Female' name='sex' <?php echo e($patient->sex=="Female"?'checked':null); ?>>
                    <label class="custom-control-label" for="sex_2">Female</label>
                </div>
                <div class="custom-control custom-radio mb-3 mr-2">
                    <input type="radio" class="custom-control-input sex" id="sex_3" value='Others' name='sex' <?php echo e($patient->sex=="Others"?'checked':null); ?>>
                    <label class="custom-control-label" for="sex_3">Others</label>
                </div>
            </div>
        </td>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td>Date of birth</td>
        <td>
            <div class="input-group mb-3 mr-4">
                <select class="form-control" name="dob_date" id="dob_date">
                    <option value="">DD</option>
                    <?php for($i=1; $i <= 31; $i++): ?> 
                        <option <?php echo e(!is_null($patient->dob)?(sprintf('%02d', $i)==$patient->dob->format('d')?'selected':null):null); ?>><?php echo e(sprintf('%02d', $i)); ?></option>
                    <?php endfor; ?>
                </select>
                <select class="form-control" name="dob_month" id="dob_month">
                    <option value="">MM</option>
                    <?php for($i=1; $i <= 12; $i++): ?> 
                        <option <?php echo e(!is_null($patient->dob)?(sprintf('%02d', $i)==$patient->dob->format('m')?'selected':null):null); ?>><?php echo e(sprintf('%02d', $i)); ?></option>
                    <?php endfor; ?>
                </select>
                <select class="form-control" name="dob_year" id="dob_year">
                    <option value="">YYYY</option>
                    <?php for($i=date('Y'); $i > date('Y', strtotime(date('Y').'- 100 years')); $i--): ?>
                        <option <?php echo e(!is_null($patient->dob)?($i==$patient->dob->format('Y')?'selected':null):null); ?>><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </td>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td>Age (Years)<span class="text-danger removestar">*</span></td>
        <td>
            <input type="number" value="<?php echo e($patient->age); ?>" class="form-control removerequired" name="age" id="age" required>
        </td>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td>Diagnosis<span class="text-danger">*</span></td>
        <td>
            <textarea class="form-control" name="diagnosis" id="diagnosis" required><?php echo e($patient->diagnosis); ?></textarea>
        </td>
    </tr>

    <tr >
        <th colspan="2" class="text-white bg-dark">
            2. QUESTIONNAIRE
        </th>
    </tr>
    <tr>
      <td class="firstcol">Stage<span class="text-danger">*</span></td>
      <td>
        <?php
            $currentstagename='';
            switch($stage){
                case 1:$currentstagename="Preoperative";
                break;
                case 2:$currentstagename="Post operative";
                break;
                case 3:$currentstagename="Postop F/U 1st visit – 1 month";
                break;
                case 4:$currentstagename="Postop F/U 2nd visit – 6 months";
                break;
                default:$currentstagename='No stage selected';
            }
        ?>
        <select class="form-control" name="stage" id="stage">
            <option value="<?php echo e($stage); ?>"><?php echo e($currentstagename); ?></option>
        </select>
      </td>
    </tr>
    <tr>
        <td>Date of questionnaire<span class="text-danger">*</span></td>
        <td>
        <input type="text" value="<?php echo e(date('d-m-Y')); ?>" id="date_of_questionnaire" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="date_of_questionnaire"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1" required="required"  oninvalid="" autocomplete="off"/>
        </td>
    </tr>
    <tr >
        <th colspan="2">
        <i><u>Instructions:</u> We are carefully evaluating the condition of your back and it is important that you answer each of these questions yourself. Please select the best answer to each question.</i>
        </th>
    </tr>
    <?php $__currentLoopData = $srsquestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="firstcol"><?php echo e($srs->id); ?>. <?php echo e($srs->question); ?><br><span class="badge badge-primary"><?php echo e($srs->question_category); ?></span></td>
        <td>
            <div class="input-group mb-3">
            <?php $__currentLoopData = $srs->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srsoption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="custom-control custom-radio mb-3 mr-2">
                    <input type="radio" class="custom-control-input srsoptions" id="q<?php echo e($srs->id); ?>_<?php echo e($srsoption->id); ?>" value='<?php echo e($srsoption->id); ?>' category="<?php echo e($srs->question_category); ?>" score="<?php echo e($srsoption->score); ?>" name='q<?php echo e($srs->id); ?>'>
                    <label class="custom-control-label" for="q<?php echo e($srs->id); ?>_<?php echo e($srsoption->id); ?>"><?php echo e($srsoption->option); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    

</table>

      <br>

      <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- <a href="/scoliosis/proforma" class="btn btn-success">Submit</a>
      <a href="/scoliosis/proforma/new/1" class="btn btn-primary">Save and continue to proforma</a> -->
      <input type="hidden" name="dashboard" value="0">
      <input type="submit" id="formsubmitbtn" class="dispnone">
        <button type="submit" class="btn btn-success submittype" dasboardval="1">Submit</button>
        <button type="submit" class="btn btn-primary submittype" dasboardval="0">Save and continue to proforma</button>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.hospital.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/patientrecord/newsrs.blade.php ENDPATH**/ ?>