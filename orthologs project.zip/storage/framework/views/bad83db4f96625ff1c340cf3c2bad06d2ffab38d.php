<?php ($i=1); ?>
<?php $__currentLoopData = orthologcategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <label class="filtercheckbox"><input type="checkbox" id="category_<?php echo e($i); ?>" value='<?php echo e($category); ?>' name='categories[]'> <?php echo e($category); ?> (<span class=><?php echo e($catcount[$category]); ?></span>)</label>            
    </li>
    <?php ($i++); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/ortholog/logs/categoriesloopforfilter.blade.php ENDPATH**/ ?>