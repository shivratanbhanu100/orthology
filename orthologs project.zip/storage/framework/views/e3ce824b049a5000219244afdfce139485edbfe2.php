<?php $__env->startSection('fixedheadercontent'); ?>

<div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
        <h1 class="h2">Add new user</h1>
    </div>

    <div class="form-inline">
        <div class="btn-group btn-group-sm" role="group">
            <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('headercontent'); ?>
<div class="px-3 py-3">
    <form method="post" action="/user/new" class="form-horizontal">

        <?php echo csrf_field(); ?>

        <table class="table table-striped reportform formtable">
            <tr>
                <td class="firstcol">Email:<span class="text-danger">*</span></td>
                <td>
                    <input type="email" id="checknewemail" class="form-control" name='email' aria-describedby="basic-addon1"
                        required="required" oninvalid="" autocomplete="off" />
                    <span class="text-danger dangerspan dispnone">Email id already exists.</span>
                    <span class="text-success successspan dispnone">Email id available</span>
                </td>
            </tr>

            <tr>
                <td class="firstcol">Name<span class="text-danger">*</span></td>
                <td>
                    <input type="text" class="form-control" aria-describedby="basic-addon1" name='name'
                        autocomplete="off" />
                </td>
            </tr>
            <tr>
                <td>Role<span class="text-danger">*</span></td>
                <td>
                    <select class="form-control" name="role">
                        <option value="">Select Role</option>
                        <option value="orthoadmin">Ortho admin</option>
                        <option value="scoliosisadmin">Scoliosis admin</option>
                        <option value="superadmin">Super admin</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Password<span class="text-danger">*</span></td>
                <td>
                    <input type="password" class="form-control" name="password">
                </td>
            </tr>
            <tr>
                <td>Confirm Password<span class="text-danger">*</span></td>
                <td>
                    <input type="password" class="form-control" name="password_confirmation">
                </td>
            </tr>
        </table>
        <br>
        <!--Add employer details form start-->
        <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="submit" id="formsubmitbtn" class="btn btn-primary">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hospital.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/users/new.blade.php ENDPATH**/ ?>