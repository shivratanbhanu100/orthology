<div class="cf-container" id="cf-container">
    <br>
    <table class="table table-bordered reportform">

        <tr>
            <td>Name</td>
            <td><?php echo e($log->patientdetail->name); ?></td>
        </tr>
        <tr>
            <td class="firstcol">DOB</td>
            <td><?php echo e(!is_null($log->patientdetail->dob)?$log->patientdetail->dob->format('d-m-Y'):null); ?></td>
        </tr>
        <tr>
            <td class="firstcol">Age</td>
            <td><?php echo e($log->patientdetail->age); ?></td>
        </tr>
        <tr>
            <td>Sex</td>
            <td><?php echo e($log->patientdetail->sex); ?>

            </td>
        </tr>
        <tr>
            <td>UHID</td>
            <td><?php echo e($log->patientdetail->uhid); ?></td>
        </tr>
        <tr>
            <td class="firstcol">Phone no</td>
            <td><?php echo e($log->patientdetail->phone); ?></td>
        </tr>
        <tr>
            <td class="firstcol">Address</td>
            <td><?php echo e($log->patientdetail->address); ?></td>
        </tr>
        <tr>
            <td class="firstcol">Email Id</td>
            <td><?php echo e($log->patientdetail->email); ?></div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Occupation (Parent’s occupation in case of minor)</td>
            <td><?php echo e($log->patientdetail->occupation); ?></td>
        </tr>
        <tr>
            <td>Bed no</td>
            <td><?php echo e($log->patientdetail->bed_no); ?></td>
        </tr>

        <tr>
            <td>Operative details</td>
            <td><?php echo e($log->operative_details); ?></td>
        </tr>
        <tr>
            <td>Diagnosis</td>
            <td><?php echo e($log->diagnosis); ?></td>
        </tr>
        <tr>
            <td>Level</td>
            <td><?php echo e($log->level); ?></td>
        </tr>
        <tr>
            <td>Treatment / Op procedure</td>
            <td><?php echo e($log->treatment_procedure); ?></td>
        </tr>
        <tr>
            <td>Comorbidities</td>
            <td><?php echo e($log->comorbidities); ?></td>
        </tr>

        <tr>
            <td class="firstcol">Surgeons</td>
            <td><?php echo e($log->surgeons); ?></td>
        </tr>
        <tr>
            <td>Implant</td>
            <td><?php echo e($log->implant); ?></td>
        </tr>
        <tr>
            <td class="firstcol">Surgical duration</td>
            <td><?php echo e($log->surgical_time); ?> minute(s)</td>
        </tr>
        <tr>
            <td class="firstcol">Blood loss</td>
            <td><?php echo e($log->blood_loss); ?> ml</td>
        </tr>
        <tr>
            <td class="firstcol">DOA </td>
            <td><?php echo e(!is_null($log->doa) ? $log->doa->format('d-m-Y'):null); ?></td>
        </tr>
        <tr>
            <td class="firstcol">DOO</td>
            <td><?php echo e(!is_null($log->doo) ? $log->doo->format('d-m-Y'):null); ?></td>
        </tr>
        <tr>
            <td class="firstcol">DOD</td>
            <td><?php echo e(!is_null($log->dod) ? $log->dod->format('d-m-Y'):null); ?></td>
        </tr>
        <tr>
            <td class="firstcol">Post op course</td>
            <td><?php echo e($log->postopcourses); ?><br><?php echo e($log->postopcourses_other); ?></td>
        </tr>

    </table>
</div><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/ortholog/logs/cf/view.blade.php ENDPATH**/ ?>