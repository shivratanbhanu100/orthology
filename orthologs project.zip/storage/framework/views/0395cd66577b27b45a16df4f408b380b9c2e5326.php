<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="foreachtr">
    <td>
        <?php if($user->id!=\Auth::user()->id): ?>
            <div class="custom-control custom-checkbox">
            <input type="checkbox"  name='ids[]' class="idcheckbox custom-control-input idcheckbox" id="customCheck<?php echo e($user->id); ?>" value="<?php echo e($user->id); ?>" name='ids[]'>
            <label class="custom-control-label" for="customCheck<?php echo e($user->id); ?>">&nbsp;</label>
            </div>
        <?php endif; ?>
    </td>
    <td><?php echo e($user->name); ?></td>
    <td><a href="/user/<?php echo e($user->id); ?>/view"><?php echo e($user->email); ?></a></td>
    <td><?php echo e($user->role); ?></td>
    <td><?php echo e($user->created_at->format('dS M, Y')); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/cpenter1/orthologs.oxygentimes.com/resources/views/hospital/users/list.blade.php ENDPATH**/ ?>