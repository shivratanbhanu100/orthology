<?php

use Illuminate\Database\Seeder;
use \App\OswestryQuestion;
use \App\OswestryOption;
use \Carbon\Carbon;

class OswestryQuestionTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $id1=OswestryQuestion::create([
            'question'=>"Section 1 – Pain intensity"
        ])->id;
        $id2=OswestryQuestion::create([
            'question'=>"Section 2 – Personal care (washing, dressing etc) "
        ])->id;
        $id3=OswestryQuestion::create([
            'question'=>"Section 3 – Lifting "
        ])->id;
        $id4=OswestryQuestion::create([
            'question'=>"Section 4 – Walking*"
        ])->id;
        $id5=OswestryQuestion::create([
            'question'=>"Section 5 – Sitting"
        ])->id;
        $id6=OswestryQuestion::create([
            'question'=>"Section 6 – Standing"
        ])->id;
        $id7=OswestryQuestion::create([
            'question'=>"Section 7 – Sleeping"
        ])->id;
        $id8=OswestryQuestion::create([
            'question'=>"Section 8 – Sex life (if applicable)"
        ])->id;
        $id9=OswestryQuestion::create([
            'question'=>"Section 9 – Social life"
        ])->id;
        $id10=OswestryQuestion::create([
            'question'=>"Section 10 – Travelling"
        ])->id;
        DB::table('oswestry_options')->insert([
            [
                'oswestry_question_id'=>$id1,
                'option'=>"I have no pain at the moment",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id1,
                'option'=>"The pain is very mild at the moment",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id1,
                'option'=>"The pain is moderate at the moment",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id1,
                'option'=>"The pain is fairly severe at the moment",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id1,
                'option'=>"The pain is very severe at the moment",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id1,
                'option'=>"The pain is the worst imaginable at the moment",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 2nd
            [
                'oswestry_question_id'=>$id2,
                'option'=>"I can look after myself normally without causing extra pain",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id2,
                'option'=>"I can look after myself normally but it causes extra pain",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id2,
                'option'=>"It is painful to look after myself and I am slow and careful",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id2,
                'option'=>"I need some help but manage most of my personal care",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id2,
                'option'=>"I need help every day in most aspects of self-care",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id2,
                'option'=>"I do not get dressed, I wash with difficulty and stay in bed",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 3nd
            [
                'oswestry_question_id'=>$id3,
                'option'=>"I can lift heavy weights without extra pain",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id3,
                'option'=>"I can lift heavy weights but it gives extra pain",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id3,
                'option'=>"Pain prevents me from lifting heavy weights off the floor, but I can manage if they are conveniently placed eg. on a table",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id3,
                'option'=>"Pain prevents me from lifting heavy weights, but I can manage light to medium weights if they are conveniently positioned",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id3,
                'option'=>"I can lift very light weights",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id3,
                'option'=>"I cannot lift or carry anything at all",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 4th
            [
                'oswestry_question_id'=>$id4,
                'option'=>"Pain does not prevent me walking any distance",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id4,
                'option'=>"Pain prevents me from walking more than 1 mile",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id4,
                'option'=>"Pain prevents me from walking more than 1/2 mile",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id4,
                'option'=>"Pain prevents me from walking more than 100 yards",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id4,
                'option'=>"I can only walk using a stick or crutches",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id4,
                'option'=>"I am in bed most of the time",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 5th
            [
                'oswestry_question_id'=>$id5,
                'option'=>"I can sit in any chair as long as I like",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id5,
                'option'=>"I can only sit in my favourite chair as long as I like",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id5,
                'option'=>"Pain prevents me sitting more than one hour",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id5,
                'option'=>"Pain prevents me from sitting more than 30 minutes",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id5,
                'option'=>"Pain prevents me from sitting more than 10 minutes",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id5,
                'option'=>"Pain prevents me from sitting at all",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 6th
            [
                'oswestry_question_id'=>$id6,
                'option'=>"I can stand as long as I want without extra pain",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id6,
                'option'=>"I can stand as long as I want but it gives me extra pain",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id6,
                'option'=>"Pain prevents me from standing for more than 1 hour",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id6,
                'option'=>"Pain prevents me from standing for more than 30 minutes ",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id6,
                'option'=>"Pain prevents me from standing for more than 10 minutes",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id6,
                'option'=>"Pain prevents me from standing at all",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 7th
            [
                'oswestry_question_id'=>$id7,
                'option'=>"My sleep is never disturbed by pain",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id7,
                'option'=>"My sleep is occasionally disturbed by pain",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id7,
                'option'=>"Because of pain I have less than 6 hours sleep",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id7,
                'option'=>"Because of pain I have less than 4 hours sleep",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id7,
                'option'=>"Because of pain I have less than 2 hours sleep",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id7,
                'option'=>"Pain prevents me from sleeping at all ",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 8th
            [
                'oswestry_question_id'=>$id8,
                'option'=>"My sex life is normal and causes no extra pain",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id8,
                'option'=>"My sex life is normal but causes some extra pain",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id8,
                'option'=>"My sex life is nearly normal but is very painful",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id8,
                'option'=>"My sex life is severely restricted by pain",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id8,
                'option'=>"My sex life is nearly absent because of pain",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id8,
                'option'=>"Pain prevents any sex life at all",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 9th
            [
                'oswestry_question_id'=>$id9,
                'option'=>"My social life is normal and gives me no extra pain",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id9,
                'option'=>"My social life is normal but increases the degree of pain",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id9,
                'option'=>"Pain has no significant effect on my social life apart from limiting my more energetic interests eg, sport",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id9,
                'option'=>"Pain has restricted my social life and I do not go out as often",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id9,
                'option'=>"Pain has restricted my social life to my home",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id9,
                'option'=>"I have no social life because of pain",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 10th
            [
                'oswestry_question_id'=>$id10,
                'option'=>"I can travel anywhere without pain",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id10,
                'option'=>"I can travel anywhere but it gives me extra pain",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id10,
                'option'=>"Pain is bad but I manage journeys over two hours",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id10,
                'option'=>"Pain restricts me to journeys of less than one hour",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id10,
                'option'=>"Pain restricts me to short necessary journeys under 30 minutes",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'oswestry_question_id'=>$id10,
                'option'=>"Pain prevents me from travelling except to receive treatment",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
