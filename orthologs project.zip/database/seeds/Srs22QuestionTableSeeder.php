<?php

use Illuminate\Database\Seeder;
use \App\Srs22Question;
use \App\Srs22Option;
use \Carbon\Carbon;

class Srs22QuestionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $id1=Srs22Question::create([
            'question'=>"Which one of the following best describes the amount of pain you have experienced during the past 6 months?",
            'question_category'=>"Pain"
        ])->id;
        $id2=Srs22Question::create([
            'question'=>"Which one of the following best describes the amount of pain you have experienced over the last month?",
            'question_category'=>"Pain"
        ])->id;
        $id3=Srs22Question::create([
            'question'=>"During the past 6 months have you been a very nervous person?",
            'question_category'=>"Mental health"
        ])->id;
        $id4=Srs22Question::create([
            'question'=>"If you had to spend the rest of your life with your back shape as it is right now, how would you feel about it?",
            'question_category'=>"Self image"
        ])->id;
        $id5=Srs22Question::create([
            'question'=>"What is your current level of activity?",
            'question_category'=>"Function"
        ])->id;
        $id6=Srs22Question::create([
            'question'=>"How do you look in clothes?",
            'question_category'=>"Self image"
        ])->id;
        $id7=Srs22Question::create([
            'question'=>"In the past 6 months have you felt so down in the dumps that nothing could cheer you up?",
            'question_category'=>"Mental health"
        ])->id;
        $id8=Srs22Question::create([
            'question'=>"Do you experience back pain when at rest?",
            'question_category'=>"Pain"
        ])->id;
        $id9=Srs22Question::create([
            'question'=>"What is your current level of work/school activity?",
            'question_category'=>"Function"
        ])->id;
        $id10=Srs22Question::create([
            'question'=>"Which of the following best describes the appearance of your trunk; defined as the human body except for the head and extremities?",
            'question_category'=>"Self image"
        ])->id;
        $id11=Srs22Question::create([
            'question'=>"Which one of the following best describes your pain medication use for back pain?",
            'question_category'=>"Pain"
        ])->id;
        $id12=Srs22Question::create([
            'question'=>"Does your back limit your ability to do things around the house?",
            'question_category'=>"Function"
        ])->id;
        $id13=Srs22Question::create([
            'question'=>"Have you felt calm and peaceful during the past 6 months?",
            'question_category'=>"Mental health"
        ])->id;
        $id14=Srs22Question::create([
            'question'=>"Do you feel that your back condition affects your personal relationships?",
            'question_category'=>"Self image"
        ])->id;
        $id15=Srs22Question::create([
            'question'=>"Are you and/or your family experiencing financial difficulties because of your back?",
            'question_category'=>"Function"
        ])->id;
        $id16=Srs22Question::create([
            'question'=>"In the past 6 months have you felt down hearted and blue?",
            'question_category'=>"Mental health"
        ])->id;
        $id17=Srs22Question::create([
            'question'=>"In the last 3 months have you taken any days off of work, including household work, or school because of back pain?",
            'question_category'=>"Pain"
        ])->id;
        $id18=Srs22Question::create([
            'question'=>"Does your back condition limit your going out with friends/family?",
            'question_category'=>"Function"
        ])->id;
        $id19=Srs22Question::create([
            'question'=>"Do you feel attractive with your current back condition?",
            'question_category'=>"Self image"
        ])->id;
        $id20=Srs22Question::create([
            'question'=>"Have you been a happy person during the past 6 months?",
            'question_category'=>"Mental health"
        ])->id;
        $id21=Srs22Question::create([
            'question'=>"Are you satisfied with the results of your back management?",
            'question_category'=>"Satisfaction/Dissatisfaction with management"
        ])->id;
        $id22=Srs22Question::create([
            'question'=>"Would you have the same management again if you had the same condition?",
            'question_category'=>"Satisfaction/Dissatisfaction with management"
        ])->id;
        DB::table('srs22_options')->insert([
            [
                'srs22_question_id'=>$id1,
                'option'=>"None",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id1,
                'option'=>"Mild",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id1,
                'option'=>"Moderate",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id1,
                'option'=>"Moderate to severe",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id1,
                'option'=>"Severe",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 2nd
            [
                'srs22_question_id'=>$id2,
                'option'=>"None",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id2,
                'option'=>"Mild",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id2,
                'option'=>"Moderate",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id2,
                'option'=>"Moderate to severe",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id2,
                'option'=>"Severe",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 3nd
            [
                'srs22_question_id'=>$id3,
                'option'=>"None of the time",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id3,
                'option'=>"A little of the time",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id3,
                'option'=>"Some of the time",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id3,
                'option'=>"Most of the time",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id3,
                'option'=>"All of the time",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 4th
            [
                'srs22_question_id'=>$id4,
                'option'=>"Very happy",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id4,
                'option'=>"Somewhat happy",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id4,
                'option'=>"Neither happy nor unhappy",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id4,
                'option'=>"Somewhat unhappy",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id4,
                'option'=>"Very unhappy",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 5th
            [
                'srs22_question_id'=>$id5,
                'option'=>"Bedridden",
                'score'=>1,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id5,
                'option'=>"Primarily no activity",
                'score'=>2,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id5,
                'option'=>"Light labor and light sports",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id5,
                'option'=>"Moderate labor and moderate sports",
                'score'=>4,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id5,
                'option'=>"Full activities without restriction",
                'score'=>5,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 6th
            [
                'srs22_question_id'=>$id6,
                'option'=>"Very good",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id6,
                'option'=>"Good",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id6,
                'option'=>"Fair",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id6,
                'option'=>"Bad",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id6,
                'option'=>"Very bad",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 7th
            [
                'srs22_question_id'=>$id7,
                'option'=>"Very often",
                'score'=>1,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id7,
                'option'=>"Often",
                'score'=>2,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id7,
                'option'=>"Sometimes",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id7,
                'option'=>"Rarely",
                'score'=>4,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id7,
                'option'=>"Never",
                'score'=>5,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 8th
            [
                'srs22_question_id'=>$id8,
                'option'=>"Very often",
                'score'=>1,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id8,
                'option'=>"Often",
                'score'=>2,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id8,
                'option'=>"Sometimes",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id8,
                'option'=>"Rarely",
                'score'=>4,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id8,
                'option'=>"Never",
                'score'=>5,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 9th
            [
                'srs22_question_id'=>$id9,
                'option'=>"100% normal",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id9,
                'option'=>"75% normal",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id9,
                'option'=>"50% normal",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id9,
                'option'=>"25% normal",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id9,
                'option'=>"0% normal",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 10th
            [
                'srs22_question_id'=>$id10,
                'option'=>"Very good",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id10,
                'option'=>"Good",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id10,
                'option'=>"Fair",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id10,
                'option'=>"Poor",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id10,
                'option'=>"Very Poor",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 11th
            [
                'srs22_question_id'=>$id11,
                'option'=>"None",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id11,
                'option'=>"Non-narcotics weekly or less (e.g., aspirin, Tylenol, Ibuprofen)",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id11,
                'option'=>"Non-narcotics daily",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id11,
                'option'=>"Narcotics weekly or less (e.g. Tylenol III, Lorcet, Percocet)",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id11,
                'option'=>"Narcotics daily",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 12th
            [
                'srs22_question_id'=>$id12,
                'option'=>"Never",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id12,
                'option'=>"Rarely",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id12,
                'option'=>"Sometimes",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id12,
                'option'=>"Often",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id12,
                'option'=>"Very Often",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 13th
            [
                'srs22_question_id'=>$id13,
                'option'=>"All of the time",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id13,
                'option'=>"Most of the time",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id13,
                'option'=>"Some of the time",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id13,
                'option'=>"A little of the time",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id13,
                'option'=>"None of the time",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 14th
            [
                'srs22_question_id'=>$id14,
                'option'=>"None",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id14,
                'option'=>"Slightly",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id14,
                'option'=>"Mildly",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id14,
                'option'=>"Moderately",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id14,
                'option'=>"Severely",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 15th
            [
                'srs22_question_id'=>$id15,
                'option'=>"Severely",
                'score'=>1,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id15,
                'option'=>"Moderately",
                'score'=>2,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id15,
                'option'=>"Mildly",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id15,
                'option'=>"Slightly",
                'score'=>4,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id15,
                'option'=>"None",
                'score'=>5,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 16th
            [
                'srs22_question_id'=>$id16,
                'option'=>"Never",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id16,
                'option'=>"Rarely",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id16,
                'option'=>"Sometimes",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id16,
                'option'=>"Often",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id16,
                'option'=>"Very often",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 17th
            [
                'srs22_question_id'=>$id17,
                'option'=>"0 days",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id17,
                'option'=>"1 days",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id17,
                'option'=>"2 days",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id17,
                'option'=>"3 days",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id17,
                'option'=>"4 or more days",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 18th
            [
                'srs22_question_id'=>$id18,
                'option'=>"Never",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id18,
                'option'=>"Rarely",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id18,
                'option'=>"Sometimes",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id18,
                'option'=>"Often",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id18,
                'option'=>"Very often",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 19th
            [
                'srs22_question_id'=>$id19,
                'option'=>"Yes, very",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id19,
                'option'=>"Yes, somewhat",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id19,
                'option'=>"Neither attractive nor unattractive",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id19,
                'option'=>"No, not very much",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id19,
                'option'=>"No, not at all",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 20th
            [
                'srs22_question_id'=>$id20,
                'option'=>"None of the time",
                'score'=>1,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id20,
                'option'=>"A little of the time",
                'score'=>2,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id20,
                'option'=>"Some of the time",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id20,
                'option'=>"Most of the time",
                'score'=>4,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id20,
                'option'=>"All of the time",
                'score'=>5,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 21st
            [
                'srs22_question_id'=>$id21,
                'option'=>"Very satisfied",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id21,
                'option'=>"Satisfied",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id21,
                'option'=>"Neither satisfied nor unsatisfied",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id21,
                'option'=>"Unsatisfied",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id21,
                'option'=>"Very unsatisfied",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 22nd
            [
                'srs22_question_id'=>$id22,
                'option'=>"Definitely yes",
                'score'=>5,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id22,
                'option'=>"Probably yes",
                'score'=>4,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id22,
                'option'=>"Not sure",
                'score'=>3,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id22,
                'option'=>"Probably not",
                'score'=>2,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'srs22_question_id'=>$id22,
                'option'=>"Definitely not",
                'score'=>1,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
