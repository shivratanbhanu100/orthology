<?php

use Illuminate\Database\Seeder;
use \App\JapaneseQuestion;
use \App\JapaneseOption;
use \Carbon\Carbon;

class JapaneseQuestionTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $id1=JapaneseQuestion::create([
            'question'=>"Motor dysfunction score of the upper extremity"
        ])->id;
        $id2=JapaneseQuestion::create([
            'question'=>"Motor dysfunction score of the lower extremity"
        ])->id;
        $id3=JapaneseQuestion::create([
            'question'=>"Sensory dysfunction score of the upper extremities"
        ])->id;
        $id4=JapaneseQuestion::create([
            'question'=>"Sphincter dysfunction score"
        ])->id;
        DB::table('japanese_options')->insert([
            [
                'japanese_question_id'=>$id1,
                'option'=>"0 — Inability to move hands",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id1,
                'option'=>"1 — Inability to eat w/a spoon, but able to move hands",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id1,
                'option'=>"2 — Inability to button shirt, but able to eat w/a spoon",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id1,
                'option'=>"3 — Able to button shirt w/great difficulty",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id1,
                'option'=>"4 — Able to button shirt w/slight difficulty",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id1,
                'option'=>"5 — No dysfunction",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 2nd
            [
                'japanese_question_id'=>$id2,
                'option'=>"0—Complete loss of motor and sensory function",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id2,
                'option'=>"1—Sensory preservation w/o ability to move legs",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id2,
                'option'=>"2—Able to move legs, but unable to walk",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id2,
                'option'=>"3—Able to walk on flat floor w/a walking aid (cane or crutch)",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id2,
                'option'=>"4—Able to walk up and/or down stairs w/hand rail",
                'score'=>4,
                'sequence'=>5,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id2,
                'option'=>"5—Moderate-to-significant lack of stability, but able to walk up and/or down stairs w/o hand rail",
                'score'=>5,
                'sequence'=>6,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id2,
                'option'=>"6—Mild lack of stability but walks w/smooth reciprocation unaided/",
                'score'=>6,
                'sequence'=>7,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 3nd
            [
                'japanese_question_id'=>$id3,
                'option'=>"0 — Complete loss of hand sensation",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id3,
                'option'=>"1 — Severe sensory loss or pain",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id3,
                'option'=>"2 — Mild sensory loss",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id3,
                'option'=>"3 — No sensory loss",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            // 4th
            [
                'japanese_question_id'=>$id4,
                'option'=>"0 — Inability to micturate voluntarily",
                'score'=>0,
                'sequence'=>1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id4,
                'option'=>"1 — Marked difficulty w/micturition",
                'score'=>1,
                'sequence'=>2,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id4,
                'option'=>"2 — Mild to moderate difficulty w/micturition",
                'score'=>2,
                'sequence'=>3,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'japanese_question_id'=>$id4,
                'option'=>"3 — Normal micturition",
                'score'=>3,
                'sequence'=>4,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
