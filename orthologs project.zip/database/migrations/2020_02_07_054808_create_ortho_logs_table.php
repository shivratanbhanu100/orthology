<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrthoLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ortho_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('patient_id');
            $table->string('category');
            $table->string('trauma_site')->nullable();
            $table->string('infection_type')->nullable();
            $table->string('tb_mdr')->nullable();
            $table->string('tb_hpe')->nullable();
            $table->string('tb_gene')->nullable();
            $table->string('tb_cs')->nullable();
            $table->string('tb_culture')->nullable();
            $table->string('tb_pyogenic_bacteria')->nullable();
            $table->string('tb_pyogenic_antibiotic')->nullable();
            $table->string('infection_site')->nullable();
            $table->string('scoliosis_type')->nullable();
            $table->string('winter_classification')->nullable();
            $table->string('winter_classification_failure_formation')->nullable();
            $table->string('winter_classification_failure_of_segmentation')->nullable();
            $table->string('deformity_type')->nullable();
            $table->string('kyphosis_type')->nullable();
            $table->string('kyphosis_angle')->nullable();
            $table->string('sagital_shift')->nullable();
            $table->string('kyphosis_pi')->nullable();
            $table->string('kyphosis_pt')->nullable();
            $table->string('kyphosis_ss')->nullable();
            $table->string('kyphosis_tk')->nullable();
            $table->string('kyphosis_ll')->nullable();
            $table->string('degenerative_site')->nullable();
            $table->string('imagefinding')->nullable();
            $table->string('imagefinding_other')->nullable();
            $table->string('lumbar_pi')->nullable();
            $table->string('lumbar_pt')->nullable();
            $table->string('lumbar_ss')->nullable();
            $table->string('lumbar_tk')->nullable();
            $table->string('lumbar_ll')->nullable();
            $table->string('cervicalimagefinding')->nullable();
            $table->string('cervicalimagefinding_other')->nullable();
            $table->string('tumour_type')->nullable();
            // cf 
            $table->string('operative_details')->nullable();
            $table->string('diagnosis')->nullable();
            $table->string('level')->nullable();
            $table->string('treatment_procedure')->nullable();
            $table->string('comorbidities')->nullable();
            $table->string('surgeons')->nullable();
            $table->text('implant')->nullable();
            $table->integer('surgical_time')->nullable();
            $table->string('blood_loss')->nullable();
            $table->date('doa')->nullable();
            $table->date('doo')->nullable();
            $table->date('dod')->nullable();
            $table->string('postopcourses')->nullable();
            $table->string('postopcourses_other')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ortho_logs');
    }
}
