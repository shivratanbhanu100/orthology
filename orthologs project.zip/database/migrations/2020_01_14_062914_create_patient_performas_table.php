<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientPerformasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_performas', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->date('date');
            $table->integer('user_id');
            $table->integer('stage');
            $table->integer('patient_id');
            $table->string('scoliosis_type')->nullable();
            $table->string('skin')->nullable();
            $table->string('shoulder_level_difference')->nullable();
            $table->string('rib_hump')->nullable();
            $table->decimal('arm_span',8,1)->nullable();
            $table->decimal('sitting_height',8,1)->nullable();
            $table->decimal('limb_length',8,1)->nullable();
            $table->string('motor_dtr')->nullable();
            $table->string('sensory')->nullable();
            $table->string('autonomic')->nullable();
            $table->string('associated_anomalies')->nullable();
            $table->string('lenke_classification')->nullable();
            $table->string('winters_classification')->nullable();
            $table->string('failure_formation')->nullable();
            $table->string('failure_of_segmentation')->nullable();
            $table->string('apex')->nullable();
            $table->decimal('apical_vertical_translation',8,1)->nullable();
            $table->string('apical_rotation')->nullable();
            $table->string('upper_lower_end_vertebra')->nullable();
            $table->decimal('cobb_angle',8,1)->nullable();
            $table->decimal('bending_cobb',8,1)->nullable();
            $table->string('secondary_apex')->nullable();
            $table->string('secondary_apical_vertical_translation',8,1)->nullable();
            $table->string('secondary_apical_rotation')->nullable();
            $table->string('secondary_upper_lower_end_vertebra')->nullable();
            $table->decimal('secondary_cobb_angle',8,1)->nullable();
            $table->decimal('secondary_bending_cobb',8,1)->nullable();
            $table->decimal('trunk_shift', 8,1)->nullable();
            $table->decimal('thoracic_kyphosis', 8,1)->nullable();
            $table->decimal('lumbar_lordosis', 8,1)->nullable();
            $table->decimal('sagittal_shift', 8,1)->nullable();
            $table->decimal('pelvic_tilt', 8,1)->nullable();
            $table->decimal('pelvic_incidence', 8,1)->nullable();
            $table->decimal('sacral_slope', 8,1)->nullable();
            $table->decimal('radiographic_shoulder_height', 8,1)->nullable();
            $table->decimal('psa', 8,1)->nullable();
            $table->string('post_operative_findings')->nullable();
            $table->string('screw_loosening_breakage')->nullable();
            $table->string('mri_findings')->nullable();
            $table->string('mri_findings_other')->nullable();
            $table->text('neurosurgical_procedure')->nullable();
            $table->decimal('functional_score', 8,1)->nullable();
            $table->decimal('self_image', 8,1)->nullable();
            $table->decimal('mental_health', 8,1)->nullable();
            $table->decimal('pain', 8,1)->nullable();
            $table->decimal('satisfaction_with_management', 8,1)->nullable();
            $table->decimal('functional_mean', 8,1)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_performas');
    }
}
