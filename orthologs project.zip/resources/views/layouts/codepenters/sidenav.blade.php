<nav class="sidebar">
  <div class="stickynav">
    <ul>
      <li>

        <?php
          $navtext='Modules';
        ?>
        <a class="nav-link active" href="/codepenters/modules">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-chart-bar"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
        </a>
      </li>

      <li class="position-relative menuparent">
        <a class="nav-link" href="javascript:void(0)">
        <?php
          $navtext='Products';
        ?>
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-user-circle"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
          <span class="dropdownicon fas fa-chevron-circle-right position-absolute"></span>
        </a>
      </li>

      <ul class="submenu" status="hidden">
        <li>
          <a class="nav-link" href="javascript:void(0)">
            <span class="navtext">Archive</span>
          </a>
        </li>
        <li>
          <a class="nav-link" href="javascript:void(0)">
            <span class="navtext">Balance scale</span>
          </a>
        </li>
        <li>
          <a class="nav-link" href="javascript:void(0)">
            <span class="navtext">Calendar</span>
          </a>
        </li>
      </ul>


      <li>
        <?php
          $navtext='Contact';
        ?>
        <a class="nav-link" href="javascript:void(0)">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-lightbulb"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
          <span class="badge badge-info">New</span>
        </a>
      </li>


      <li>
        <?php
          $navtext='Transactions';
        ?>
        <a class="nav-link" href="javascript:void(0)">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-address-card"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
          <span class="badge badge-warning">Over</span>
        </a>

      </li>

    </ul>

    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
      <span>Saved reports</span>
      <a class="d-flex align-items-center text-muted" href="#">
      </a>
    </h6>

    <ul>

      <li>
        <?php
          $navtext='Reports';
        ?>
        <a class="nav-link" href="javascript:void(0)">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-list-alt"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
          <span class="badge badge-danger">Low</span>
        </a>
      </li>

      <li>
        <?php
          $navtext='Last quarter';
        ?>
        <a class="nav-link" href="javascript:void(0)">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-life-ring"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
        </a>

      </li>

      <li>
        <?php
          $navtext='Social engagement';
        ?>
        <a class="nav-link" href="javascript:void(0)">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-building"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
        </a>

      </li>

      <li>
        <?php
          $navtext='Year-end sale';
        ?>
        <a class="nav-link" href="javascript:void(0)">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-hdd"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
        </a>
      </li>


    </ul>

    <div class="navtogglediv border-top border-right">
      <button type="button" class="btn-sm btn btn-outline-secondary navtoggle" name="button" status="expanded">
        <i class="fas fa-chevron-left"></i>
      </button>
    </div>
  </div>
</nav>
