<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="Codepenters">

      <meta name="csrf-token" content="{{ csrf_token() }}">

      <link rel="icon" href="../../../../favicon.ico">

        <title>VAE: PGI Chandigarh</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">

        <!-- Stylesheets -->
        <link rel="stylesheet" href="/css/app.css">
        <link rel="stylesheet" href="/css/style.css?v=032020">
        <link rel='shortcut icon' href='/images/favicon.ico' type='image/x-icon'>

    </head>
    <body>

    @include ('layouts.flash_msg')



    @include ('layouts.analyst.nav')

      <div class="container-fluid">
         <div class="row">

          @include ('layouts.analyst.sidenav')

          @yield ('entrysidebar')

          <main role="main" class="col ml-sm-auto p-0 maindiv">

            <div class="fixedheader fixed-top border-bottom">
              @yield ('fixedheadercontent')
            </div>
              <div class="main-container">
                @yield ('headercontent')
              </div>


          @yield ('tablecontent')

        </main>
      </div>
    </div>

    <script type="text/javascript"  src="/js/app.js"></script>
    <script src="/js/main.js?v=032020"></script>
    <script src="/js/exportcsv.js"></script>

    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js" integrity="sha384-kW+oWsYx3YpxvjtZjFXqazFpA7UP/MbiY4jvs+RWZo2+N94PFZ36T6TFkc9O3qoB" crossorigin="anonymous"></script>



    {{-- Datepicker files============================= --}}
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker3.standalone.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker3.standalone.min.css.map" />
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/locales/bootstrap-datepicker.en-GB.min.js"></script>

</body>

</html>
