<nav class="sidebar">
  <div class="stickynav">
    <ul>

      <li>

        @php ($navtext='Submitted Forms')

        <a class="nav-link {{$page=="crf"?'active':null}}" href="/analyst/crf">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-tachometer-alt"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
        </a>
      </li>
      <li>

       @php ($navtext='Analytics')

       <a class="nav-link {{$page=="analytics"?'active':null}}" href="/analyst">
         <span class="tool" data-toggle="tooltip" data-placement="right" title="Raw Data">
         <span class="fas fa-arrow-alt-circle-down"></span>
         </span>
         <span class="navtext">Raw Data</span>
       </a>
      </li>
      <li>

        @php ($navtext='Change Password')
        <a class="nav-link" href="#"  data-toggle="modal" data-target="#changepassword">
          <span class="tool" data-toggle="tooltip" data-placement="right" title="{{$navtext}}">
            <span class="fas fa-key"></span>
          </span>
          <span class="navtext">{{$navtext}}</span>
        </a>

      </li>
    </ul>
      <div class="navtogglediv border-top border-right">
        <button type="button" class="btn-sm btn btn-outline-secondary navtoggle" name="button" status="expanded">
          <i class="fas fa-chevron-left"></i>
        </button>
      </div>
    </div>

</nav>
<!-- change password modal -->
<div class="modal fade change passwordmodal" id="changepassword" tabindex="-1" role="dialog" aria-labelledby="changepasswordModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/updatepassword" method="POST" class="changepasswordform">
        <div class="modal-body">
            @csrf
            <label for="password">New Password</label>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-keyboard"></i></span>
              </div>
              <input type="password" class="form-control userpassword" name="password" placeholder="New Password">
            </div>
            <label for="password">Retype Password</label>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-keyboard"></i></span>
              </div>
              <input type="password" class="form-control retypeuserpassword" name="retypepassword" placeholder="Retype Password">
            </div>
            <span class="passwordmsg redcolor"></span>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- change password modal end -->
