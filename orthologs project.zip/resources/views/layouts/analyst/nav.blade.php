<nav class="navbar sticky-top flex-md-nowrap p-0 box-shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="/">
    <img src="/images/autopenters-logo.png" alt="Logo">
  </a>
  <ul class="navbar-nav px-3">
    <li class="nav-item text-nowrap">
      <!--<a class="nav-link" href="/analyst"><span class="fas fa-tachometer-alt"></span> Home</a>-->
      <a class="nav-link" href="javascript:void(0)"><i class="fas fa-user"></i> {{\Auth::user()->name}}</a>
      <a class="nav-link" href="javascript:void(0)" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="fas fa-power-off"></i> Logout
      </a>
    </li>
  </ul>
</nav>

<form id="logout-form" class="d-none" action="/logout" method="POST">
  {{ csrf_field() }}
</form>
