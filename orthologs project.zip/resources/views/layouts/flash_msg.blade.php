@if(Session::has('flash_message'))

     <div class="col-lg-12 flash_msg" >

         <div class="alert alert-success"> {!! session('flash_message') !!}

           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>

         </div>

     </div>

 @endif
 
 @if(Session::has('redflash_message'))

     <div class="col-lg-12 flash_msg" >

         <div class="alert alert-danger"> {!! session('redflash_message') !!}

           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>

         </div>

     </div>

 @endif
