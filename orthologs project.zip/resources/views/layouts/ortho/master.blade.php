<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="Codepenters">

      <meta name="csrf-token" content="{{ csrf_token() }}">

      <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
      <link rel="icon" href="/favicon.ico" type="image/x-icon">

        <title>Orthologs</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">

        <!-- Stylesheets -->
        <link rel="stylesheet" href="/css/app.css">
        <link rel="stylesheet" href="/css/style.css?v=032020">
        <script src="http://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>

        <script src="http://cdnjs.cloudflare.com/ajax/libs/highcharts/6.0.6/highcharts.js" charset="utf-8"></script>

        <script src="http://cdn.jsdelivr.net/npm/fusioncharts@3.12.2/fusioncharts.js" charset="utf-8"></script>

        <script src="http://cdnjs.cloudflare.com/ajax/libs/echarts/4.0.2/echarts-en.min.js" charset="utf-8"></script>

        <script src="http://cdn.jsdelivr.net/npm/frappe-charts@1.1.0/dist/frappe-charts.min.iife.js"></script>

        <script src="http://cdnjs.cloudflare.com/ajax/libs/d3/5.7.0/d3.min.js"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/c3/0.6.7/c3.min.js"></script>
    </head>
    <body>

    @include ('layouts.flash_msg')



    @include ('layouts.ortho.nav')

      <div class="container-fluid">
         <div class="row">

          @include ('layouts.ortho.sidenav')

          @yield ('entrysidebar')

          <main role="main" class="col ml-sm-auto p-0 maindiv">

            <div class="fixedheader fixed-top border-bottom">
              @yield ('fixedheadercontent')
            </div>
              <div class="main-container">
                @yield ('headercontent')
              </div>


          @yield ('tablecontent')

        </main>
      </div>
    </div>

    <script type="text/javascript"  src="/js/app.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js" integrity="sha384-kW+oWsYx3YpxvjtZjFXqazFpA7UP/MbiY4jvs+RWZo2+N94PFZ36T6TFkc9O3qoB" crossorigin="anonymous"></script>



    {{-- Datepicker files============================= --}}
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker3.standalone.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker3.standalone.min.css.map" />
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/locales/bootstrap-datepicker.en-GB.min.js"></script>

    <script src="/js/main.js?v=032020?v=03052019"></script>
    <script src="/js/exportcsv.js"></script>
    <script>
    $("td").each(function(){
      if(this.innerHTML.trim()=='degree' || this.innerHTML.trim()=='minute(s)' || this.innerText.trim()=='ml'){
        this.innerHTML="";
      }
    });
    </script>  

</body>

</html>
