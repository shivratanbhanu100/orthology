@extends('layouts.hospital.master')

@section('fixedheadercontent')

  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">

      <h1 class="h2">Patient records</h1>

      <a href="/scoliosis/patient/new" class="btn btn-sm btn-success ml-2">
        <i class="fas fa-plus"></i>
        New Patient
      </a>

    </div>

    <div class="form-inline">

      <div class="input-group input-group-sm mr-2 searchdiv">
        <div class="input-group-prepend border-right-0">
          <span class="input-group-text" id="inputGroup-sizing-sm">
            <i class="fas fa-search"></i>
          </span>
        </div>
        <input type="text" class="form-control searchbox extendbox superadminsearchbar" placeholder="Search" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
      </div>

      <!-- <div class="btn-group btn-group-sm" role="group">
        <a class="exportbutton btn btn-outline-secondary" exportfilename="exportfilename" data-toggle="tooltip" data-placement="bottom" title="Export">
          <i class="fas fa-download"></i>
        </a>
      </div> -->

      <button type="button" class="btn btn-sm btn-danger ml-2 patientrecorddeletebutton dispnone">
        <i class="fas fa-trash-alt"></i> Delete
      </button>

    </div>

  </div>

@endsection


@section('headercontent')

@endsection


@section('tablecontent')
  <!--table starts here-->
  
  <div class="table-responsive">
    <table class="table table-hover table-export">
      <thead>
        <tr class="active">
          <th>
            <div class="custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input selectall" id="selectallcheckbox" value="0" name='ids[]'>
              <label class="custom-control-label" for="selectallcheckbox">&nbsp;</label>
            </div>
          </th>
          <th>Name</th>
          <th>Age</th>
          <th>Sex</th>
          <th>UHID</th>
          <th></th>
          <th>Preop</th>
          <th>Postop</th>
          <th>F/U 1</th>
          <th>F/U 2</th>
        </tr>
      </thead>
      <tbody class="tbodycontainer">
          @include('hospital.patientrecord.list')
      </tbody>
    </table>
  </div>



@endsection
