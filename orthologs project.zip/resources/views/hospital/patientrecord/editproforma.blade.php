@extends('layouts.hospital.master')


@section('fixedheadercontent')

  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
      <h1 class="h2">Update Scoliosis Proforma</h1>
    </div>

    <div class="form-inline">
      <div class="btn-group btn-group-sm" role="group">
        <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
      </div>
    </div>

  </div>

@endsection
@section('headercontent')
  <div class="px-3 py-3">
    <form method="post" action="/editproforma" id='proformaform' class="form-horizontal">
    @csrf
    <input type="hidden" name="patient_id" value="{{$patient->id}}">
    <table class="table table-striped reportform formtable">
    <tr class="pointer togglepatientdetails">
        <th colspan="2" class="bg-dark text-white">1. PATIENT DETAILS  <i class="fas fa-arrow-circle-right"></i>  <i class="fas fa-arrow-circle-down dispnone"></i></th>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td class="firstcol">UHID:<span class="text-danger">*</span></td>
        <td>
        <div class="input-group">
            <!-- <div class="input-group-prepend"> -->
                <input type="text" value="{{$patient->uhid}}" class="form-control" name='uhid' aria-describedby="basic-addon1" required="required" oninvalid="" autocomplete="off"/>
            <!-- </div> -->
            <!-- <input type="button" value="Load details" class="btn btn-primary loadfornewuhid"> -->
        </div>
        </td>
    </tr>

    <tr class="patientdetailrows dispnone disableclass">
        <td class="firstcol">Patient Name</td>
        <td>
        <input type="text" value="{{$patient->name}}" class="form-control" aria-describedby="basic-addon1" name='patient_name' autocomplete="off"/>
        </td>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td>Gender<span class="text-danger">*</span></td>
        <td>
        <div class="input-group mb-3">
        <div class="custom-control custom-radio mb-3 mr-2">
            <input type="radio" class="custom-control-input sex" id="sex_1" value='Male' name='sex' required {{$patient->sex=="Male"?'checked':null}}>
            <label class="custom-control-label" for="sex_1">Male</label>
        </div>
        <div class="custom-control custom-radio mb-3 mr-2">
            <input type="radio" class="custom-control-input sex" id="sex_2" value='Female' name='sex' {{$patient->sex=="Female"?'checked':null}}>
            <label class="custom-control-label" for="sex_2">Female</label>
        </div>
        <div class="custom-control custom-radio mb-3 mr-2">
            <input type="radio" class="custom-control-input sex" id="sex_3" value='Others' name='sex' {{$patient->sex=="Others"?'checked':null}}>
            <label class="custom-control-label" for="sex_3">Others</label>
        </div>
        </div>
        </td>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td>Date of birth</td>
        <td>
            <div class="input-group mb-3 mr-4">
                <select class="form-control" name="dob_date" id="dob_date">
                    <option value="">DD</option>
                    @for ($i=1; $i <= 31; $i++) 
                        <option {{!is_null($patient->dob)?(sprintf('%02d', $i)==$patient->dob->format('d')?'selected':null):null}}>{{sprintf('%02d', $i)}}</option>
                    @endfor
                </select>
                <select class="form-control" name="dob_month" id="dob_month">
                    <option value="">MM</option>
                    @for ($i=1; $i <= 12; $i++) 
                        <option {{!is_null($patient->dob)?(sprintf('%02d', $i)==$patient->dob->format('m')?'selected':null):null}}>{{sprintf('%02d', $i)}}</option>
                    @endfor
                </select>
                <select class="form-control" name="dob_year" id="dob_year">
                    <option value="">YYYY</option>
                    @for ($i=date('Y'); $i > date('Y', strtotime(date('Y').'- 100 years')); $i--)
                        <option {{!is_null($patient->dob)?($i==$patient->dob->format('Y')?'selected':null):null}}>{{$i}}</option>
                    @endfor
                </select>
            </div>
        </td>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td>Age (Years)<span class="text-danger removestar">*</span></td>
        <td>
            <input type="number" value="{{$patient->age}}" class="form-control removerequired" name="age" id="age" required>
        </td>
    </tr>
    <tr class="patientdetailrows dispnone disableclass">
        <td>Diagnosis<span class="text-danger">*</span></td>
        <td>
            <textarea class="form-control" name="diagnosis" id="diagnosis" required>{{$patient->diagnosis}}</textarea>
        </td>
    </tr>
    @php($proforma=$patient->performa($stage))
    <tr>
      <th colspan="2" class="text-white bg-dark">2. CLINICAL DETAILS</th>
    </tr>
    <tr>
      <td class="firstcol">Stage<span class="text-danger">*</span></td>
      <td>
      <?php
        $currentstagename='';
        switch($stage){
            case 1:$currentstagename="Preoperative";
            break;
            case 2:$currentstagename="Post operative";
            break;
            case 3:$currentstagename="Postop F/U 1st visit – 1 month";
            break;
            case 4:$currentstagename="Postop F/U 2nd visit – 6 months";
            break;
            default:$currentstagename='No stage selected';
        }
        ?>
        <select class="form-control" name="stage" id="stage">
            <option value="{{$stage}}">{{$currentstagename}}</option>
        </select>
      </td>
    </tr>
    <tr>
        <td>Date of proforma<span class="text-danger">*</span></td>
        <td>
            <input type="text" value="{{$patient->proformaDate($stage)?$patient->proformaDate($stage)->date->format('d-m-Y'):null}}" id="date_of_proforma" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="date_of_proforma"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1" required="required"  oninvalid="" autocomplete="off"/>
        </td>
    </tr>
    <tr>
        <td>Scoliosis Type</td>
        <td>
            <select class="form-control" name="scoliosis_type" id="scoliosis_type">
                <option value="">Type</option>
                @foreach(orthologscoliosistype() as $scoliosistype)
                    <option value="{{$scoliosistype}}" {{$proforma->scoliosis_type==$scoliosistype?'selected':null}}>{{$scoliosistype}}</option>
                @endforeach
            </select>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Skin</td>
        <td>
            <input type="text" class="form-control" value="{{$proforma->skin}}" aria-describedby="basic-addon1" name='skin' autocomplete="off"/>
        </td>
    </tr>
    <tr>
      <td class="firstcol">Shoulder level difference</td>
      <td>
        <select class="form-control" name="shoulder_level_difference" id="shoulder_level_difference">
            <option value="">Select difference</option>
            <option value="Right up" {{$proforma->shoulder_level_difference=="Right up"?'selected':null}}>Right up</option>
            <option value="Left up" {{$proforma->shoulder_level_difference=="Left up"?'selected':null}}>Left up</option>
            <option value="Same" {{$proforma->shoulder_level_difference=="Same"?'selected':null}}>Same</option>
        </select>
      </td>
    </tr>
    <tr>
      <td class="firstcol">Rib Hump</td>
      <td>
        <select class="form-control" name="rib_hump" id="rib_hump">
            <option value="">Select</option>
            <option value="Left" {{$proforma->shoulder_level_difference=="Left"?'selected':null}}>Left</option>
            <option value="Right" {{$proforma->shoulder_level_difference=="Right"?'selected':null}}>Right</option>
        </select>
      </td>
    </tr>
    <tr>
        <td class="firstcol">Arm span</td>
        <td>
        <div class="input-group">
            <input type="number" value="{{$proforma->arm_span}}" class="form-control" step="any" name='arm_span' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
            <div class="input-group-append">
                <span class="input-group-text">cm</span>
            </div>
        </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Sitting height</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->sitting_height}}" class="form-control" step="any" name='sitting_height' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">cm</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Limb length R/L</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->limb_length}}" class="form-control" step="any" name='limb_length' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">cm</span>
                </div>
            </div>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark">3. NEUROLOGICAL STATUS</th>
    </tr>
    <tr>
        <td class="firstcol">Motor/DTR</td>
        <td>
            <input type="text" value="{{$proforma->motor_dtr}}" class="form-control" aria-describedby="basic-addon1" name='motor_dtr' autocomplete="off"/>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Sensory</td>
        <td>
            <input type="text" value="{{$proforma->sensory}}" class="form-control" aria-describedby="basic-addon1" name='sensory' autocomplete="off"/>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Autonomic</td>
        <td>
            <input type="text" value="{{$proforma->autonomic}}" class="form-control" aria-describedby="basic-addon1" name='autonomic' autocomplete="off"/>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark">4. SRS FUNCTIONAL SCORE</th>
    </tr>
    <tr>
        <td class="firstcol">Function<span class="text-danger">*</span></td>
        <td>
            <div class="input-group">
                <input type="number" class="form-control" value="{{$proforma->functional_score}}" min="0" max="5" step="any" name='functional_score' aria-describedby="basic-addon1" oninvalid="" autocomplete="off" required/>
                <div class="input-group-append">
                    <span class="input-group-text">/ 5</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Self image<span class="text-danger">*</span></td>
        <td>
            <div class="input-group">
                <input type="number" class="form-control" value="{{$proforma->self_image}}" min="0" max="5" step="any" name='self_image' aria-describedby="basic-addon1" oninvalid="" autocomplete="off" required/>
                <div class="input-group-append">
                    <span class="input-group-text">/ 5</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Mental health<span class="text-danger">*</span></td>
        <td>
            <div class="input-group">
                <input type="number" class="form-control" value="{{$proforma->mental_health}}" min="0" max="5" step="any" name='mental_health' aria-describedby="basic-addon1" oninvalid="" autocomplete="off" required/>
                <div class="input-group-append">
                    <span class="input-group-text">/ 5</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Pain<span class="text-danger">*</span></td>
        <td>
            <div class="input-group">
                <input type="number" class="form-control" value="{{$proforma->pain}}" min="0" max="5" step="any" name='pain' aria-describedby="basic-addon1" oninvalid="" autocomplete="off" required/>
                <div class="input-group-append">
                    <span class="input-group-text">/ 5</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Satisfaction/dissatisfaction with management<span class="text-danger">*</span></td>
        <td>
            <div class="input-group">
                <input type="number" class="form-control" value="{{$proforma->satisfaction_with_management}}" min="0" max="5" step="any" name='satisfaction_with_management' aria-describedby="basic-addon1" oninvalid="" autocomplete="off" required/>
                <div class="input-group-append">
                    <span class="input-group-text">/ 5</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Functional Mean<span class="text-danger">*</span></td>
        <td>
            <div class="input-group">
                <input type="number" class="form-control" value="{{$proforma->functional_mean}}" min="0" max="5" step="any" name='functional_mean' aria-describedby="basic-addon1" oninvalid="" autocomplete="off" required/>
                <div class="input-group-append">
                    <span class="input-group-text">/ 5</span>
                </div>
            </div>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark"></th>
    </tr>
    <tr>
        <td class="firstcol">Associated anomalies</td>
        <td>
            <input type="text"  value="{{$proforma->associated_anomalies}}" class="form-control"  name='associated_anomalies' aria-describedby="basic-addon1" autocomplete="off"/>
        </td>
    </tr>
    <tr class="lenke_heading_tr {{$proforma->scoliosis_type!='Idiopathic' && $proforma->scoliosis_type!='Congenital' ?'dispnone':null}}">
      <th colspan="2" class="text-white bg-dark">5. RADIOLOGICAL</th>
    </tr>
    <tr class="lenke_tr {{$proforma->scoliosis_type!='Idiopathic'?'dispnone':null}}">
        <td class="firstcol">Lenke classification(AIS)</td>
        <td>
            <select class="form-control" name="lenke_classification" id="lenke_classification">
                <option value="">Select classification</option>
                @for($j=0;$j < 7;$j++)
                    <option value="{{$j}}" {{$proforma->lenke_classification==$j?'selected':null}}>{{$j}}</option>
                @endfor
            </select>
        </td>
    </tr>
    <tr  class="winter_classification_tr {{$proforma->scoliosis_type!='Congenital' ?'dispnone':null}}">
        <td class="firstcol">Winters classification</td>
        <td>
            <select class="form-control" name="winters_classification" id="winters_classification">
                <option value="">Select classification</option>
                <option value="Failure formation" {{$proforma->winters_classification=="Failure formation"?'selected':null}}>Failure formation</option>
                <option value="Failure of segmentation" {{$proforma->winters_classification=="Failure of segmentation"?'selected':null}}>Failure of segmentation</option>
                <option value="Mixed" {{$proforma->winters_classification=="Mixed"?'selected':null}}>Mixed (Unsegmented bar with hemivertebrae)</option>
            </select>
        </td>
    </tr>
    <tr class="{{$proforma->winters_classification!='Failure formation'?'dispnone':null}} failure_formation_tr winter_classification_tr {{$proforma->scoliosis_type!='Congenital'?'dispnone':null}}">
        <td class="firstcol">Failure formation</td>
        <td>
            <select class="form-control" name="failure_formation" id="failure_formation">
                <option value="">Select failure formation</option>
                <option value="Semi-segmented" {{$proforma->failure_formation=="Semi-segmented"?'selected':null}}>Semi-segmented</option>
                <option value="Fully-segmented" {{$proforma->failure_formation=="Fully-segmented"?'selected':null}}>Fully-segmented</option>
                <option value="Wedge vertibrae" {{$proforma->failure_formation=="Wedge vertibrae"?'selected':null}}>Wedge vertibrae</option>
            </select>
        </td>
    </tr>
    <tr class="{{$proforma->winters_classification!='Failure of segmentation'?'dispnone':null}} failure_of_segmentation_tr winter_classification_tr {{$proforma->scoliosis_type!='Congenital' ?'dispnone':null}}">
        <td class="firstcol">Failure of segmentation</td>
        <td>
            <select class="form-control" name="failure_of_segmentation" id="failure_of_segmentation">
                <option value="">Select failure of segmentation</option>
                <option value="Block vertibrae" {{$proforma->failure_formation=="Block vertibrae"?'selected':null}}>Block vertibrae</option>
                <option value="Unsegmented bar" {{$proforma->failure_formation=="Unsegmented bar"?'selected':null}}>Unsegmented bar</option>
            </select>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark">6. PRIMARY CURVE</th>
    </tr>
    <tr>
        <td class="firstcol">Apex</td>
        <td>
            <input type="text" value="{{$proforma->apex}}" class="form-control"  name='apex' aria-describedby="basic-addon1" autocomplete="off"/>
        </td>
    </tr>

    <tr>
        <td class="firstcol">Apical vertical translation(AVT) </td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->apical_vertical_translation}}" class="form-control" min="0" step="any" name='apical_vertical_translation' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">mm</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Apical rotation (NASH & MOE)</td>
        <td>
            <select class="form-control" name="apical_rotation" id="apical_rotation">
                <option value="">Select rotation</option>
                @for($j=0;$j < 4;$j++)
                    <option value="{{$j}}" {{$proforma->apical_rotation==$j?'selected':null}}>{{$j}}</option>
                @endfor
            </select>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Upper end vertebra / Lower end vertebra</td>
        <td>
            <input type="text" value="{{$proforma->upper_lower_end_vertebra}}" class="form-control" name='upper_lower_end_vertebra' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Cobb's angle</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->cobb_angle}}" class="form-control" min="0" name='cobb_angle' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">Degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Bending cobb's</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->bending_cobb}}" class="form-control" min="0" name='bending_cobb' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">Degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark">7. SECONDARY CURVE</th>
    </tr>
    <tr>
        <td class="firstcol">Apex</td>
        <td>
            <input type="text" value="{{$proforma->secondary_apex}}" class="form-control"  name='secondary_apex' aria-describedby="basic-addon1" autocomplete="off"/>
        </td>
    </tr>

    <tr>
        <td class="firstcol">Apical vertical translation(AVT) </td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->secondary_apical_vertical_translation}}" class="form-control" min="0" step="any" name='secondary_apical_vertical_translation' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">mm</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Apical rotation (NASH & MOE)</td>
        <td>
            <select class="form-control" name="secondary_apical_rotation" id="secondary_apical_rotation">
                <option value="">Select rotation</option>
                @for($j=0;$j < 4;$j++)
                    <option value="{{$j}}" {{$proforma->secondary_apical_rotation==$j?'selected':null}}>{{$j}}</option>
                @endfor
            </select>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Upper end vertebra / Lower end vertebra</td>
        <td>
            <input type="text" value="{{$proforma->secondary_upper_lower_end_vertebra}}" class="form-control" step="any" name='secondary_upper_lower_end_vertebra' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Cobb's angle</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->secondary_cobb_angle}}" class="form-control" min="0" name='secondary_cobb_angle' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">Degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Bending cobb's</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->secondary_bending_cobb}}" class="form-control" min="0" name='secondary_bending_cobb' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">Degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark"></th>
    </tr>
    <tr>
        <td class="firstcol">Coronal shift/trunk shift</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->trunk_shift}}" class="form-control" min="0" step="any" name='trunk_shift' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">mm</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Thoracic kyphosis(T4-T12)</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->thoracic_kyphosis}}" class="form-control" name='thoracic_kyphosis' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Lumbar lordosis(L1-L5)</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->lumbar_lordosis}}" class="form-control" name='lumbar_lordosis' aria-describedby="basic-addon1" oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Sagittal shift (SVA)</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->sagittal_shift}}" class="form-control" step="any" name='sagittal_shift' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">mm</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Pelvic tilt(PT)</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->pelvic_tilt}}" class="form-control" name='pelvic_tilt' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Pelvic incidence(PI)</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->pelvic_incidence}}" class="form-control" name='pelvic_incidence' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Sacral slope(SS)</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->sacral_slope}}" class="form-control" step="any" name='sacral_slope' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Radiographic shoulder Height</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->radiographic_shoulder_height}}" class="form-control" step="any" name='radiographic_shoulder_height' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">mm</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Pelvic Sagittal Axis(PSA)</td>
        <td>
            <div class="input-group">
                <input type="number" value="{{$proforma->psa}}" class="form-control" step="any" name='psa' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                <div class="input-group-append">
                    <span class="input-group-text">degree</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td class="firstcol">Post operative findings</td>
        <td>
            <input type="text" value="{{$proforma->post_operative_findings}}" class="form-control" name='post_operative_findings' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark">CT findings</th>
    </tr>
    <tr>
        <td class="firstcol">Screw loosening/breakage</td>
        <td>
            <input type="text" value="{{$proforma->screw_loosening_breakage}}" class="form-control" name='screw_loosening_breakage' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark">MRI findings</th>
    </tr>
    <tr>
        <td class="firstcol">check all that apply</td>
        <td>
            <div class="mb-3">
                <div class="custom-control custom-checkbox mr-1">
                    <input type="checkbox" class="custom-control-input" id="mri_findings_1" value='Arnold Chiari' {{strpos($proforma->mri_findings, 'Arnold Chiari') !== false?'checked':null}} name="mri_findings[]">
                    <label class="custom-control-label" for="mri_findings_1">Arnold Chiari</label>
                </div>
                <div class="custom-control custom-checkbox mr-1">
                    <input type="checkbox" class="custom-control-input" id="mri_findings_2" value='Syrinx' {{strpos($proforma->mri_findings, 'Syrinx') !== false?'checked':null}} name="mri_findings[]">
                    <label class="custom-control-label" for="mri_findings_2">Syrinx</label>
                </div>
                <div class="custom-control custom-checkbox mr-1">
                    <input type="checkbox" class="custom-control-input" id="mri_findings_3" value='Low lying tethered cord (LLTC)' {{strpos($proforma->mri_findings, 'Low lying tethered cord (LLTC)') !== false?'checked':null}} name="mri_findings[]">
                    <label class="custom-control-label" for="mri_findings_3">Low lying tethered cord (LLTC)</label>
                </div>
                <div class="custom-control custom-checkbox mr-1">
                    <input type="checkbox" class="custom-control-input" id="mri_findings_4" value='Split-cord formation' {{strpos($proforma->mri_findings, 'Split-cord formation') !== false?'checked':null}} name="mri_findings[]">
                    <label class="custom-control-label" for="mri_findings_4">Split-cord formation</label>
                </div>
                <div class="custom-control custom-checkbox mr-1">
                    <input type="checkbox" class="custom-control-input" id="mri_findings_5" value='Neurofibroma' {{strpos($proforma->mri_findings, 'Neurofibroma') !== false?'checked':null}} name="mri_findings[]">
                    <label class="custom-control-label" for="mri_findings_5">Neurofibroma</label>
                </div>
                <div class="input-group">
                    <div class="custom-control custom-checkbox mr-1">
                        <input type="checkbox" class="custom-control-input" id="mri_findings_6" value='Others' {{strpos($proforma->mri_findings, 'Others') !== false?'checked':null}} name="mri_findings[]">
                        <label class="custom-control-label" for="mri_findings_6">Others</label>
                    </div>
                    <input type="text" class="form-control" name="mri_findings_other" value="{{$proforma->mri_findings_other}}">
                </div>
            </div>
        </td>
    </tr>
    <tr >
      <th colspan="2" class="text-white bg-dark"></th>
    </tr>
    <tr>
        <td class="firstcol">Neurosurgical procedure (if any)</td>
        <td>
            <textarea class="form-control" name='neurosurgical_procedure' aria-describedby="basic-addon1"  oninvalid="" autocomplete="off">{{$proforma->neurosurgical_procedure}}</textarea>
        </td>
    </tr>
</table>


    
            <br>

            <!--Add employer details form start-->

        @include('layouts.errors')
        
        <?php
        $nextstagename='';
        switch($stage+1){
            case 1:$nextstagename="Preoperative";
            break;
            case 2:$nextstagename="Post operative";
            break;
            case 3:$nextstagename="Postop F/U 1st visit – 1 month";
            break;
            case 4:$nextstagename="Postop F/U 2nd visit – 6 months";
            break;
            default:$nextstagename='No stage selected';
        }
        ?>
        @if($stage < 4)
            @if($patient->srsExist($stage+1))
                <a href="/srs22/edit/{{$stage+1}}/{{$patient->id}}" class="btn btn-primary" onclick="return confirm('Are you sure want to navigate')">Discard changes and view SRS22r for {{$nextstagename}}</a>
            @else
                <a href="/srs22/new/{{$stage+1}}/{{$patient->id}}" class="btn btn-primary" onclick="return confirm('Are you sure want to navigate')">Discard changes and create new SRS22r for {{$nextstagename}}</a>
            @endif
        @endif
        <button type="submit" class="btn btn-success">Update</button>
    </form>
    </div>
@endsection
