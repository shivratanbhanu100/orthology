@foreach($patients as $patient)
<tr class="foreachtr">
    <td>
        @if($patient->ortholog!=1)
            <div class="custom-control custom-checkbox">
            <input type="checkbox"  name='ids[]' class="idcheckbox custom-control-input idcheckbox" id="customCheck{{$patient->id}}" value="{{$patient->id}}" name='ids[]'>
            <label class="custom-control-label" for="customCheck{{$patient->id}}">&nbsp;</label>
            </div>
        @endif
    </td>
    <td><a href="/scoliosis/patient/{{$patient->id}}">{{$patient->name}}</a></td>
    <td>{{$patient->age}}</td>
    <td>{{$patient->sex}}</td>
    <td><a href="/scoliosis/patient/{{$patient->id}}">{{$patient->uhid}}</a></td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <!-- <td>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-check-circle text-success"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="far fa-circle"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="far fa-circle"></i><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="far fa-circle"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-circle text-muted"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-circle text-muted"></i>
    </td> -->
    @for($i=1; $i< 5 ;$i++)
        <td>
            @if($patient->srsExist($i))
                <a href="/srs22/edit/{{$i}}/{{$patient->id}}"><i class="fas fa-check-circle text-success"></i></a><br>
            @else
                @if($i>1)
                    @if($patient->srsExist($i-1))
                        <a href="/srs22/new/{{$i}}/{{$patient->id}}"><i class="far fa-circle "></i></a><br>
                    @else
                        <i class="far fa-circle"></i><br>
                    @endif
                @else
                    <a href="/srs22/new/{{$i}}/{{$patient->id}}"><i class="far fa-circle "></i></a><br>
                @endif
            @endif

            @if($patient->proformaExist($i))
                <a href="/proforma/edit/{{$i}}/{{$patient->id}}"><i class="fas fa-check-circle text-success"></i></a>
            @else
                <a href="/proforma/new/{{$i}}/{{$patient->id}}"><i class="far fa-circle"></i></a>
            @endif
        </td>
    @endfor
    <!-- <td>
        <a href="/srs22/edit/1/{{$patient->id}}"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/proforma/edit/1/{{$patient->id}}"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/srs22/edit/2/{{$patient->id}}"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/proforma/new/2/{{$patient->id}}"><i class="far fa-circle"></i></a>
    </td>
    <td>    
        <a href="srs22/edit/3/{{$patient->id}}"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/proforma/new/3/{{$patient->id}}"><i class="far fa-circle"></i></a>
    </td>
    <td>    
        <a href="/srs22/new/4/{{$patient->id}}"><i class="far fa-circle "></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td> -->
</tr>
@endforeach
<!-- <tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Amit Jain</a></td>
    <td>25-05-1987</td>
    <td>Male</td>
    <td>102547859</td>
    <td>12th Feb, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle "></i></a>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Ajit Singh</a></td>
    <td>25-05-1977</td>
    <td>Male</td>
    <td>102547852</td>
    <td>14th Mar, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>
    <td>
    <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Rinki kapoor</a></td>
    <td>25-05-1995</td>
    <td>Female</td>
    <td>103265987</td>
    <td>29th Mar, 2019<br><span class="badge badge-danger">Overdue</span></td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
    <td>
        <i class="far fa-circle"></i><br>
        <i class="far fa-circle"></i>
    </td>
    <td>
        <i class="far fa-circle"></i><br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Indira sharma</a></td>
    <td>18-05-1965</td>
    <td>Female</td>
    <td>106554878</td>
    <td>5th Apr, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Rishi Jain</a></td>
    <td>25-05-1966</td>
    <td>Male</td>
    <td>102547859</td>
    <td>16th Jun, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle "></i></a>
        <br>
        <i class="far fa-circle "></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Vinod Pal</a></td>
    <td>25-05-1954</td>
    <td>Male</td>
    <td>102356897</td>
    <td>16th Jun, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>    
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle "></i></a>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Kripa Sharma</a></td>
    <td>25-05-1992</td>
    <td>Female</td>
    <td>102509750</td>
    <td>2nd Jul, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Rinki Manchanda</a></td>
    <td>25-07-1977</td>
    <td>Female</td>
    <td>102509734</td>
    <td>30th Dec, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
    <td>
        <i class="far fa-circle"></i><br>
        <i class="far fa-circle"></i>
    </td>
    <td>
        <i class="far fa-circle"></i><br>
        <i class="far fa-circle"></i>
    </td>
</tr>
<tr class="foreachtr">
    
    <td><a href="/scoliosis/record/1">Kriti Goel</a></td>
    <td>02-07-1993</td>
    <td>Female</td>
    <td>106789750</td>
    <td>5th Dec, 2020</td>
    <td>
        Questionnaire:<br>
        Proforma:
    </td>    
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/edit/1"><i class="fas fa-check-circle text-success"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/edit/1"><i class="fas fa-check-circle text-success"></i></a><br>
        <a href="/scoliosis/proforma/new/1"><i class="far fa-circle"></i></a>
    </td>
    <td>
        <a href="/scoliosis/questionnaire/new/1"><i class="far fa-circle"></i></a>
        <br>
        <i class="far fa-circle"></i>
    </td>
</tr> -->