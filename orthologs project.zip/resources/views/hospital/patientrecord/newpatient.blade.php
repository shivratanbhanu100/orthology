@extends('layouts.hospital.master')


@section('fixedheadercontent')

<div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
        <h1 class="h2">Add new patient</h1>
    </div>

    <div class="form-inline">
        <div class="btn-group btn-group-sm" role="group">
            <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
        </div>
    </div>

</div>

@endsection
@section('headercontent')
<div class="px-3 py-3">
    <form method="post" action="/newpatient" class="form-horizontal">

        @csrf

        <table class="table table-striped reportform formtable">
            <tr>
                <th colspan="2" class="bg-dark text-white">1. PATIENT DETAILS</th>
            </tr>
            <tr>
                <td class="firstcol">UHID:<span class="text-danger">*</span></td>
                <td>
                    <input type="text" id="checknewuhid" class="form-control" name='uhid' aria-describedby="basic-addon1"
                        required="required" oninvalid="" autocomplete="off" />
                    <span class="text-danger dangerspan dispnone">UHID already exists. Details on this form will be updated on patient's profile.</span>
                    <span class="text-success successspan dispnone">UHID available</span>
                </td>
            </tr>

            <tr>
                <td class="firstcol">Patient Name</td>
                <td>
                    <input type="text" class="form-control" aria-describedby="basic-addon1" name='patient_name'
                        autocomplete="off" />
                </td>
            </tr>
            <tr>
                <td>Sex<span class="text-danger">*</span></td>
                <td>
                    <div class="input-group mb-3">
                        <div class="custom-control custom-radio mb-3 mr-2">
                            <input type="radio" class="custom-control-input sex" id="sex_1" value='Male' name='sex'
                                required>
                            <label class="custom-control-label" for="sex_1">Male</label>
                        </div>
                        <div class="custom-control custom-radio mb-3 mr-2">
                            <input type="radio" class="custom-control-input sex" id="sex_2" value='Female' name='sex'>
                            <label class="custom-control-label" for="sex_2">Female</label>
                        </div>
                        <div class="custom-control custom-radio mb-3 mr-2">
                            <input type="radio" class="custom-control-input sex" id="sex_3" value='Others' name='sex'>
                            <label class="custom-control-label" for="sex_3">Others</label>
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td>Date of birth</td>
                <td>
                    <div class="input-group mb-3 mr-4">
                        <select class="form-control" name="dob_date" id="dob_date">
                            <option value="">DD</option>
                            @for ($i=1; $i <= 31; $i++) 
                                <option>{{sprintf('%02d', $i)}}</option>
                            @endfor
                        </select>
                        <select class="form-control" name="dob_month" id="dob_month">
                            <option value="">MM</option>
                            @for ($i=1; $i <= 12; $i++) 
                                <option>{{sprintf('%02d', $i)}}</option>
                            @endfor
                        </select>
                        <select class="form-control" name="dob_year" id="dob_year">
                            <option value="">YYYY</option>
                            @for ($i=date('Y'); $i > date('Y', strtotime(date('Y').'- 100 years')); $i--)
                                <option>{{$i}}</option>
                            @endfor
                        </select>
                    </div>
                    
                </td>
            </tr>
            <tr>
                <td>Age (Years)<span class="text-danger removestar">*</span></td>
                <td>
                    <input type="number" class="form-control removerequired" name="age" id="age" required>
                </td>
            </tr>
            <tr>
                <td>Diagnosis<span class="text-danger">*</span></td>
                <td>
                    <textarea class="form-control" name="diagnosis" id="diagnosis" required></textarea>
                </td>
            </tr>
        </table>
        <br>

        <!--Add employer details form start-->

        @include('layouts.errors')
        <input type="hidden" name="dashboard" value="0">
        <input type="submit" id="formsubmitbtn" class="dispnone">
        <button type="button" class="btn btn-success submittype" dasboardval="1">Save</button>
        <button type="button" class="btn btn-primary submittype" dasboardval="0">Save and continue to questionnaire</button>
    </form>
</div>
@endsection