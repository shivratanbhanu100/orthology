@extends('layouts.hospital.master')


@section('fixedheadercontent')

  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
      <h1 class="h2">Add new CRF</h1>
    </div>

    <div class="form-inline">
      <div class="btn-group btn-group-sm" role="group">
        <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
      </div>
    </div>

  </div>

@endsection
@section('headercontent')
  <div class="px-3 py-3">
    <form method="post" action="/hospital/crf/store" id='crfform' class="form-horizontal">

      {{ csrf_field() }}

      <table class="table table-striped reportform table-responsive">
        <tr class="text-white bg-dark">
          <th colspan="2">1. PATIENT INFORMATION</th>
        </tr>
        <tr>
          <td class="firstcol">Surveillance unit<span class="text-danger">*</span></td>
            <td>

            </td>
        </tr>
        <tr>
          <td class="firstcol">Medical record Number:<span class="text-danger">*</span></td>
          <td>
            <div class="input-group">
              <div class="input-group-prepend">
                <input type="text" class="form-control" name='mrn' aria-describedby="basic-addon1" required="required" oninvalid="" autocomplete="off"/>
              </div>
              <input type="button" value="Evaluate event" class="btn btn-primary calculateeventfromworksheet">
            </div>
          </td>
        </tr>

        <tr>
          <td class="firstcol">Patient Name</td>
          <td>
            <input type="text" class="form-control" aria-describedby="basic-addon1" name='patient_name' autocomplete="off"/>
          </td>
        </tr>
        <tr>
          <td>Gender<span class="text-danger">*</span></td>
          <td>
          <div class="input-group mb-3">
            <div class="custom-control custom-radio mb-3 mr-2">
              <input type="radio" class="custom-control-input sex" id="sex_1" value='M' name='sex' required>
              <label class="custom-control-label" for="sex_1">M</label>
            </div>
            <div class="custom-control custom-radio mb-3 mr-2">
              <input type="radio" class="custom-control-input sex" id="sex_2" value='F' name='sex'>
              <label class="custom-control-label" for="sex_2">F</label>
            </div>
            <div class="custom-control custom-radio mb-3 mr-2">
              <input type="radio" class="custom-control-input sex" id="sex_3" value='O' name='sex'>
              <label class="custom-control-label" for="sex_3">O</label>
            </div>
          </div>
          </td>
        </tr>
        <tr>
          <td>Date of birth</td>
          <td>
            <div class="row dobcontainer">
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <select class="form-control" name="dob_date" id="dob_date">
                  <option value="">DD</option>
                  @for ($i=1; $i <= 31; $i++)
                    <option>{{$i}}</option>
                  @endfor
                </select>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <select class="form-control" name="dob_month" id="dob_month">
                  <option value="">MM</option>
                  @for ($i=1; $i <= 12; $i++)
                    <option>{{$i}}</option>
                  @endfor
                </select>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <select class="form-control" name="dob_year" id="dob_year">
                  <option value="">YYYY</option>
                  @for ($i=date('Y'); $i > date('Y', strtotime(date('Y').'- 100 years')); $i--)
                    <option>{{$i}}</option>
                  @endfor
                </select>
              </div>
            </div>
          </td>
        </tr>
        <tr>
          <td>Age (Years)<span class="text-danger removestar">*</span></td>
          <td>
            <input type="number" class="form-control removerequired" name="age" id="age" required>
          </td>
        </tr>
        <tr>
          <td>Date of event<span class="text-danger">*</span></td>
          <td>
            <input type="text" id="date_of_event" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="date_of_event"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1" required="required"  oninvalid="" autocomplete="off"/>
          </td>
        </tr>
        <tr>

        </tr>
        
        <tr>
          <td>Post Procedure VAE<span class="text-danger">*</span></td>
          <td>
          <div class="input-group mb-3">
            <div class="custom-control custom-radio mb-3 mr-2">
              <input type="radio" class="custom-control-input post_procedure_vae" id="post_procedure_vae_1" value='Yes' name='post_procedure_vae' required>
              <label class="custom-control-label" for="post_procedure_vae_1">Yes</label>
            </div>
            <div class="custom-control custom-radio mb-3 mr-2">
              <input type="radio" class="custom-control-input post_procedure_vae" id="post_procedure_vae_2" value='No' name='post_procedure_vae'>
              <label class="custom-control-label" for="post_procedure_vae_2">No</label>
            </div>
          </div>
          </td>
        </tr>
          <td>Date of procedure<span class="text-danger">*</span></td>
          <td>
            <input type="text" id="date_of_procedure" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="date_of_procedure"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" required="required" autocomplete="off"/>
          </td>
        </tr>
    <tr>
      <td>MDRO Infection Surveillance<span class="text-danger">*</span></td>
      <td>
        <div class="input-group mb-3">
          <div class="custom-control custom-radio mb-3 mr-5">
            <input type="radio" class="custom-control-input mdro_infection" id="mdro_infection_1" value='Yes' name='mdro_infection' required>
            <label class="custom-control-label" for="mdro_infection_1">Yes, this infection’s pathogen & location are in-plan for Infection Surveillance in the MDRO/CDI Module</label>
          </div>
          <div class="custom-control custom-radio mb-3 mr-5">
            <input type="radio" class="custom-control-input mdro_infection" id="mdro_infection_2" value='No' name='mdro_infection'>
            <label class="custom-control-label" for="mdro_infection_2">No, this infection’s pathogen & location are not in-plan for Infection Surveillance in the MDRO/CDI Module</label>
          </div>
        </div>
      </td>
    </tr>
    <tr>
      <td>Date admitted to facility<span class="text-danger">*</span></td>
      <td>
        <input type="text" id="date_of_admission" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="date_of_admission" class="datepicker form-control" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1" required="required" oninvalid="" autocomplete="off"/>

      </td>
    </tr>
    <tr>
      <td class="firstcol">Location of Mechanical Ventilation Initiation<span class="text-danger">*</span></td>
      <td>
        <input type="text" value="" class="form-control" aria-describedby="basic-addon1" name='location_of_mechanical_ventilation_initiation' required="required"/>
      </td>
    </tr>
    <tr>
      <td class="firstcol">Date Initiated<span class="text-danger">*</span></td>
      <td>
        <input type="text" id="date_initiated" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="date_initiated" class="datepicker form-control" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1" required="required" oninvalid="" autocomplete="off"/>
      </td>
    </tr>
    <tr>
      <td class="firstcol">APRV<span class="text-danger">*</span></td>
      <td>
        <div class="input-group mb-3">
          <div class="custom-control custom-radio mb-3 mr-5">
            <input type="radio" class="custom-control-input aprv" id="aprv_1" value='Yes' name='aprv' required>
            <label class="custom-control-label" for="aprv_1">Yes</label>
          </div>
          <div class="custom-control custom-radio mb-3 mr-5">
            <input type="radio" class="custom-control-input aprv" id="aprv_2" value='No' name='aprv'>
            <label class="custom-control-label" for="aprv_2">No</label>
          </div>
        </div>
      </td>
    </tr>

    <tr class="text-white bg-dark">
      <th colspan="2">2. EVENT DETAILS</th>
    </tr>

    <tr>
      <td class="firstcol">Hospital Name<span class="text-danger">*</span></td>
      <td>
        <input type="text" value="{{\Auth::user()->name}}" class="form-control" aria-describedby="basic-addon1" name='hospital_name' required="required" disabled/>
      </td>
    </tr>

    <tr>
      <td>Specific Event<span class="text-danger">*</span></td>
      <td>

        <div class="custom-control custom-checkbox custom-control-inline mb-3">
          <input type="checkbox" class="custom-control-input" id="specific_event_vac" value='1' name='specific_event_vac'>
          <label class="custom-control-label" for="specific_event_vac"> VAC</label>
        </div>
        <div class="custom-control custom-checkbox custom-control-inline mb-3">
          <input type="checkbox" class="custom-control-input" id="specific_event_ivac" value='1' name='specific_event_ivac'>
          <label class="custom-control-label" for="specific_event_ivac"> IVAC</label>
        </div>
        <div class="custom-control custom-checkbox custom-control-inline mb-3">
          <input type="checkbox" class="custom-control-input" id="specific_event_pvap" value='1' name='specific_event_pvap'>
          <label class="custom-control-label" for="specific_event_pvap"> PVAP</label>
        </div>
        
      </td>
    </tr>
    <tr>
      <td>Specify Criteria Used<span class="text-danger">*</span></td>
      <td>
        <div class="criteria_for_vac">
          <h6><b>STEP 1: VAC (≥1 REQUIRED)</b></h6>
          <div class="custom-control custom-checkbox custom-control-inline mb-3">
            <input type="checkbox" class="custom-control-input" id="vac_min_fio2" value='1' name='vac_min_fio2'>
            <label class="custom-control-label" for="vac_min_fio2"> Daily min FiO2 increase ≥ 0.20 (20 points) for ≥ 2 days†</label>
          </div>
          <b>OR</b>
          <div class="custom-control custom-checkbox custom-control-inline mb-3 ml-3">
            <input type="checkbox" class="custom-control-input" id="vac_min_peep_increase" value='1' name='vac_min_peep_increase'>
            <label class="custom-control-label" for="vac_min_peep_increase"> Daily min PEEP increase ≥ 3 cm H2O for ≥ 2 days†</label>
          </div><br>
          <i>†after 2+ days of stable or decreasing daily minimum values.</i>
        </div>
        <br>
        <div class="criteria_for_ivac">
          <h6><b>STEP 2: IVAC</b></h6>
          <div class="custom-control custom-checkbox custom-control-inline mb-3">
            <input type="checkbox" class="custom-control-input" id="ivac_temperature_38_36" value='1' name='ivac_temperature_38_36'>
            <label class="custom-control-label" for="ivac_temperature_38_36"> Temperature > 38°C or < 36°</label>
          </div>
          <b>OR</b>
          <div class="custom-control custom-checkbox custom-control-inline mb-3 ml-3">
            <input type="checkbox" class="custom-control-input" id="ivac_white_blood_cell_count" value='1' name='ivac_white_blood_cell_count'>
            <label class="custom-control-label" for="ivac_white_blood_cell_count"> White blood cell count ≥ 12,000 or ≤ 4,000 cells/mm3</label>
          </div><br>
          AND<br>
          <div class="custom-control custom-checkbox custom-control-inline mb-3">
            <input type="checkbox" class="custom-control-input" id="ivac_new_antimicrobial" value='1' name='ivac_new_antimicrobial'>
            <label class="custom-control-label" for="ivac_new_antimicrobial"> A new antimicrobial agent(s) is started, and is continued for ≥ 4 days</label>
          </div><br>
          
        </div>
        <br>
        <div class="criteria_for_pvap">
          <h6><b>STEP 3: PVAP</b></h6>
          <div class="custom-control custom-checkbox custom-control-inline mb-3">
            <input type="checkbox" class="custom-control-input" id="pvap_criterion_1" value='1' name='pvap_criterion_1'>
            <label class="custom-control-label" for="pvap_criterion_1"> Criterion #1: Positive culture of one of the following specimens, meeting quantitative or semi-quantitative thresholds as outlined in protocol,‡ without requirement for purulent respiratory secretions:</label>
          </div>
          <!-- part 1 start-->
          <div class="ml-5">
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_1_endotracheal" value='1' name='pvap_criterion_1_endotracheal'>
              <label class="custom-control-label" for="pvap_criterion_1_endotracheal"> Endotracheal aspirate</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_1_lung_tissue" value='1' name='pvap_criterion_1_lung_tissue'>
              <label class="custom-control-label" for="pvap_criterion_1_lung_tissue"> Lung tissue</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_1_bronchoalveolar" value='1' name='pvap_criterion_1_bronchoalveolar'>
              <label class="custom-control-label" for="pvap_criterion_1_bronchoalveolar"> Bronchoalveolar lavage</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_1_protected" value='1' name='pvap_criterion_1_protected'>
              <label class="custom-control-label" for="pvap_criterion_1_protected"> Protected specimen brush</label>
            </div>
          </div>
          <!-- part 1 end-->
          OR<br>
          <div class="custom-control custom-checkbox custom-control-inline mb-3">
            <input type="checkbox" class="custom-control-input" id="pvap_criterion_2" value='1' name='pvap_criterion_2'>
            <label class="custom-control-label" for="pvap_criterion_2"> Criterion #2: Purulent respiratory secretions‡ (defined in the protocol) plus organism(s) identified from one of the following specimens:‡</label>
          </div><br>
          <!-- part 2 start-->
          <div class="ml-5">
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_2_sputum" value='1' name='pvap_criterion_2_sputum'>
              <label class="custom-control-label" for="pvap_criterion_2_sputum"> Sputum</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_2_lung_tissue" value='1' name='pvap_criterion_2_lung_tissue'>
              <label class="custom-control-label" for="pvap_criterion_2_lung_tissue"> Lung tissue</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_2_endotracheal" value='1' name='pvap_criterion_2_endotracheal'>
              <label class="custom-control-label" for="pvap_criterion_2_endotracheal"> Endotracheal aspirate</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_2_protected" value='1' name='pvap_criterion_2_protected'>
              <label class="custom-control-label" for="pvap_criterion_2_protected"> Protected specimen brush</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_2_bronchoalveolar" value='1' name='pvap_criterion_2_bronchoalveolar'>
              <label class="custom-control-label" for="pvap_criterion_2_bronchoalveolar"> Bronchoalveolar lavage</label>
            </div>
          </div>
          <!-- part 2 end-->
          OR<br>
          <div class="custom-control custom-checkbox custom-control-inline mb-3">
            <input type="checkbox" class="custom-control-input" id="pvap_criterion_3" value='1' name='pvap_criterion_3'>
            <label class="custom-control-label" for="pvap_criterion_3"> Criterion #3: One of the following positive tests (as outlined in the protocol):‡</label>
          </div><br>
          <!-- part 3 start-->
          <div class="ml-5">
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_3_organism" value='1' name='pvap_criterion_3_organism'>
              <label class="custom-control-label" for="pvap_criterion_3_organism"> Organism(s) identified from pleural fluid</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_3_legionella" value='1' name='pvap_criterion_3_legionella'>
              <label class="custom-control-label" for="pvap_criterion_3_legionella"> Diagnostic test for <i>Legionella</i> species</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_3_lung_histopathology" value='1' name='pvap_criterion_3_lung_histopathology'>
              <label class="custom-control-label" for="pvap_criterion_3_lung_histopathology"> Lung histopathology</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline mb-3">
              <input type="checkbox" class="custom-control-input" id="pvap_criterion_3_viral_pathogens" value='1' name='pvap_criterion_3_viral_pathogens'>
              <label class="custom-control-label" for="pvap_criterion_3_viral_pathogens"> Diagnostic test for selected viral pathogens</label>
            </div>
          </div>
          <!-- part 3 end-->
        </div>
        <i>‡collected after 2 days of mechanical ventilation and within +/- 2 days of onset of increase in FiO2 or PEEP</i>

      </td>
    </tr>

    

    <tr class="text-white bg-dark">
      <th colspan="2">4. Infection Details</th>
    </tr>
    <tr>
      <td>Secondary BSI<span class="text-danger">*</span></td>
      <td>
        <div class="input-group mb-3">
          <div class="custom-control custom-radio mb-3 mr-5">
            <input type="radio" class="custom-control-input secondary_bsi" id="secondary_bsi_1" value='Yes' name='secondary_bsi' required>
            <label class="custom-control-label" for="secondary_bsi_1">Yes</label>
          </div>
          <div class="custom-control custom-radio mb-3 mr-5">
            <input type="radio" class="custom-control-input secondary_bsi" id="secondary_bsi_2" value='No' name='secondary_bsi'>
            <label class="custom-control-label" for="secondary_bsi_2">No</label>
          </div>
        </div>
      </td>
    </tr>
    <tr>
      <td>Died<span class="text-danger">*</span></td>
      <td>
        <div class="input-group mb-3">
          <div class="custom-control custom-radio mb-3 mr-5">
            <input type="radio" class="custom-control-input died" id="died_1" value='Yes' name='died' required>
            <label class="custom-control-label" for="died_1">Yes</label>
          </div>
          <div class="custom-control custom-radio mb-3 mr-5">
            <input type="radio" class="custom-control-input died" id="died_2" value='No' name='died'>
            <label class="custom-control-label" for="died_2">No</label>
          </div>
        </div>

        <div class="dispnone died_details">
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text">Date of Death</span>
            </div>
            <input type="text" class="form-control datepicker" name="death_date" id="death_date"   placeholder="Date of Death" autocomplete="off">
          </div>
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text">VAE Contributed to Death</span>
            </div>
            <div class="input-group-append">
              <span class="input-group-text">
                <div class="input-group">
                  <div class="custom-control custom-radio mr-5">
                    <input type="radio" class="custom-control-input vae_contributed_to_death" id="vae_contributed_to_death_1" value='Yes' name='vae_contributed_to_death' required>
                    <label class="custom-control-label" for="vae_contributed_to_death_1">Yes</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input vae_contributed_to_death" id="vae_contributed_to_death_2" value='No' name='vae_contributed_to_death'>
                    <label class="custom-control-label" for="vae_contributed_to_death_2">No</label>
                  </div>
                </div>
              </span>
            </div>
          </div>
        </div>
      </td>
    </tr>
    <tr class="discharge_date">
      <td>Discharge date<span class="text-danger">*</span></td>
      <td>
        <input type="text" name="discharge_date" id="discharge_date" class="datepicker form-control" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1" required autocomplete="off"/>
      </td>
    </tr>
    <tr>
      <td>Pathogen Obtained<span class="text-danger">*</span></td>
      <td>
        <label>
          <input type="radio" name="pathogen_obtained" class="pathogen_obtained" value="Yes" required="required"> Yes
        </label>
        &nbsp;&nbsp;
        <label>
          <input type="radio" name="pathogen_obtained" class="pathogen_obtained" value="No"> No
        </label>

      </td>
    </tr>
</table>


    
            <br>

            <!--Add employer details form start-->

      @include('layouts.errors')
      {{-- <input type='button' class="verifysec5organism btn btn-success" value='Submit'> --}}
      <input type="hidden" id='organismrow' value="0" name="organismrow">
      <button type="submit" class="btn btn-success validorganismclick">Submit</button>
    </form>
    </div>
@endsection
