<div class="cf-container" id="cf-container">
    <br>
    <table class="table table-bordered reportform">

        <tr>
            <td>Name</td>
            <td>{{$log->patientdetail->name}}</td>
        </tr>
        <tr>
            <td class="firstcol">DOB</td>
            <td>{{!is_null($log->patientdetail->dob)?$log->patientdetail->dob->format('d-m-Y'):null}}</td>
        </tr>
        <tr>
            <td class="firstcol">Age</td>
            <td>{{$log->patientdetail->age}}</td>
        </tr>
        <tr>
            <td>Sex</td>
            <td>{{$log->patientdetail->sex}}
            </td>
        </tr>
        <tr>
            <td>UHID</td>
            <td>{{$log->patientdetail->uhid}}</td>
        </tr>
        <tr>
            <td class="firstcol">Phone no</td>
            <td>{{$log->patientdetail->phone}}</td>
        </tr>
        <tr>
            <td class="firstcol">Address</td>
            <td>{{$log->patientdetail->address}}</td>
        </tr>
        <tr>
            <td class="firstcol">Email Id</td>
            <td>{{$log->patientdetail->email}}</div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Occupation (Parent’s occupation in case of minor)</td>
            <td>{{$log->patientdetail->occupation}}</td>
        </tr>
        <tr>
            <td>Bed no</td>
            <td>{{$log->patientdetail->bed_no}}</td>
        </tr>

        <tr>
            <td>Operative details</td>
            <td>{{$log->operative_details}}</td>
        </tr>
        <tr>
            <td>Diagnosis</td>
            <td>{{$log->diagnosis}}</td>
        </tr>
        <tr>
            <td>Level</td>
            <td>{{$log->level}}</td>
        </tr>
        <tr>
            <td>Treatment / Op procedure</td>
            <td>{{$log->treatment_procedure}}</td>
        </tr>
        <tr>
            <td>Comorbidities</td>
            <td>{{$log->comorbidities}}</td>
        </tr>

        <tr>
            <td class="firstcol">Surgeons</td>
            <td>{{$log->surgeons}}</td>
        </tr>
        <tr>
            <td>Implant</td>
            <td>{{$log->implant}}</td>
        </tr>
        <tr>
            <td class="firstcol">Surgical duration</td>
            <td>{{$log->surgical_time}} minute(s)</td>
        </tr>
        <tr>
            <td class="firstcol">Blood loss</td>
            <td>{{$log->blood_loss}} ml</td>
        </tr>
        <tr>
            <td class="firstcol">DOA </td>
            <td>{{!is_null($log->doa) ? $log->doa->format('d-m-Y'):null}}</td>
        </tr>
        <tr>
            <td class="firstcol">DOO</td>
            <td>{{!is_null($log->doo) ? $log->doo->format('d-m-Y'):null}}</td>
        </tr>
        <tr>
            <td class="firstcol">DOD</td>
            <td>{{!is_null($log->dod) ? $log->dod->format('d-m-Y'):null}}</td>
        </tr>
        <tr>
            <td class="firstcol">Post op course</td>
            <td>{{$log->postopcourses}}<br>{{$log->postopcourses_other}}</td>
        </tr>

    </table>
</div>