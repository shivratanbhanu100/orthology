<div class="cf-container dispnone" id="cf-container">
    <br>
    <table class="table table-bordered table-striped reportform formtable">

        <tr>
            <td>Name<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input required type="text" class="form-control" name="name" id="name"
                            value="{{@old('name')}}" placeholder="Name" autocomplete="off" required>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOB</td>
            <td>
                <div class="input-group mb-3 mr-4">
                    <select class="form-control" name="dob_date" id="dob_date">
                        <option value="">DD</option>
                        @for ($i=1; $i <= 31; $i++) 
                            <option>{{sprintf('%02d', $i)}}</option>
                        @endfor
                    </select>
                    <select class="form-control" name="dob_month" id="dob_month">
                        <option value="">MM</option>
                        @for ($i=1; $i <= 12; $i++) 
                            <option>{{sprintf('%02d', $i)}}</option>
                        @endfor
                    </select>
                    <select class="form-control" name="dob_year" id="dob_year">
                        <option value="">YYYY</option>
                        @for ($i=date('Y'); $i > date('Y', strtotime(date('Y').'- 100 years')); $i--)
                            <option>{{$i}}</option>
                        @endfor
                    </select>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Age<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input required type="number" min="0" class="form-control" name="age" id="age"
                            value="{{@old('age')}}" placeholder="Age" autocomplete="off">
                    <div class="input-group-append">
                        <span class="input-group-text">year(s)</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td>Sex<span class="text-danger">*</span></td>
            <td>
                <select class="form-control" name="sex" required="required">
                    <option value="">Select sex</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Others">Others</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>UHID<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input id="checknewuhid" type="text" class="form-control" name="uhid" id="uhid" value="{{@old('uhid')}}" placeholder="UHID" autocomplete="off" required="required">
                </div>
                <span class="text-danger dangerspan dispnone">UHID already exists. Details on this form will be updated on patient's profile.</span>
                <span class="text-success successspan dispnone">UHID available</span>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Phone no<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="phone_no" id="phone_no" value="{{@old('phone_no')}}" placeholder="Phone no" autocomplete="off" required="required">
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Address<span class="text-danger">*</span></td>
            <td>
                <div class="input-group mb-3">
                    <textarea class="form-control" name="address" id="address" placeholder="Address" autocomplete="off" required="required">{{@old('address')}}</textarea>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Email Id</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="emailid" id="emailid" value="{{@old('emailid')}}" placeholder="Email Id" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Occupation (Parent’s occupation in case of minor)</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="occupation" id="occupation" value="{{@old('occupation')}}" placeholder="Occupation" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Bed no</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="bed_no" id="bed_no" value="{{@old('bed_no')}}" placeholder="Bed no" autocomplete="off">
                </div>
            </td>
        </tr>

        <tr>
            <td>Operative details</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="operative_details" id="operative_details" value="{{@old('operative_details')}}" placeholder="Operative details" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Diagnosis</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="diagnosis" id="diagnosis" value="{{@old('diagnosis')}}" placeholder="Diagnosis" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Level</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="level" id="level" value="{{@old('level')}}" placeholder="Level" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Treatment / Op procedure</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="treatment_procedure" id="treatment_procedure" value="{{@old('treatment_procedure')}}" placeholder="Treatment / Op procedure" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td>Comorbidities</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="comorbidities" id="comorbidities" value="{{@old('comorbidities')}}" placeholder="Comorbidities" autocomplete="off">
                </div>
            </td>
        </tr>

        <tr>
            <td class="firstcol">Surgeons</td>
            <td>
                @foreach(orthologsurgeons() as $surgeon)
                    <div class="custom-control custom-checkbox custom-control-inline mb-3">
                        <input type="checkbox" class="custom-control-input" id="specific_event_{{$surgeon}}" value='{{$surgeon}}' name='surgeons[]'>
                        <label class="custom-control-label" for="specific_event_{{$surgeon}}"> {{$surgeon}}</label>
                    </div>
                @endforeach
            </td>
        </tr>
        <tr>
            <td>Implant</td>
            <td>
                <div class="input-group mb-3">
                    <textarea class="form-control" name="implant" id="implant" placeholder="Implant" autocomplete="off">{{@old('implant')}}</textarea>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Surgical duration</td>
            <td>
                <div class="input-group mb-3">
                    <input type="number" min="0" class="form-control" name="surgical_time" id="surgical_time"
                            value="{{@old('surgical_time')}}" placeholder="Surgical time" autocomplete="off">
                    <div class="input-group-append">
                        <span class="input-group-text">minute(s)</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Blood loss</td>
            <td>
                <div class="input-group mb-3">
                    <input type="number" min="0" class="form-control" name="blood_loss" id="blood_loss"
                            value="{{@old('blood_loss')}}" placeholder="Blood loss" autocomplete="off">
                    <div class="input-group-append">
                        <span class="input-group-text">ml</span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOA</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="doa" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="doa"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOO</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="doo" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="doo"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">DOD</td>
            <td>
                <div class="input-group mb-3">
                    <input type="text" id="dod" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" name="dod"  class="datepicker form-control whiteback" placeholder="DD-MM-YYYY" aria-describedby="basic-addon1"  oninvalid="" autocomplete="off"/>
                </div>
            </td>
        </tr>
        <tr>
            <td class="firstcol">Post op course</td>
            <td>
                @php($i=1)
                @foreach(postopcourse() as $postopcourse)
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="postopcourse{{$i}}" value='{{$postopcourse}}' name='postopcourses[]'>
                        <label class="custom-control-label" for="postopcourse{{$i}}"> {{$postopcourse}}</label>
                    </div>
                    @php($i++)
                @endforeach
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="postopcoursesother" value='Other' name='postopcourses[]'>
                    <label class="custom-control-label" for="postopcoursesother"> Other</label>
                </div>
                <input type="text" class="form-control" name="postopcourses_other">
            </td>
        </tr>

    </table>
</div>