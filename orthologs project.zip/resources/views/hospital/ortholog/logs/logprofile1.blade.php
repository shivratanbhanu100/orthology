@extends('layouts.hospital.master')

@section('fixedheadercontent')

  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
      <h1 class="h2">{{caseidformat($log->id)}}</h1>
    </div>

    <div class="form-inline">
      <div class="btn-group btn-group-sm" role="group">
        <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
        <a href="/ortho/ortholog/{{$log->id}}/edit/" class="btn btn-primary btn-sm">Edit</a>
       </div>
    </div>

  </div>

@endsection

@section('headercontent')

<div class="px-3 py-3 disableall">
  <table class="table table-bordered">
    <tr>
      <td>Category</td>
      <td>{{$log->category}}</td>
    </tr>
    <tr class="{{$log->category!='Traumatic'?'dispnone':null}}">
      <td>Site</td>
      <td>{{$log->trauma_site}}</td>
    </tr>
    <tr class="{{$log->category!='Infection'?'dispnone':null}}">
      <td colspan=2>
        <table class="table table-bordered">
          <tr>
            <td>Type</td>
            <td>{{$log->infection_type}}</td>
          </tr>
          <tr class="{{$log->infection_type!='Tuberculosis'?'dispnone':null}}">
            <td colspan=2>
              <table class="table table-bordered">
                  <tr>
                      <td>MDR</td>
                      <td>{{$log->tb_mdr}}</td>
                  </tr>
                  <tr>
                      <td>HPE</td>
                      <td>{{$log->tb_hpe}}</td>
                  </tr>
                  <tr>
                      <td>Gene expert</td>
                      <td>{{$log->tb_gene}}</td>
                  </tr>
                  <tr>
                      <td>C/S</td>
                      <td>{{$log->tb_cs}}</td>
                  </tr>
                  <tr>
                      <td>TB culture</td>
                      <td>{{$log->tb_culture}}</td>
                  </tr>
              </table>
            </td>
          </tr>
          <tr class="{{$log->infection_type!='Pyogenic'?'dispnone':null}}">
            <td colspan=2>
              <table class="table table-bordered"> 
                  <tr>
                      <td>C/S</td>
                      <td>Bacteria: {{$log->tb_pyogenic_bacteria}}<br>
                          Antibiotic sensitivity: {{$log->tb_pyogenic_antibiotic}}
                      </td>
                  </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td>Site</td>
            <td>{{$log->infection_site}}</td>
          </tr>
        </table>
      </td>
    </tr>
    <tr class="{{$log->category!='Deformity'?'dispnone':null}}">
      <td colspan=2>
        <table class="table table-bordered">
          <tr>
            <td>Deformity Type</td>
            <td>{{$log->deformity_type}}</td>
          </tr>
          <tr class="{{$log->deformity_type!='Scoliosis'?'dispnone':null}}">
            <td colspan=2>
              <table class="table table-bordered">
                <tr>
                  <td>Type</td>
                  <td>{{$log->scoliosis_type}}</td>
                </tr>
                <tr>
                  <td>Winters classification</td>
                  <td>{{$log->winter_classification}}</td>
                </tr>
                <tr class="{{$log->winter_classification!='Failure formation'?'dispnone':null}}">
                  <td>Failure formation</td>
                  <td>{{$log->winter_classification_failure_formation}}</td>
                </tr>
                <tr class="{{$log->winter_classification!='Failure of segmentation'?'dispnone':null}}">
                  <td>Failure of segmentation</td>
                  <td>{{$log->winter_classification_failure_of_segmentation}}</td>
                </tr>
                <tr>
                    <th colspan="2">
                        @php($stage=getLastSrsStage($log->patient_id))
                        @if($stage==0)
                            <i><u>Note:</u> No SRS22r questionnaire available.</i>
                        @else
                            <i><u>Note:</u> <a href="/srs22/edit/{{$stage}}/{{$log->patient_id}}">View SRS22r questionnaire</a> | <a href="/scoliosis/patient/{{$log->patient_id}}">View Scoliosis proforma</a></i>
                        @endif
                    </th>
                </tr>
              </table>
            </td>
          </tr>
          <tr class="{{$log->deformity_type!='Kyphosis'?'dispnone':null}}">
            <td colspan=2>
              <table class="table table-bordered table-striped">
                  <tr>
                      <td>Type</td>
                      <td>{{$log->kyphosis_type}}</td>
                  </tr>
                  <tr>
                      <td>Kyphosis angle</td>
                      <td>{{$log->kyphosis_angle}} {{is_null($log->kyphosis_angle)?null:"degree"}}</td>
                  </tr>
                  <tr>
                      <td>Sagital shift</td>
                      <td>{{$log->sagital_shift}}</td>
                  </tr>
                  <tr>
                      <td>PI</td>
                      <td>{{$log->kyphosis_pi}} {{is_null($log->kyphosis_pi)?null:"degree"}}</td>
                  </tr>
                  <tr>
                      <td>PT</td>
                      <td>{{$log->kyphosis_pt}} {{is_null($log->kyphosis_pt)?null:"degree"}}</td>
                  </tr>
                  <tr>
                      <td>SS</td>
                      <td>{{$log->kyphosis_ss}} {{is_null($log->kyphosis_ss)?null:"degree"}}</td>
                  </tr>
                  <tr>
                      <td>TK</td>
                      <td>{{$log->kyphosis_tk}} {{is_null($log->kyphosis_tk)?null:"degree"}}</td>
                  </tr>
                  <tr>
                      <td>LL</td>
                      <td>{{$log->kyphosis_ll}} {{is_null($log->kyphosis_ll)?null:"degree"}}</td>
                  </tr>
                </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr class="{{$log->category!='Degenerative'?'dispnone':null}}">
      <td colspan=2>
        <table class="table table-bordered">
          <tr>
            <td>Site</td>
            <td>{{$log->degenerative_site}}</td>
          </tr>
          <tr class="{{$log->degenerative_site!='Lumbar'?'dispnone':null}}">
            <td colspan=2>
              <table class="table table-bordered table-striped">
                <tr>
                    <td>Imaging findings</td>
                    <td>
                        {{$log->imagefinding}}<br>{{in_array('Others', explode(',',$log->imagefinding))?$log->imagefinding_other:null}}
                    </td>
                </tr>
                
                <tr>
                    <td>PI</td>
                    <td>{{$log->lumbar_pi}} {{is_null($log->lumbar_pi)?null:"degree"}}</td>
                </tr>
                <tr>
                    <td>PT</td>
                    <td>{{$log->lumbar_pt}} {{is_null($log->lumbar_pt)?null:"degree"}}</td>
                </tr>
                <tr>
                    <td>SS</td>
                    <td>{{$log->lumbar_ss}} {{is_null($log->lumbar_ss)?null:"degree"}}</td>
                </tr>
                <tr>
                    <td>TK</td>
                    <td>{{$log->lumbar_tk}} {{is_null($log->lumbar_tk)?null:"degree"}}</td>
                </tr>
                <tr>
                    <td>LL</td>
                    <td>{{$log->lumbar_ll}} {{is_null($log->lumbar_ll)?null:"degree"}}</td>
                </tr>
              </table>
              <!-- Oswestry Questions start-->
              <table class="table table-bordered table-striped">
                <tr >
                    <th colspan="2" class="text-white bg-dark">
                        Oswestry low back disability (questionnaire)
                    </th>
                </tr>
                
                <tr >
                    <th colspan="2">
                    <i><u>Instructions:</u> This questionnaire has been designed to give us information as to how your back or leg pain is affecting your ability to manage in everyday life. Please answer by checking ONE box in each section for the statement which best applies to you. We realise you may consider that two or more statements in any one section apply but please just shade out the spot that indicates the statement which most clearly describes your problem. </i>
                    </th>
                </tr>
                <tr>
                    <!-- <th colspan="2">Total Score: {{$log->total_oswestry_score}}</th> -->
                    <td colspan="2">
                    @if($log->category=='Degenerative' && $log->degenerative_site=='Lumbar')
                        @php($score=$log->countOswestryScoreFunction())
                        <h2><span class="badge badge-success">{{$score[3]*100}}%</span><br></h2>
                        Score: {{$score[0]}}/{{$score[2]}} <br>
                        <i>Interpretation: {{getOswestryInterpretation($score[3]*100)}}</i>
                    @endif
                    </td>
                </tr>
                @foreach($oswestryquestions as $oswestryquestion)
                <tr>
                    <td class="firstcol">{{$oswestryquestion->question}}<br><span class="badge badge-primary">{{$oswestryquestion->question_category}}</span></td>
                    <td>
                        <div class="">
                        @foreach($oswestryquestion->options as $oswestryoption)
                            <div class="custom-control custom-radio mr-2">
                                <input type="radio" class="custom-control-input sex" id="oswest{{$oswestryquestion->id}}_{{$oswestryoption->id}}" value='{{$oswestryoption->id}}' name='oswest{{$oswestryquestion->id}}' {{optionSelectedByPatientOswestry($log->id, $oswestryoption->id)?'checked':null}} disabled>
                                <label class="custom-control-label" for="oswest{{$oswestryquestion->id}}_{{$oswestryoption->id}}">{{$oswestryoption->option}}</label>
                            </div>
                        @endforeach
                        </div>
                    </td>
                </tr>
                @endforeach
              </table>
              <!-- Oswestry Questions end-->
            </td>
          </tr>
          <tr class="{{$log->degenerative_site!='Cervical'?'dispnone':null}}">
            <td colspan=2>
              <table class="table table-bordered table-striped">
                <tr>
                    <td>Imaging findings</td>
                    <td>{{$log->cervicalimagefinding}}<br>{{in_array('Others', explode(',',$log->cervicalimagefinding))?$log->cervicalimagefinding_other:null}}</td>
                </tr>
              </table>
              <!-- Japanese Questions start-->
              <table class="table table-bordered table-striped">
                  <tr >
                      <th colspan="2" class="text-white bg-dark">
                          Modified Japanese Association Score (Questionnaire)
                      </th>
                  </tr>
                  <tr>
                      <!-- <th colspan="2">Total Score: {{$log->total_japanese_score}}</th> -->
                      <th colspan="2">
                          @if($log->category=='Degenerative' && $log->degenerative_site=='Cervical')
                              @php($score=$log->countJapaneseScoreFunction())
                              <h2><span class="badge badge-success">{{$score[3]*100}}%</span><br></h2>
                              Score: {{$score[0]}}/{{$score[2]}}
                          @endif
                      </th>
                  </tr>
                  @foreach($japanesequestions as $japanesequestion)
                  <tr>
                      <td class="firstcol">{{$japanesequestion->id}}. {{$japanesequestion->question}}<br><span class="badge badge-primary">{{$japanesequestion->question_category}}</span></td>
                      <td>
                          <div class="">
                          @foreach($japanesequestion->options as $japaneseoption)
                              <div class="custom-control custom-radio mr-2">
                                  <input type="radio" class="custom-control-input sex" id="japanese{{$japanesequestion->id}}_{{$japaneseoption->id}}" value='{{$japaneseoption->id}}' name='japanese{{$japanesequestion->id}}' {{optionSelectedByPatientJapanese($log->id, $japaneseoption->id)?'checked':null}} disabled>
                                  <label class="custom-control-label" for="japanese{{$japanesequestion->id}}_{{$japaneseoption->id}}">{{$japaneseoption->option}}</label>
                              </div>
                          @endforeach
                          </div>
                      </td>
                  </tr>
                  @endforeach
              </table>
              <!-- Japanese Questions end-->
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr class="{{$log->category!='Tumours'?'dispnone':null}}">
      <td>Type</td>
      <td>{{$log->tumour_type}}</td>
    </tr>
    <tr>
        <td>Name</td>
        <td>{{$log->patientdetail->name}}</td>
    </tr>
    <tr>
        <td>DOB</td>
        <td>{{!is_null($log->patientdetail->dob) ? $log->patientdetail->dob->format('d-m-Y'):null}}</td>
    </tr>
    <tr>
        <td>Age</td>
        <td>{{$log->patientdetail->age}}</td>
    </tr>
    <tr>
        <td>Sex</td>
        <td>{{$log->patientdetail->sex}}</td>
    </tr>
    <tr>
        <td>UHID</td>
        <td>{{$log->patientdetail->uhid}}</td>
    </tr>
    <tr>
        <td>Phone no</td>
        <td>{{$log->patientdetail->phone}}</td>
    </tr>
    <tr>
        <td>Address</td>
        <td>{{$log->patientdetail->address}}</td>
    </tr>
    <tr>
        <td>Email</td>
        <td>{{$log->patientdetail->email}}</td>
    </tr>
    <tr>
        <td>Bed no</td>
        <td>{{$log->patientdetail->bed_no}}</td>
    </tr>
    <tr>
        <td>Operative details</td>
        <td>{{$log->operative_details}}</td>
    </tr>
    <tr>
        <td>Diagnosis</td>
        <td>{{$log->operative_details}}</td>
    </tr>
    <tr>
        <td>Level</td>
        <td>{{$log->level}}</td>
    </tr>
    <tr>
        <td>Treatment / Op procedure</td>
        <td>{{$log->treatment_procedure}}</td>
    </tr>
    <tr>
        <td>Comorbidities</td>
        <td>{{$log->comorbidities}}</td>
    </tr>

    <tr>
        <td class="firstcol">Surgeons</td>
        <td>{{substr($log->surgeons, 1, -1)}}</td>
    </tr>
    <tr>
        <td>Implant</td>
        <td>{{$log->implant}}</td>
    </tr>
    <tr>
        <td class="firstcol">Surgical duration</td>
        <td>{{$log->surgical_time}} {{is_null($log->surgical_time)?null:"minute(s)"}}</td>
    </tr>
    <tr>
        <td class="firstcol">Blood loss</td>
        <td>{{$log->blood_loss}} {{is_null($log->blood_loss)?null:"ml"}}</td>
    </tr>
    <tr>
        <td class="firstcol">DOA </td>
        <td>{{!is_null($log->doa) ? $log->doa->format('d-m-Y'):null}}</td>
    </tr>
    <tr>
        <td class="firstcol">DOO</td>
        <td>{{!is_null($log->doo) ? $log->doo->format('d-m-Y'):null}}</td>
    </tr>
    <tr>
        <td class="firstcol">DOD</td>
        <td>{{!is_null($log->dod) ? $log->dod->format('d-m-Y'):null}}</td>
    </tr>
    <tr id="cf-container-lastrow">
        <td class="firstcol">Post op course</td>
        <td>{{substr($log->postopcourses, 1, -1)}}<br>{{in_array("Other", explode(',',substr($log->postopcourses, 1, -1)))?$log->postopcourses_other:null}}</td>
    </tr>
  </table>
</div>
  @endsection
