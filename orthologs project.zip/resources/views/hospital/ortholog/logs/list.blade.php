@foreach($selectedlogs as $log)
<tr class='foreachtr'>
  <td>
    <div class="custom-control custom-checkbox">
      <input type="checkbox"  name='ids[]' class="idcheckbox custom-control-input idcheckbox" id="customCheck{{$log->id}}" value="{{$log->id}}" name='ids[]'>
      <label class="custom-control-label" for="customCheck{{$log->id}}">&nbsp;</label>
    </div>
  </td>
  <td><a href="/ortho/ortholog/{{$log->id}}/view/">{{caseidformat($log->id)}}</a>
    @if(count($log->relatedIds)>0)
      <br>
      <a href="javascript:void(0)" class="showrelatedcaseidlink"><span class="badge badge-primary">Related Case IDs</span></a>
      <ul class="dispnone">
        @foreach($log->relatedIds as $relatedid)
          <li><a target="_blank" href="/ortho/ortholog/{{$relatedid}}/view/">{{caseidformat($relatedid)}}</a></li>
        @endforeach
      </ul>
    @endif
  </td>
  
  <td class="naclass">{{$log->patientdetail->name}}</td>
  <td class="naclass">{{$log->patientdetail->sex}}</td>

  <td class="naclass">{{$log->patientdetail->uhid}}</td>
  <td class="naclass">
    {{$log->category}}<br>
    @if($log->category=='Traumatic')
    <span class="badge badge-success">{{$log->trauma_site}}</span>
    @endif
    @if($log->category=='Infection')
    <span class="badge badge-success">{{$log->infection_type}}</span>
    @endif
    @if($log->category=='Tumours')
    <span class="badge badge-success">{{$log->tumour_type}}</span>
    @endif
    @if($log->category=='Deformity' && $log->deformity_type=='Scoliosis')
    <a class="badge badge-success" href="/scoliosis/patient/{{$log->patient_id}}">Scoliosis</a>
    @endif
    @if($log->category=='Degenerative' && $log->degenerative_site=='Lumbar')
      @php($score=$log->countOswestryScoreFunction())
      <span class="badge badge-success">Lumbar</span>
    @endif
    @if($log->category=='Degenerative' && $log->degenerative_site=='Cervical')
      @php($score=$log->countJapaneseScoreFunction())
      <span class="badge badge-success">Cervical</span>
    @endif
  </td>
  <td class="naclass">{{substr($log->surgeons, 1, -1)}}</td>
  <td class="naclass">
    @if($log->category=='Deformity' && $log->deformity_type=='Scoliosis')
      @php($stage=getLastSrsStage($log->patient_id))
      {{$log->patientdetail->countScoreFunction($stage)}}
    @endif
    @if($log->category=='Degenerative' && $log->degenerative_site=='Lumbar')
      @php($score=$log->countOswestryScoreFunction())
      {{$score[3]*100}}%<br>
    @endif
    @if($log->category=='Degenerative' && $log->degenerative_site=='Cervical')
      @php($score=$log->countJapaneseScoreFunction())
      {{$score[3]*100}}%<br>
    @endif
  </td>
  <td class="naclass">{{$log->created_at->format('d M, Y')}}</td>
</tr>
@endforeach
