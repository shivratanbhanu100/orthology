@php($j=1)
@foreach(orthologsites() as $site)
    <li style="text-align:left;">
        <label class="filtercheckbox"><input type="checkbox"  id="site_{{$j}}" value='{{$site}}' name='site[]'> {{$site}} (<span class=>{{$sitecount[$site]}}</span>)</label>
    </li>
    @php($j++)
@endforeach