@extends('layouts.ortho.master')

@section('fixedheadercontent')

<div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">
        <h1 class="h2">{{caseidformat($log->id)}}</h1>
    </div>

    <div class="form-inline">
        <div class="btn-group btn-group-sm" role="group">
            <!-- <button type="button" class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="How this page works"><i class="fas fa-lightbulb"></i></button> -->
            <a href="/ortho/ortholog/{{$log->id}}/edit/" class="btn btn-primary btn-sm">Edit</a>
        </div>
    </div>

</div>


@endsection

@section('headercontent')

<div class="px-3 py-3">
        <div class="input-group">
            <table class="table table-bordered">
                <tr>
                    <td>Category</td>
                    <td>{{$log->category}}<input type="hidden" class="ortho_category" value="{{$log->category}}"></td>
                </tr>
            </table>
        </div>
        <div class="{{$log->category!='Traumatic'?'dispnone':null}} trauma_category_div">
            <table class="table table-bordered">
                <tr>
                    <td>Site</td>
                    <td>{{$log->trauma_site}}</td>
                </tr>
            </table>
        </div>
        <div class="{{$log->category!='Infection'?'dispnone':null}} infection_category_div">
            <div class="input-group">
                <table class="table table-bordered">
                    <tr>
                        <td>Type</td>
                        <td>{{$log->infection_type}}</td>
                    </tr>
                </table>
            </div>
            <div class="{{$log->infection_type!='Tuberculosis'?'dispnone':null}} tb_div">
                <table class="table table-bordered">
                    <tr>
                        <td>MDR</td>
                        <td>{{$log->tb_mdr}}</td>
                    </tr>
                    <tr>
                        <td>HPE</td>
                        <td>{{$log->tb_hpe}}</td>
                    </tr>
                    <tr>
                        <td>Gene expert</td>
                        <td>{{$log->tb_gene}}</td>
                    </tr>
                    <tr>
                        <td>C/S</td>
                        <td>{{$log->tb_cs}}</td>
                    </tr>
                    <tr>
                        <td>TB culture</td>
                        <td>{{$log->tb_culture}}</td>
                    </tr>
                </table>
            </div>
            <div class="{{$log->infection_type!='Pyogenic'?'dispnone':null}} pyogenic_div">
                <table class="table table-bordered"> 
                    <tr>
                        <td>C/S</td>
                        <td>
                            <table class="table table-bordered">
                                <tr>
                                    <td>Bacteria</td>
                                    <td>{{$log->tb_pyogenic_bacteria}}</td>
                                </tr>
                                <tr>
                                    <td>Antibiotic sensitivity</td>
                                    <td>{{$log->tb_pyogenic_antibiotic}}</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="input-group" id="infection_site_div">
                <table class="table table-bordered">
                    <tr>
                        <td>Site</td>
                        <td>{{$log->infection_site}}</td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="{{$log->category!='Deformity'?'dispnone':null}} deformity_category_div">
            <div class="input-group deformity_type_tr">
                <table class="table table-bordered">
                    <tr>
                        <td>Deformity Type</td>
                        <td>{{$log->deformity_type}}</td>
                    </tr>
                </table>
            </div>
            <div class="{{$log->deformity_type!='Scoliosis'?'dispnone':null}} deformity_scoliosis_div">
                <div class="input-group">
                    <table class="table table-bordered">
                        <tr>
                            <td>Type</td>
                            <td>{{$log->scoliosis_type}}</td>
                        </tr>
                    </table>
                </div>
                <table class="table table-bordered table-striped">
                    <tr>
                        <th colspan="2">
                            @php($stage=getLastSrsStage($log->patient_id))
                            @if($stage==0)
                                <i><u>Note:</u> You will be redirected to SRS22r questionnaire in the next step.</i>
                            @else
                                <i><u>Note:</u> <a href="/srs22/edit/{{$stage}}/{{$log->patient_id}}">View SRS22r questionnaire</a> | <a href="/scoliosis/patient/{{$log->patient_id}}">View Scoliosis profile</a></i>
                            @endif
                        </th>
                    </tr>
                </table>
            </div>
            <div class="{{$log->deformity_type!='Kyphosis'?'dispnone':null}} deformity_kyphosis_div">
                <table class="table table-bordered table-striped">
                    <tr>
                        <td>Type</td>
                        <td>{{$log->kyphosis_type}}</td>
                    </tr>
                    <tr>
                        <td>Kyphosis angle</td>
                        <td>{{$log->kyphosis_angle}} degree</td>
                    </tr>
                    <tr>
                        <td>Sagital shift</td>
                        <td>{{$log->sagital_shift}}</td>
                    </tr>
                    <tr>
                        <td>PI</td>
                        <td>{{$log->kyphosis_pi}} degree</td>
                    </tr>
                    <tr>
                        <td>PT</td>
                        <td>{{$log->kyphosis_pt}} degree</td>
                    </tr>
                    <tr>
                        <td>SS</td>
                        <td>{{$log->kyphosis_ss}} degree</td>
                    </tr>
                    <tr>
                        <td>TK</td>
                        <td>{{$log->kyphosis_tk}} degree</div>
                        </td>
                    </tr>
                    <tr>
                        <td>LL</td>
                        <td>{{$log->kyphosis_ll}} degree</div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="{{$log->category!='Degenerative'?'dispnone':null}} degenerative_category_div">
            <div class="input-group degenerative_site_tr">
                <table class="table table-bordered">
                    <tr>
                        <td>Site</td>
                        <td>{{$log->degenerative_site}}</td>
                    </tr>
                </table>
            </div>
            <div class="{{$log->degenerative_site!='Lumbar'?'dispnone':null}} lumbar_site_div">
                <table class="table table-bordered">
                    <tr>
                        <td>Imaging findings</td>
                        <td>
                            {{$log->imagefinding}}<br>
                            {{$log->imagefinding_other}}
                        </td>
                    </tr>
                    
                    <tr>
                        <td>PI</td>
                        <td>{{$log->lumbar_pi}} degree</td>
                    </tr>
                    <tr>
                        <td>PT</td>
                        <td>{{$log->lumbar_pt}} degree</td>
                    </tr>
                    <tr>
                        <td>SS</td>
                        <td>{{$log->lumbar_ss}} degree</td>
                    </tr>
                    <tr>
                        <td>TK</td>
                        <td>{{$log->lumbar_tk}} degree</td>
                    </tr>
                    <tr>
                        <td>LL</td>
                        <td>{{$log->lumbar_ll}} degree</td>
                    </tr>
                </table>
                <!-- Oswestry low back disability (questionnaire)-->
                <table class="table table-bordered table-striped">
                    <tr >
                        <th colspan="2" class="text-white bg-dark">
                            Oswestry low back disability (questionnaire)
                        </th>
                    </tr>
                    
                    <tr >
                        <th colspan="2">
                        <i><u>Instructions:</u> This questionnaire has been designed to give us information as to how your back or leg pain is affecting your ability to manage in everyday life. Please answer by checking ONE box in each section for the statement which best applies to you. We realise you may consider that two or more statements in any one section apply but please just shade out the spot that indicates the statement which most clearly describes your problem. </i>
                        </th>
                    </tr>
                    <tr>
                        <!-- <th colspan="2">Total Score: {{$log->total_oswestry_score}}</th> -->
                        <td colspan="2">
                        @if($log->category=='Degenerative' && $log->degenerative_site=='Lumbar')
                            @php($score=$log->countOswestryScoreFunction())
                            <span class="badge badge-success">Score:{{$score[0]}}/{{$score[2]}} = {{$score[3]*100}}%</span><br>
                            {{getOswestryInterpretation($score[3]*100)}}
                        @endif
                        </td>
                    </tr>
                    @foreach($oswestryquestions as $oswestryquestion)
                    <tr>
                        <td class="firstcol">{{$oswestryquestion->question}}<br><span class="badge badge-primary">{{$oswestryquestion->question_category}}</span></td>
                        <td>
                            <div class="">
                            @foreach($oswestryquestion->options as $oswestryoption)
                                <div class="custom-control custom-radio mr-2">
                                    <input type="radio" class="custom-control-input sex" id="oswest{{$oswestryquestion->id}}_{{$oswestryoption->id}}" value='{{$oswestryoption->id}}' name='oswest{{$oswestryquestion->id}}' {{optionSelectedByPatientOswestry($log->id, $oswestryoption->id)?'checked':null}}>
                                    <label class="custom-control-label" for="oswest{{$oswestryquestion->id}}_{{$oswestryoption->id}}">{{$oswestryoption->option}}</label>
                                </div>
                            @endforeach
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </table>
            </div>
            <div class="{{$log->degenerative_site!='Cervical'?'dispnone':null}} cervical_site_div">
                <table class="table table-bordered">
                    <tr>
                        <td>Imaging findings</td>
                        <td>{{$log->cervicalimagefinding}}<br>{{$log->cervicalimagefinding_other}}</td>
                    </tr>
                </table>
                <!-- Modified Japanese Association Score (Questionnaire)-->
                <table class="table table-bordered table-striped">
                    <tr >
                        <th colspan="2" class="text-white bg-dark">
                            Modified Japanese Association Score (Questionnaire)
                        </th>
                    </tr>
                    <tr>
                        <!-- <th colspan="2">Total Score: {{$log->total_japanese_score}}</th> -->
                        <th colspan="2">
                            @if($log->category=='Degenerative' && $log->degenerative_site=='Cervical')
                                @php($score=$log->countJapaneseScoreFunction())
                                <span class="badge badge-success">Score:{{$score[0]}}/{{$score[2]}} = {{$score[3]*100}}%</span>
                            @endif
                        </th>
                    </tr>
                    @foreach($japanesequestions as $japanesequestion)
                    <tr>
                        <td class="firstcol">{{$japanesequestion->id}}. {{$japanesequestion->question}}<br><span class="badge badge-primary">{{$japanesequestion->question_category}}</span></td>
                        <td>
                            <div class="">
                            @foreach($japanesequestion->options as $japaneseoption)
                                <div class="custom-control custom-radio mr-2">
                                    <input type="radio" class="custom-control-input sex" id="japanese{{$japanesequestion->id}}_{{$japaneseoption->id}}" value='{{$japaneseoption->id}}' name='japanese{{$japanesequestion->id}}' {{optionSelectedByPatientJapanese($log->id, $japaneseoption->id)?'checked':null}}>
                                    <label class="custom-control-label" for="japanese{{$japanesequestion->id}}_{{$japaneseoption->id}}">{{$japaneseoption->option}}</label>
                                </div>
                            @endforeach
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </table>
            </div>
        </div>
        <div class="{{$log->category!='Tumours'?'dispnone':null}} tumour_category_div" id="tumour_category_div">
            <table class="table table-bordered">
                <tr>
                    <td>Type</td>
                    <td>{{$log->tumour_type}}</td>
                </tr>
            </table>
        </div>
        <div class="misc_category_div">

        </div>
        @include('hospital.ortholog.logs.cf.view')
</div>
@endsection
