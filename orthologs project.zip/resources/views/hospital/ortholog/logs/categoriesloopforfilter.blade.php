@php($i=1)
@foreach(orthologcategories() as $category)
    <li>
        <label class="filtercheckbox"><input type="checkbox" id="category_{{$i}}" value='{{$category}}' name='categories[]'> {{$category}} (<span class=>{{$catcount[$category]}}</span>)</label>            
    </li>
    @php($i++)
@endforeach