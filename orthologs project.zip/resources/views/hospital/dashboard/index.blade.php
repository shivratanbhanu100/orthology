@extends('layouts.hospital.master')

@section('fixedheadercontent')

  <div class="d-flex justify-content-between flex-wrap align-items-center px-3 pt-2 pb-3">

    <div class="d-flex justify-content-start flex-wrap align-items-center ">

      <h1 class="h2">Dashboard</h1>


    </div>

    <div class="form-inline">


      <div id="momentdaterange">
          <i class="fa fa-calendar"></i>&nbsp;
          <span></span> <i class="fa fa-caret-down"></i>
      </div>      
      <input type="hidden" class="momentstartdate" value="{{date('Y-m-d', strtotime('-6 months', strtotime(date('Y-m-d'))))}}">
      <input type="hidden" class="momentenddate" value="{{date('Y-m-d')}}">

      <!-- <div class="btn-group btn-group-sm" role="group">
        <a class="exportbutton btn btn-outline-secondary" exportfilename="exportfilename" data-toggle="tooltip" data-placement="bottom" title="Export">
          <i class="fas fa-download"></i>
        </a>
      </div> -->

      <button type="button" class="btn btn-sm btn-danger ml-2 deletebutton denominatordel">
        <i class="fas fa-trash-alt"></i> Delete
      </button>

    </div>

  </div>

@endsection


@section('headercontent')

<div class="dash_full">

  <div class="ml-3 mr-3">
    <div class="scholiosisdashboardcontent">
        @include("hospital.dashboard.dashboardmeans")
    </div>
    <div class="row mt-3">

      <div class="col-6">
        <div class="card" >
          <div class="card-body">
            <p class="card-text">
              <!-- <img class="graph" src="/images/pie.png"> -->
              {!! $chartsex->container() !!}
              {!! $chartsex->script() !!}
          </div>
        </div>        
      </div>       
      <div class="col-6">
        <div class="card" >
          <div class="card-body">
            <p class="card-text">
              <!-- <img class="graph" src="/images/age-bar.png"> -->
              {!! $chartage->container() !!}
              {!! $chartage->script() !!}
          </div>
        </div>        
      </div>       
      

    </div>
<!--
    <div class="row mt-3">

      <div class="col-6">
        <div class="card" >
          <div class="card-body">
            <p class="card-text">

              <table class="table">
                <tr>
                  <th>Domain (Postop F/U2)</th>
                  <th>Avg score</th>
                  <th>Standard devidation</th>
                  <th>Max</th>
                  <th>Min</th>
                </tr>

                <tr>
                  <td>Function</td>
                  <td>4.3</td>
                  <td>0.18</td>
                  <td>4.6</td>
                  <td>4.0</td>
                </tr>                
                <tr>
                  <td>Pain</td>
                  <td>4.3</td>
                  <td>0.18</td>
                  <td>4.9</td>
                  <td>4.3</td>
                </tr>                
                <tr>
                  <td>Self image</td>
                  <td>3.8</td>
                  <td>0.2</td>
                  <td>4.2</td>
                  <td>3.4</td>
                </tr>                
                <tr>
                  <td>Mental health</td>
                  <td>4.4</td>
                  <td>0.3</td>
                  <td>5.0</td>
                  <td>3.8</td>
                </tr>                
                <tr>
                  <td>Satisfaction with management</td>
                  <td>4.3</td>
                  <td>0.3</td>
                  <td>4.8</td>
                  <td>3.5</td>
                </tr>                
                <tr>
                  <td>Mean</td>
                  <td>4.26</td>
                  <td>0.014</td>
                  <td>4.5</td>
                  <td>4.0</td>
                </tr>                

              </table>

          </div>
        </div>        
      </div>  

      <div class="col-6">
        <div class="card" >
          <div class="card-body">
            <p class="card-text">
              <img class="graph" src="/images/cobb.png" style="max-height: 396px;">
          </div>
        </div>        
      </div>       
     

    </div> 
    {{-- Row end --}}

    <div class="row mt-3">

      <div class="col-6">
        <div class="card" >
          <div class="card-body">
            <p class="card-text">
              <img class="graph" src="/images/classi-bar-grey.png">
          </div>
        </div>        
      </div>       
      <div class="col-6">
        <div class="card" >
          <div class="card-body">
            <p class="card-text">
              <img class="graph" src="/images/impr-bar.png">
          </div>
        </div>        
      </div>       
     

    </div>

    {{-- Row end========= --}} -->


  </div>  

</div>

@endsection


@section('tablecontent')
  <!--table starts here-->


@endsection
