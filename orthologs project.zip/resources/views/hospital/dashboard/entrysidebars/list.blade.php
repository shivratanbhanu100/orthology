entrysidebarlist snippet 
