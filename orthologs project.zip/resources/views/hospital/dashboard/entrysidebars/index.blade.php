entrysidebarindex snippet 
