<div class="row">
  <div class="col-sm">
    <div class="card" >
      <div class="card-body">
        <p class="card-text">
          <span class="cardhead">Preoperative</span>
          <br>
          <span class="text-muted">functional score mean</span></p>
        <h1 class="card-title"><b>{{countFunctionalMean(1,$startdate,$enddate)}}/5</b></h1>
      </div>
    </div>        
  </div>

  <div class="col-sm">
    <div class="card" >
      <div class="card-body">
        <p class="card-text">
          <span class="cardhead">Postoperative</span>
          <br>
          <span class="text-muted">functional score mean</span></p>
        <h1 class="card-title"><b>{{countFunctionalMean(2,$startdate,$enddate)}}/5</b></h1>
      </div>
    </div>        
  </div>

  <div class="col-sm">
    <div class="card" >
      <div class="card-body">
        <p class="card-text">
          <span class="cardhead">Postop F/U 1</span>
          <br>
          <span class="text-muted">functional score mean</span></p>
        <h1 class="card-title"><b>{{countFunctionalMean(3,$startdate,$enddate)}}/5</b></h1>
      </div>
    </div>        
  </div>     
  
  <div class="col-sm">
    <div class="card" >
      <div class="card-body">
        <p class="card-text">
          <span class="cardhead">Postop F/U 2</span>
          <br>
          <span class="text-muted">functional score mean</span></p>
        <h1 class="card-title"><b>{{countFunctionalMean(4,$startdate,$enddate)}}/5</b></h1>
      </div>
    </div>        
  </div>           


</div> 
  {{-- row ends here================== --}}

