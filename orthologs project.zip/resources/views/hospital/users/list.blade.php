@foreach($users as $user)
<tr class="foreachtr">
    <td>
        @if($user->id!=\Auth::user()->id)
            <div class="custom-control custom-checkbox">
            <input type="checkbox"  name='ids[]' class="idcheckbox custom-control-input idcheckbox" id="customCheck{{$user->id}}" value="{{$user->id}}" name='ids[]'>
            <label class="custom-control-label" for="customCheck{{$user->id}}">&nbsp;</label>
            </div>
        @endif
    </td>
    <td>{{$user->name}}</td>
    <td><a href="/user/{{$user->id}}/view">{{$user->email}}</a></td>
    <td>{{$user->role}}</td>
    <td>{{$user->created_at->format('dS M, Y')}}</td>
</tr>
@endforeach