// Codepenters template js starts here=========================================

var delay = 0;
var offset = 160;

document.addEventListener('invalid', function(e){
   $(e.target).addClass("invalid");
   $('html, body').animate({scrollTop: $($(".invalid")[0]).offset().top - offset }, delay);
}, true);
document.addEventListener('change', function(e){
   $(e.target).removeClass("invalid")
}, true);


// Datepicker==================================================
$(function() {

  var start = moment().subtract(6, 'months');
  var end = moment();

  function cb(start, end) {
      $('#momentdaterange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
      $('.momentstartdate').val(start.format('YYYY-MM-DD'))
      $('.momentenddate').val(end.format('YYYY-MM-DD'))
      dashboardorthofilter()
      dashboardfilter()
      // $(".dashboardfilter").click();
  }

  $('#momentdaterange').daterangepicker({
      startDate: start,
      endDate: end,
      ranges: {
         'Today': [moment(), moment()],
         'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
         'Last 7 Days': [moment().subtract(6, 'days'), moment()],
         'Last 30 Days': [moment().subtract(29, 'days'), moment()],
         'This Month': [moment().startOf('month'), moment().endOf('month')],
         'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
      }
  }, cb);

  cb(start, end);

});
function dashboardfilter(){
  var startdate=$('.momentstartdate').val();
  var enddate=$('.momentenddate').val();
  var token=$("input[name='_token']").val();
  $.ajax({
    type: "post",
    url: "/scoliosis/dashboardfilter",
    data:{'startdate':startdate,'enddate':enddate,'_token':token},
    success: function (data) {
      $(".scholiosisdashboardcontent").html(data);
    }
  });
}
function dashboardorthofilter(){
  var startdate=$('.momentstartdate').val();
  var enddate=$('.momentenddate').val();
  var token=$("input[name='_token']").val();
  $.ajax({
    type: "post",
    url: "/ortho/dashboardfilter",
    data:{'startdate':startdate,'enddate':enddate,'_token':token},
    success: function (data) {
      $(".totalspan").html(data[0]);
      $(".countspan").html(data[1]);
      $(".meanspan").html(data[2]);
      // $(".scholiosisdashboardcontent").html(data);
    }
  });
}
$(".submittype").click(function(){
  var dasboardval=$(this).attr('dasboardval');
  $("input[name='dashboard']").val(dasboardval);
  $("#formsubmitbtn").click();
});
// Flash message===============================================
$(document).ready(function(){
    setTimeout(function(){  $('.flash_msg').hide();}, 8000);
    token=$('input[name=_token]').val();
    $('.datepicker').datepicker({
      format: "dd-mm-yyyy",
      autoclose: true,
      todayHighlight: true,
      onSelect: function(d,i){
        if(d !== i.lastVal){
            $(this).change();
        }
      }
      });

      $('.daterangepickerdiv .input-daterange').datepicker({
          format: "dd-mm-yyyy",
          orientation: "bottom right",
          autoclose: true,
          todayHighlight: true
      }).keydown(function(e){
        if (e.keyCode === 8) { return false; }
        e.preventDefault();
      });

});


// Submenu in sidenav==========================================

$('.menuparent').click(function(){
  expandSideNav();
  $(this).next().toggle(600);
  var status=$(this).next().attr('status');
  if (status=='hidden') {
    $(this).find('.dropdownicon').addClass ('fa-rotate-90');
    $(this).next().attr('status','shown');
  } else {
    $(this).find('.dropdownicon').removeClass ('fa-rotate-90');
    $(this).next().attr('status','hidden');
  }
});


//Checkbox for delete=========================================

//Select all checkbox=========================================
$(document).on('click','.selectall',function(){
    if($(this).val()==0){
      $(this).val(1);

      $('input[name="ids[]"]').prop('checked',true).attr('checked');
    }
    else{
        $(this).val(0);

        $('input[name="ids[]"]').prop('checked',false).removeAttr('checked');
    }

      var arr = $('.idcheckbox:checked').map(function () {
      return this.value; // $(this).val()
  }).get();

  if(arr!=''){
    $('.deletebutton,.patientrecorddeletebutton,.usersdeletebutton,.deleteorthorecord,.markaseligibleagent').show(300);
  }
  else{
   $('.deletebutton,.patientrecorddeletebutton,.usersdeletebutton,.deleteorthorecord,.markaseligibleagent').hide(300);
  }
});

//Individual checkbox==========================================

$(document).on('click','.idcheckbox',function(){
   $('.selectall').prop('checked',false).removeAttr('checked');
   $('.selectall').val(0);
   var arr = $('.idcheckbox:checked').map(function () {
      return this.value; // $(this).val()
  }).get();

   if(arr!=''){
    $('.deletebutton,.patientrecorddeletebutton,.usersdeletebutton,.deleteorthorecord,.markaseligibleagent').show(300);
  }
  else{
   $('.deletebutton,.patientrecorddeletebutton,.usersdeletebutton,.deleteorthorecord,.markaseligibleagent').hide(300);
  }
});

//Functionality of delete button===============================
$(document).on('click','.deletebutton', function(){
   var id = $('.idcheckbox:checked').map(function () {
      return this.value; // $(this).val()
  }).get();

  var pagename=$('.pagename').val();
  var deltype=$('.deltype').val();

  if (deltype=='permdelete') {
    path='/permdelete';
  }
  else {
    path='/tempdelete';
  }

    if(confirm('Confirm delete')){
           thiselement=$(this);
           thiselement.attr('disabled','disabled');
         $.ajax({
                type:'post',
                url: path,
                data:{'id':id,'pagename':pagename,'deltype':deltype,'_token':token},
                success:function(data){
                  console.log(data);

                //$('.outerdiv').load(document.URL +  ' .innerdiv'); //Load innerdiv into outerdiv through Ajax
                  window.location.reload(); //Reload page
                },
                error: function(data){
                console.log(data);
                }
            });
       }
});
$(document).on('click','.patientrecorddeletebutton', function(){
   var id = $('.idcheckbox:checked').map(function () {
      return this.value; // $(this).val()
  }).get();
    path='/deletepatientrecord';

    if(confirm('Data related to the selected patients will get deleted. Press ok to continue')){
           thiselement=$(this);
           thiselement.attr('disabled','disabled');
         $.ajax({
                type:'post',
                url: path,
                data:{'id':id,'_token':token},
                success:function(data){
                  console.log(data);

                //$('.outerdiv').load(document.URL +  ' .innerdiv'); //Load innerdiv into outerdiv through Ajax
                  window.location.reload(); //Reload page
                },
                error: function(data){
                console.log(data);
                }
            });
       }
});
$(document).on('click','.usersdeletebutton', function(){
   var id = $('.idcheckbox:checked').map(function () {
      return this.value; // $(this).val()
  }).get();
    path='/deleteusers';

    if(confirm('User(s) will get deleted. Press ok to continue')){
           thiselement=$(this);
           thiselement.attr('disabled','disabled');
         $.ajax({
                type:'post',
                url: path,
                data:{'id':id,'_token':token},
                success:function(data){
                  console.log(data);

                //$('.outerdiv').load(document.URL +  ' .innerdiv'); //Load innerdiv into outerdiv through Ajax
                  window.location.reload(); //Reload page
                },
                error: function(data){
                console.log(data);
                }
            });
       }
});
$(document).on('click','.deleteorthorecord', function(){
   var id = $('.idcheckbox:checked').map(function () {
      return this.value; // $(this).val()
  }).get();
    path='/deleteorthorecord';

    if(confirm('This log will get deleted. Press ok to continue')){
           thiselement=$(this);
           thiselement.attr('disabled','disabled');
         $.ajax({
                type:'post',
                url: path,
                data:{'id':id,'_token':token},
                success:function(data){
                  console.log(data);

                //$('.outerdiv').load(document.URL +  ' .innerdiv'); //Load innerdiv into outerdiv through Ajax
                  window.location.reload(); //Reload page
                },
                error: function(data){
                console.log(data);
                }
            });
       }
});

// Tabpane change links======================================

$('#tablink1').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=1");
});

$('#tablink2').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=2");
});

$('#tablink3').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=3");
});

$('#tablink4').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=4");
});

$('#tablink5').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=5");
});

$('#tablink6').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=6");
});

$('#tablink7').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=7");
});

$('#tablink8').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=8");
});

$('#tablink9').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=9");
});

$('#tablink10').click(function(){
  var loc = location.href;
  locs=loc.split('?');
  window.history.pushState('obj', 'basic details', locs[0] + "?type=10");
});


//Search box case sensitive off commands======================
jQuery.expr[':'].Contains = function(a, i, m) {
  return jQuery(a).text().toUpperCase().indexOf(m[3].toUpperCase()) >= 0;
};
jQuery.expr[':'].contains = function(a, i, m) {
  return jQuery(a).text().toUpperCase().indexOf(m[3].toUpperCase()) >= 0;
};

// case sensitive command ends================================

$(document).on('keyup','.searchbox',function(){
  var text=$('.searchbox').val();
  $(".foreachtr").hide();
    $(".foreachtr:contains("+text+")").show();
    //$('.modal-body').find('tr').show(); //Search exception
});

$('#categoryfilter').change(function(){
    var text=$(this).val();
    searchInTable(text);
})

$('#filter1').change(function(){
    var text1=$('#filter1').val();
    var text2=$('#filter2').val();
    doubleSearchInTable(text1,text2);
})

$('#filter2').change(function(){
    var text1=$('#filter1').val();
    var text2=$('#filter2').val();
    doubleSearchInTable(text1,text2);
})

$('.datefilter').click(function(){
  var startdate=$('.startdate').val();
  var enddate=$('.enddate').val();

  var page=$(this).prev().val();

  if (page=='transaction'){
    var path='/transactiondatefilter';
  }
  else if (page=='vendorpayment'){
    var path='/vendorpaymentdatefilter';
  }

  if (startdate==''||enddate==''){
    alert('Please select a date range to apply filter');
  }
  else {
    applyDateFilter(startdate, enddate, path, token)
  }
})


// Default functions===========================================
function applyDateFilter(startdate, enddate, path, token) {

  $.ajax({
         type:'post',
         url: path,
         data:{'startdate':startdate,'enddate':enddate,'_token':token},
         success:function(data){
           console.log(data);
           $('tbody').html(data);
         },
         error: function(data){
         console.log(data);
         }
     });

}

function searchInTable(text) {
  $(".foreachtr").hide();
  $(".foreachtr:contains("+text+")").show();
  $('.modal-body').find('tr').show(); //Search exception
}

function doubleSearchInTable(text1, text2) {
  $(".foreachtr").hide();
  $(".foreachtr:contains("+text1+"):contains("+text2+")").show();
  $('.modal-body').find('tr').show(); //Search exception
}


// New for bootstrap 4========================================

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

$('.extendbox').focus(function()
{
  $(this).animate({ width: '+=40' }, 300);
}).blur(function()
{
  $(this).animate({ width: '-=40' }, 300);
});

$('.navtoggle').click(function(){
  var status=$(this).attr('status');
  if (status=='expanded') {
    collapseSideNav();
  } else {
    expandSideNav();
  }
})

function collapseSideNav(){
  $('.sidebar').animate({ width: 60 }, 300);
  $('.sidebar .navtext').hide(300);
  $('.sidebar .badge').hide(300);
  $('.sidebar .sidebar-heading span').hide(300);
  $('.sidebar').animate({ 'font-size': 20 }, 300);
  $('.sidebar').css('text-align', 'center');
  // $('.fixedheader').animate({ 'padding-left': 56 }, 300);
  $('.navtoggle').addClass ('fa-rotate-180');
  $('.navtoggle').attr ('status','collapsed');
  $('.stickynav').css('position', 'sticky');
  $('.stickynav').css('overflow-y', 'visible');
  $('.tool').attr('data-toggle','tooltip');
  $('.dropdownicon').hide(300);
  $('.submenu').hide();
  $('.submenu').attr('status','hidden');
  var sideBarRequiredHeight=($(window).height())-98;
  $('.sidebar').css('min-height',sideBarRequiredHeight);
}

function expandSideNav(){
  $('.sidebar').animate({ 'font-size': 14 }, 0);
  $('.sidebar').animate({ width: 200 }, 0);
  $('.sidebar .navtext').show(0);
  $('.sidebar .badge').show(300);
  $('.sidebar .sidebar-heading span').show(300);
  $('.sidebar').css('text-align', 'left');
  // $('.fixedheader').animate({ 'padding-left': 198 }, 0);
  $('.navtoggle').removeClass ('fa-rotate-180');
  $('.navtoggle').attr ('status','expanded');
  $('.stickynav').css('position', 'fixed');
  $('.stickynav').css('overflow-y', 'auto');
  $('.tool').attr('data-toggle','tooltip');
  $('.dropdownicon').show(300);
  $('.sidebar').css('min-height','auto');
  $('.sidebar').find('.dropdownicon').removeClass ('fa-rotate-90');
}

/*Application specific js will start from here==========================================*/


$('.addmorefieldslink').click(function(){
  $('.optionalfields').toggle(300);
});
$(document).on('click','.cleardate', function(){
    $(this).parent().prev().val('');
});
$('[data-toggle="tooltip"]').tooltip();

// SSI Code
$('.logfilter').click(function(){
  var startdate=$('.momentstartdate').val();
  var enddate=$('.momentenddate').val();
  var categories = $("input[name='categories[]']:checked").map(function () {
    return this.value; // $(this).val()
  }).get();
  var site = $("input[name='site[]']:checked").map(function () {
    return this.value; // $(this).val()
  }).get();
  $.ajax({
    type: "post",
    url: "/ortho/getfilteredlog",
    data:{'startdate':startdate,'enddate':enddate,'categories':categories,'_token':token},
    success: function (data) {
      console.log(data.tablecontent);
     $('.tbodycontainer').html(data.tablecontent);
     $('.categoryloopcontent').html(data.catcount);
     $('.siteloopcontent').html(data.sitecount);
     $("input[name='categories[]']").each(function(){
      var thisel=this.value;
      var found=categories.find(function(element) { 
                return element ==thisel; 
              }); 
      if(found){
        this.checked =true;
      }
     });
    }
  });
});

$(".togglepatientdetails").click(function(){
  $(".patientdetailrows").toggle(300);
  $(".fa-arrow-circle-right").toggle();
  $(".fa-arrow-circle-down").toggle();
});
$("#winters_classification").change(function(){
  if(this.value=="Failure formation"){
    $(".failure_formation_tr").show();
    $(".failure_of_segmentation_tr").hide();
  }
  else if(this.value=="Failure of segmentation"){
    $(".failure_of_segmentation_tr").show();
    $(".failure_formation_tr").hide();
  }
  else if(this.value=="Mixed"){
    $(".failure_of_segmentation_tr").hide();
    $(".failure_formation_tr").hide();
  }
  else if(this.value==""){
    $(".failure_of_segmentation_tr").hide();
    $(".failure_formation_tr").hide();
  }
});

$("#checknewuhid").keyup(function(){
  if(this.value.length>2){

    var uhid=this.value;
    $.ajax({
      type: "post",
      url: "/checkuniqueuhid",
      data: {'_token':token,'uhid':uhid},
      success: function (response) {
        if(response[0]==1){
          $(".successspan").show();
          $(".dangerspan").hide();
             
        }
        else{
          $(".successspan").hide();
          $(".dangerspan").show(); 
          console.log(response[1]);
          $("input[name='sex'][value='"+response[1].sex+"']").prop('checked', true);   
          $("input[name='patient_name']").val(response[1].name);       
          $("input[name='age']").val(response[1].age);       
          $("textarea[name='diagnosis']").html(response[1].diagnosis);       
          $("input[name='uhid']").val(response[1].uhid); 
          
          if (response[1].dob !== null){
            var dob = moment(response[1].dob);
            $("select[name='dob_year']").val(dob.format('YYYY'))
            $("select[name='dob_month']").val(dob.format('MM'))
            $("select[name='dob_date']").val(dob.format('DD'))
          }
        }
      }
    });
  }
  else{
  }
})
$(document).on('change',"select[name='dob_month'],select[name='dob_date'],select[name='dob_year']", function(){
  dob_date=$("select[name='dob_date']").val();
  dob_month=$("select[name='dob_month']").val();
  dob_year=$("select[name='dob_year']").val();
  if(dob_date!='' && dob_month!='' && dob_year!=''){
      dob=dob_year+"-"+dob_month+"-"+dob_date
      dob = new Date(dob);
      var today = new Date();
      var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
      age=age<0 ? 0 : age;
      $("input[name='age']").val(age);
  }

});
$(".disableclass").find("input,select,textarea").attr("disabled","disabled")


// ortho log js


$('.addmorefieldslink').click(function(){
  $('.optionalfields').toggle(300);
});
$(document).on('click','.cleardate', function(){
    $(this).parent().prev().val('');
});
$('[data-toggle="tooltip"]').tooltip();

// SSI Code
$('.logfilter').click(function(){
  var startdate=$('.momentstartdate').val();
  var enddate=$('.momentenddate').val();
  var categories = $("input[name='categories[]']:checked").map(function () {
    return this.value; // $(this).val()
  }).get();
  var site = $("input[name='site[]']:checked").map(function () {
    return this.value; // $(this).val()
  }).get();

  $.ajax({
    type: "post",
    url: "/ortho/getfilteredlog",
    data:{'startdate':startdate,'enddate':enddate,'categories':categories,'site':site,'_token':token},
    success: function (data) {
     $('.tbodycontainer').html(data.tablecontent);
     $('.categoryloopcontent').html(data.catcount);
     $('.siteloopcontent').html(data.sitecount);
     $("input[name='categories[]']").each(function(){
      var thisel=this.value;
      var found=categories.find(function(element) { 
                return element ==thisel; 
              }); 
      if(found){
        this.checked =true;
      }
     });
    
    }
  });
});
$(document).on("click",".showrelatedcaseidlink", function(){
  $(this).next().show();
  // $(this).hide();
})
$(document).on('click', '.dropdown-menu.dropdown-menu-form', function(e) {
  e.stopPropagation();
});
$(document).on('change', '.ortho_category', function(e) {
  if(this.value=='Traumatic'){
    $(".trauma_category_div").show();
    $(".infection_category_div").hide();
    $(".deformity_category_div").hide();
    $(".degenerative_category_div").hide();
    $(".tumour_category_div").hide();
    $(".misc_category_div").hide();
    $(".cf-container").hide();
    $("#cf-container").insertAfter($("select[name='trauma_site']"));
    
  }
  else if(this.value=='Infection'){
    $(".infection_category_div").show();
    $(".trauma_category_div").hide();
    $(".deformity_category_div").hide();
    $(".degenerative_category_div").hide();
    $(".tumour_category_div").hide();
    $(".misc_category_div").hide();
    $(".cf-container").hide();
    $("#cf-container").insertAfter($("#infection_site_div"));
    $(".tb_div").insertAfter($("#cf-container"));
    $(".pyogenic_div").insertAfter($("#cf-container"));
    // $("#cf-container").insertAfter($("select[name='infection_type']"));
    // $("#infection_site_div").insertAfter($("#cf-container"));
  }
  else if(this.value=='Deformity'){
    $(".deformity_category_div").show();
    $(".infection_category_div").hide();
    $(".trauma_category_div").hide();
    $(".degenerative_category_div").hide();
    $(".tumour_category_div").hide();
    $(".misc_category_div").hide();
    $(".cf-container").hide();
    $("#cf-container").insertAfter($("select[name='deformity_type']"));
  }
  else if(this.value=='Degenerative'){
    $(".degenerative_category_div").show();
    $(".deformity_category_div").hide();
    $(".infection_category_div").hide();
    $(".trauma_category_div").hide();
    $(".tumour_category_div").hide();
    $(".misc_category_div").hide();
    $(".cf-container").hide();
    $("#cf-container").insertAfter($("select[name='degenerative_site']"));
    
  }
  else if(this.value=='Tumours'){
    $(".tumour_category_div").show();
    $(".degenerative_category_div").hide();
    $(".deformity_category_div").hide();
    $(".infection_category_div").hide();
    $(".trauma_category_div").hide();
    $(".misc_category_div").hide();
    $(".cf-container").show();
    $("#cf-container").insertAfter($("#tumour_category_div"));
  }
  else if(this.value=='Misc'){
    $(".misc_category_div").show();
    $(".tumour_category_div").hide();
    $(".degenerative_category_div").hide();
    $(".deformity_category_div").hide();
    $(".infection_category_div").hide();
    $(".trauma_category_div").hide();
    $(".cf-container").show();
    $("#cf-container").insertAfter($("#misc_category_div"));
  }
});
if($(".ortho_category").val()=='Traumatic'){
  $("#cf-container").insertAfter($("select[name='trauma_site']"));
}
else if($(".ortho_category").val()=='Infection'){
  $("#cf-container").insertAfter($("#infection_site_div"));
  $(".tb_div").insertAfter($("#cf-container"));
  $(".pyogenic_div").insertAfter($("#cf-container"));
  // $("#cf-container").insertAfter($("select[name='infection_type']"));
  // $("#infection_site_div").insertAfter($("#cf-container"));
}
else if($(".ortho_category").val()=='Deformity'){
  $("#cf-container").insertAfter($("select[name='deformity_type']"));
  $("#cf-container").insertAfter($(".deformity_type_tr"));
}
else if($(".ortho_category").val()=='Degenerative'){
  $("#cf-container").insertAfter($("select[name='degenerative_site']"));  
  $("#cf-container").insertAfter($(".degenerative_site_tr"));  
}
else if($(".ortho_category").val()=='Tumours'){
  $("#cf-container").insertAfter($("#tumour_category_div"));
}
else if($(".ortho_category").val()=='Misc'){
  $("#cf-container").insertAfter($("#misc_category_div"));
}

$(document).on('change', '.trauma_site,.scoliosis_type', function(e) {
  if(this.value!=''){
    $(".cf-container").show();
  }else{
    $(".cf-container").hide();
  }
});
$(document).on('change', '.infection_type,.infection_site', function(e) {
  type=$(".infection_type").val();
  site=$(".infection_site").val();
  if(site!='' && type!=''){
    $(".cf-container").show();
  }else{
    $(".cf-container").hide();
  }
});
$(document).on('change', '.infection_type', function(e) {
  type=$(".infection_type").val();
  // alert();
  if(type=="Tuberculosis"){
    $('.tb_div').show(); 
    $('.pyogenic_div').hide(); 
  }
  else if(type=="Pyogenic"){
    $('.tb_div').hide(); 
    $('.pyogenic_div').show(); 
  }
  else{
    $('.tb_div,.pyogenic_div').hide(); 
  }
});
$(document).on('change', '.deformity_type', function(e) {
  type=$(".deformity_type").val();
  // alert();
  if(type=="Scoliosis"){
    $('.deformity_scoliosis_div').show(); 
    $('.deformity_kyphosis_div').hide(); 
    $(".cf-container").show();
  }
  else if(type=="Kyphosis"){
    $('.deformity_scoliosis_div').hide(); 
    $('.deformity_kyphosis_div').show(); 
    $(".cf-container").show();
  }
  else{
    $('.deformity_scoliosis_div,.deformity_kyphosis_div').hide();  
    $(".cf-container").hide();
  }
});

$(document).on('change', '.winter_classification', function(e) {
  type=$(".winter_classification").val();
  // alert();
  if(type=="Failure formation"){
    $('.ortho_winter_classification_formation').show(); 
    $('.ortho_winter_classification_segmentation').hide(); 
  }
  else if(type=="Failure of segmentation"){
    $('.ortho_winter_classification_formation').hide(); 
    $('.ortho_winter_classification_segmentation').show(); 
  }
  else{
    $('.ortho_winter_classification_formation,.ortho_winter_classification_segmentation').hide(); 
  }
});
$(document).on('change', '.degenerative_site', function(e) {
  type=$(".degenerative_site").val();
  // alert();
  if(type=="Lumbar"){
    $('.lumbar_site_div').show(); 
    $('.cervical_site_div').hide(); 
    $(".cf-container").show();
  }
  else if(type=="Cervical"){
    $('.lumbar_site_div').hide(); 
    $('.cervical_site_div').show(); 
    $(".cf-container").show();
  }
  else{
    $('.lumbar_site_div,.cervical_site_div').hide(); 
    $(".cf-container").hide();
  }
});
$(".naclass").each(function(){
  if(this.innerHTML.trim()=='' || this.innerText.trim()=='' || this.innerHTML.trim()=='(NA)' || this.innerText.trim()=='(NA)' || this.innerText.trim()=='0/0'){
    this.innerHTML="--";
  }
});

$(".srsoptions").change(function(){

function_attemped=0;
function_score=0;
function_score_mean=0;

pain_attemped=0;
pain_score=0;
pain_score_mean=0;

self_image_attemped=0;
self_image_score=0;
self_image_score_mean=0;

mental_health_attemped=0;
mental_health_score=0;
mental_health_score_mean=0;

satisfaction_attemped=0;
satisfaction_score=0;
satisfaction_score_mean=0;

total_srs_attemped=0;
total_srs_score=0;
total_srs_score_mean=0
  $(".srsoptions:checked").each(function(){
    if($(this).attr('category')=='Function'){
      // function calculation
      function_attemped++
      function_score=function_score+parseInt($(this).attr('score'))
    }
    if($(this).attr('category')=='Pain'){
      // function calculation
      pain_attemped++
      pain_score=pain_score+parseInt($(this).attr('score'))
    }
    if($(this).attr('category')=='Self image'){
      // function calculation
      self_image_attemped++
      self_image_score=self_image_score+parseInt($(this).attr('score'))
    }
    if($(this).attr('category')=='Mental health'){
      // function calculation
      mental_health_attemped++
      mental_health_score=mental_health_score+parseInt($(this).attr('score'))
    }
    if($(this).attr('category')=='Satisfaction/Dissatisfaction with management'){
      // function calculation
      satisfaction_attemped++
      satisfaction_score=satisfaction_score+parseInt($(this).attr('score'))
    }
    total_srs_attemped++
    total_srs_score=total_srs_score+parseInt($(this).attr('score'))
  });
  if(total_srs_attemped==0){
    total_srs_score_mean=0;  
  }
  else{
    total_srs_score_mean=total_srs_score/total_srs_attemped;
  }
  if(function_attemped==0){
    function_score_mean=0;  
  }
  else{
    function_score_mean=function_score/function_attemped;
  }
  if(pain_attemped==0){
    pain_score_mean=0;  
  }
  else{
    pain_score_mean=pain_score/pain_attemped;
  }
  if(self_image_attemped==0){
    self_image_score_mean=0;  
  }
  else{
    self_image_score_mean=self_image_score/self_image_attemped;
  }
  if(mental_health_attemped==0){
    mental_health_score_mean=0;  
  }
  else{
    mental_health_score_mean=mental_health_score/mental_health_attemped;
  }
  if(satisfaction_attemped==0){
    satisfaction_score_mean=0;  
  }
  else{
    satisfaction_score_mean=satisfaction_score/satisfaction_attemped;
  }
  $('.function_span').html(Math.round( function_score_mean * 10 ) / 10);
  $('.pain_span').html(Math.round( pain_score_mean * 10 ) / 10);
  $('.self_image_span').html(Math.round( self_image_score_mean * 10 ) / 10);
  $('.mental_health_span').html(Math.round( mental_health_score_mean * 10 ) / 10);
  $('.satisfation_span').html(Math.round( satisfaction_score_mean * 10 ) / 10);
  $('.total_srs_score_span').html(Math.round( total_srs_score_mean * 10 ) / 10);
});

$("select[name='scoliosis_type']").change(function(){
  if(this.value=="Idiopathic"){
    $('.lenke_heading_tr').show();
    $('.lenke_tr').show();
    $('.winter_classification_tr').hide();
    $('.winter_classification_tr').find('select').val('');
  }
  else if(this.value=="Congenital"){
    $('.lenke_heading_tr').show();
    $('.lenke_tr').hide();
    $('.lenke_tr').find('select').val('');
    $('.winter_classification_tr').show();
    winter=$("#winters_classification").val()
    if(winter=="Failure formation"){
      $(".failure_formation_tr").show();
      $(".failure_of_segmentation_tr").hide();
    }
    else if(winter=="Failure of segmentation"){
      $(".failure_of_segmentation_tr").show();
      $(".failure_formation_tr").hide();
    }
    else if(winter=="Mixed"){
      $(".failure_of_segmentation_tr").hide();
      $(".failure_formation_tr").hide();
    }
    else if(winter==""){
      $(".failure_of_segmentation_tr").hide();
      $(".failure_formation_tr").hide();
    }
  }
  else{
    alert();
    $('.lenke_heading_tr').hide();
    $('.lenke_tr').hide();
    $('.winter_classification_tr').hide();
    $('.lenke_tr').find('select').val('');
    $('.winter_classification_tr').find('select').val('');
  }
});