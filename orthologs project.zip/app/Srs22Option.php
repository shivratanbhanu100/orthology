<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Srs22Option extends Model
{
    protected $guarded=[];

    public function question(){
        return $this->belongsTo(Srs22Question::class,'srs22_question_id');
    }
}
