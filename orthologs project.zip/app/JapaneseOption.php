<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JapaneseOption extends Model
{
    protected $guarded=[];
}
