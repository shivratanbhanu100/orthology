<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientPerforma extends Model
{
    protected $guarded=[];
    protected $dates=['date'];

    public function patient(){
        return $this->belongsTo(Patient::class,'patient_id');
    }
    public function user(){
        return $this->belongsTo(User::class,'user_id')->withTrashed()->withDefault();
    }
}
