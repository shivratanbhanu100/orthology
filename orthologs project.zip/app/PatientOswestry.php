<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientOswestry extends Model
{
    protected $guarded=[];
    protected $dates=['date'];

    public function patient(){
        return $this->belongsTo(Patient::class,'patient_id');
    }
    public function question(){
        return $this->belongsTo(OswestryQuestion::class,'oswestry_question_id');
    }
    public function option(){
        return $this->belongsTo(OswestryOption::class,'oswestry_option_id')->withDefault();
    }
    public function user(){
        return $this->belongsTo(User::class,'user_id')->withTrashed()->withDefault();
    }
}
