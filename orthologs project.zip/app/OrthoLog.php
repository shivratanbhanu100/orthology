<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrthoLog extends Model
{
    protected $dates=['doa','doo','dod'];
    protected $guarded=[];
    protected $appends=['relatedIds'];
    
    public function setUhidAttribute($value) {
        $this->attributes['uhid'] = strtoupper($value);
    }
    public function getSurgeonsAttribute($value) {
        return str_replace('"','',$value);
    }
    public function getPostopcoursesAttribute($value) {
        return str_replace('"','',$value);
    }
    public function getRelatedIdsAttribute(){
        return OrthoLog::where('patient_id',$this->patientdetail->id)->where('id','<>',$this->id)->get()->pluck('id')->toArray();
    }
    public function patientdetail(){
        return $this->belongsTo(Patient::class,'patient_id');
    }
    public function getTotalJapaneseScoreAttribute(){
        return PatientJapanese::where('ortho_log_id',$this->id)->sum('score');
    }
    public function getTotalOswestryScoreAttribute(){
        return PatientOswestry::where('ortho_log_id',$this->id)->sum('score');
    }
    public function getIsOswestryExistAttribute(){
        return PatientOswestry::where('ortho_log_id',$this->id)->exists();
    }
    public function countOswestryScoreFunction(){
        $totalscore= PatientOswestry::where("patient_id",$this->id)->where("ortho_log_id",$this->id)->sum("score");
        $totalattempt= PatientOswestry::where("patient_id",$this->id)->where("ortho_log_id",$this->id)->whereNotNull("score")->get()->count();
        $totalapplicablescore=$totalattempt*5;
        if($totalattempt>0){
            return [$totalscore,$totalattempt,$totalapplicablescore,round(($totalscore/$totalapplicablescore),1)];
        }
        else{
            return [0,0,0,0];
        }
    }
    public function getIsJapaneseExistAttribute(){
        return PatientOswestry::where('ortho_log_id',$this->id)->exists();
    }
    public function countJapaneseScoreFunction(){
        $totalscore= PatientJapanese::where("patient_id",$this->id)->where("ortho_log_id",$this->id)->sum("score");
        $totalattempt= PatientJapanese::where("patient_id",$this->id)->where("ortho_log_id",$this->id)->whereNotNull("score")->get()->count();
        $totalapplicablescore=17;
        if($totalattempt>0){
            return [$totalscore,$totalattempt,$totalapplicablescore,round(($totalscore/$totalapplicablescore),1)];
        }
        else{
            return [0,0,0,0];
        }
    }
}
