<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JapaneseQuestion extends Model
{
    protected $guarded=[];

    public function options(){
        return $this->hasMany(JapaneseOption::class)->orderBy('sequence');
    }
}
