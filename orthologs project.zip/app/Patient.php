<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
    protected $guarded=[];
    protected $dates=['dob'];
    public function setUhidAttribute($value)
    {
        $this->attributes['uhid'] = strtoupper($value);
    }
    public function getUhidAttribute($value)
    {
        return strtoupper($value);
    }
    public function allSrs(){
        return $this->hasMany(PatientSrs22::class);
    }
    public function allPerforma(){
        return $this->hasMany(PatientPerforma::class);
    }
    public function performa($stage){
        return $this->allPerforma()->where("stage",$stage)->where("patient_id",$this->id)->first();
    }
    public function lastUpdated(){
        return $this->allPerforma()->where("patient_id",$this->id)->latest()->first()->updated_at;
    }
    public function proformaExist($stage){
        return $this->allPerforma()->where("stage",$stage)->where("patient_id",$this->id)->exists();
    }
    public function srsExist($stage){
        return $this->allSrs()->where("stage",$stage)->where("patient_id",$this->id)->exists();
    }
    public function srsDate($stage){
        return PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->distinct('date')->select('date')->first();
    }
    public function proformaDate($stage){
        return PatientPerforma::where("stage",$stage)->where("patient_id",$this->id)->distinct('date')->select('date')->first();
    }
    public function countScoreFunction($stage){
        $totalscore= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Function")->sum("score");
        $totalattempt= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Function")->whereNotNull("score")->count();
        if($totalattempt>0){
            return round(($totalscore/$totalattempt),1);
        }
        else{
            return 0;
        }
    }
    public function countFunctionalMean($stage){
        $totalscore= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->sum("score");
        $totalattempt= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->whereNotNull("score")->get()->count();
        if($totalattempt>0){
            return round(($totalscore/$totalattempt),1);
        }
        else{
            return 0;
        }
    }
    public function countFunctionalMeanDirect($stage){
        $mean_row= PatientPerforma::where("stage",$stage)->where("patient_id",$this->id)->first();
        if(!is_null($mean_row)){
            return $mean_row->functional_mean;
        }
        return 0;
    }
    public function countScoreSelfImage($stage){
        $totalscore= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Self image")->sum("score");
        $totalattempt= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Self image")->whereNotNull("score")->get()->count();
        if($totalattempt>0){
            return round(($totalscore/$totalattempt),1);
        }
        else{
            return 0;
        }
    }
    public function countScoreMentalHealth($stage){
        
        $totalscore= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Mental health")->sum("score");
        $totalattempt= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Mental health")->whereNotNull("score")->get()->count();
        if($totalattempt>0){
            return round(($totalscore/$totalattempt),1);
        }
        else{
            return 0;
        }
    }
    public function countScorePain($stage){
        $totalscore= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Pain")->sum("score");
        $totalattempt= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Pain")->whereNotNull("score")->get()->count();
        if($totalattempt>0){
            return round(($totalscore/$totalattempt),1);
        }
        else{
            return 0;
        }
    }
    public function countScoreManagement($stage){
        $totalscore= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Satisfaction/Dissatisfaction with management")->sum("score");
        $totalattempt= PatientSrs22::where("stage",$stage)->where("patient_id",$this->id)->where("question_category","Satisfaction/Dissatisfaction with management")->whereNotNull("score")->get()->count();
        if($totalattempt>0){
            return round(($totalscore/$totalattempt),1);
        }
        else{
            return 0;
        }
    }
}
