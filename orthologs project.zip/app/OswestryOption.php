<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OswestryOption extends Model
{
    protected $guarded=[];
}
