<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientJapanese extends Model
{
    protected $guarded=[];
    protected $dates=['date'];

    public function patient(){
        return $this->belongsTo(Patient::class,'patient_id');
    }
    public function question(){
        return $this->belongsTo(JapaneseQuestion::class,'japanese_question_id');
    }
    public function option(){
        return $this->belongsTo(JapaneseOption::class,'japanese_option_id')->withDefault();
    }
    public function user(){
        return $this->belongsTo(User::class,'user_id')->withTrashed()->withDefault();
    }
}
