<?php

function userRole($role)
{
  $userRole=\Auth::user()->role;
  if ($role==$userRole) {
    return true;
  }
  else {
    return false;
  }

}
function orthologcategories(){
  return ['Traumatic','Infection','Deformity','Degenerative','Tumours','Misc'];
}
function orthologtraumasite(){
  return ['Cervical','Dorsal','Lumbar'];
}
function orthologinfectiontype(){
  return ['Tuberculosis','Pyogenic','Other'];
}
function orthologinfectionsite(){
  return ['Cervical','Dorsal','Dorsolumbar','Lumbar','Sacral','Disseminated'];
}
function orthologscoliosistype(){
  return ['Idiopathic','Congenital','Degenerative','Neuromuscular','Syndromic'];
}
function orthologkyphosistype(){
  return ['Congenital','Late TB','Ankylosing spondylitis','Post-laminectomy kyphosis','Post-trauma','Neurofibromatosis','Scheurmann disease'];
}
function postopcourse(){
  return ['SSI (Infection)','Wound dehiscence','DVT','Neurological deficit'];
}
function orthologsites(){
  return ['Knee','Spine','Thigh','Wrist'];
}
function orthologsurgeons(){
  return ['BG','Nishank','Akhtar','Ankur','Shubhankar', 'VS','Gokul', 'Anand', 'Aditya', 'Naman', 'Megha', 'Shashank', 'Ankit', 'Sahil', 'Man Singh', 'Roshan', 'Aayush'];
  
}
function orthologside(){
  return ['Right','Left','Back','Lower Back','Upper Back', 'B/L', 'B/L TKR'];
}
function caseidformat($id){
  return 'ORTH'.str_pad($id, 6, '0', STR_PAD_LEFT);
}
function optionSelectedByPatient($patient_id,$srsoption_id,$stage)
{
  return \App\PatientSrs22::where('patient_id',$patient_id)->where('srs22_option_id',$srsoption_id)->where('stage',$stage)->exists();
} 

function countFunctionalMean($stage,$startdate,$enddate){
  
  $totalscore= \App\PatientSrs22::where("stage",$stage)->whereBetween('date',[$startdate,$enddate])->sum("score");
  $totalattempt= \App\PatientSrs22::where("stage",$stage)->whereBetween('date',[$startdate,$enddate])->whereNotNull("score")->get()->count();
  if($totalattempt>0){
      return round(($totalscore/$totalattempt),1);
  }
  else{
      return 0;
  }
}
function getNextSrsStage($id){
  $patient=App\Patient::find($id);
  if(!$patient->srsExist(4)){
    $stage=4;
  }
  if(!$patient->srsExist(3)){
      $stage=3;
  }
  if(!$patient->srsExist(2)){
      $stage=2;
  }
  if(!$patient->srsExist(1)){
      $stage=1;
  }
  return $stage;
}
function getLastSrsStage($id){
  $patient=App\Patient::find($id);
  $stage=0;
  if($patient->srsExist(1)){
      $stage=1;
  }
  if($patient->srsExist(2)){
      $stage=2;
  }
  if($patient->srsExist(3)){
      $stage=3;
  }
  if($patient->srsExist(4)){
    $stage=4;
  }
  return $stage;
}
function optionSelectedByPatientJapanese($log_id,$japaneseoption_id)
{
  return \App\PatientJapanese::where('ortho_log_id',$log_id)->where('japanese_option_id',$japaneseoption_id)->exists();
} 
function optionSelectedByPatientOswestry($log_id,$oswestryoption_id)
{
  return \App\PatientOswestry::where('ortho_log_id',$log_id)->where('oswestry_option_id',$oswestryoption_id)->exists();
} 

function getOswestryInterpretation($percent){
  $percent=round($percent);
  if($percent>=0 && $percent<=20){
    // 0% to 20%: minimal disability: The patient can cope with most living activities. Usually no treatment is indicated apart from advice on lifting sitting and exercise.
    return "minimal disability: The patient can cope with most living activities. Usually no treatment is indicated apart from advice on lifting sitting and exercise.";
  }
  if($percent>=21 && $percent<=40){
    // 21%-40%: 
    return "moderate disability: The patient experiences more pain and difficulty with sitting, lifting and standing. Travel and social life are more difficult and they may be disabled from work. Personal care, sexual activity and sleeping are not grossly affected and the patient can usually be managed by conservative means.";
  }
  if($percent>=41 && $percent<=60){
    // 41%-60%: severe disability: Pain remains the main problem in this group but activities of daily living are affected. These patients require a detailed investigation. 
    return "severe disability: Pain remains the main problem in this group but activities of daily living are affected. These patients require a detailed investigation.";
  }
  if($percent>=61 && $percent<=80){
    // 61%-80%: crippled: Back pain impinges on all aspects of the patient's life. Positive intervention is required.
    return "crippled: Back pain impinges on all aspects of the patient's life. Positive intervention is required.";
  }
  if($percent>=81 && $percent<=100){
    // 81%-100%: These patients are either bed-bound or exaggerating their symptoms. 
    return "These patients are either bed-bound or exaggerating their symptoms.";
  }
}



