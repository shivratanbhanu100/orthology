<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use App\Patient;
use App\PatientSrs22;
use App\PatientPerforma;
use App\Srs22Question;
use App\Srs22Option;
use App\Charts\PieChart;
use Carbon\Carbon;
use App\OrthoLog;
use App\OswestryQuestion;
use App\OswestryOption;
use App\PatientOswestry;
use App\JapaneseQuestion;
use App\JapaneseOption;
use App\PatientJapanese;


class OrthoLogController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkrole:scoliosisadmin,orthoadmin,superadmin,4,5,6,7,8');
    }
    public function dashboard()
    {
        // $data = OrthoLog::selectRaw("age,count(*) as count")->groupBy('age')->get();
        // category wise
        // $categorywise = OrthoLog::selectRaw("category,count(*) as total")->groupBy('category')
        //     ->get();
        //     $categorydata=[];
        // foreach($categorywise as $log){
        //     $categorydata[$log->category]=$log->total;
        // }
        // $categoryfinaldata = collect($categorydata);
        // $chartcategory = new PieChart;
        // $chartcategory->labels($categoryfinaldata->keys());
        // $chartcategory->dataset('Case Type', 'line', $categoryfinaldata->values());
        // gender wise
        $sexwiselogs = Patient::selectRaw("sex,count(*) as total")->groupBy('sex')
            ->get();
            $sexdata=[];
        foreach($sexwiselogs as $log){
            $sexdata[$log->sex]=$log->total;
        }
        $sexfinaldata = collect($sexdata);
        $chartsex = new PieChart;
        $chartsex->labels($sexfinaldata->keys());
        $chartsex->dataset('Sex', 'pie', $sexfinaldata->values());
        $chartsex->dataset('Sex', 'pie', $sexfinaldata->values())->color(['#036cb5','#fbaf3a',"#000000"]);

        $agewiselogs = Patient::selectRaw("age,count(*) as total")->groupBy('age')
            ->get();
            $agedata=[];
        foreach($agewiselogs as $log){
            $agedata[$log->age]=$log->total;
        }
        $agefinaldata = collect($agedata);
        $chartage = new PieChart;
        $chartage->labels($agefinaldata->keys());
        $chartage->dataset('Age', 'bar', $agefinaldata->values());

        $page="orthodashboard";
        $total=OrthoLog::query()->sum('surgical_time');
        $logs=OrthoLog::all();
        $count=$logs->count();
        if($count>0){
            $mean=round($total/$count,2);
        }
        else{
            $mean=0;
        }
        return view('hospital.ortholog.dashboard.index',compact("page",'total','mean', 'count','chartsex','chartage'));
        
    }
    public function index()
    {
        $page="orthologindex";
        $catcount=[];
        $sitecount=[];
        foreach(orthologcategories() as $cat){
            $catcount[$cat]=OrthoLog::where('category',$cat)->count();
        }
        // foreach(orthologsites() as $siteloop){
        //     $sitecount[$siteloop]=OrthoLog::where('site',$siteloop)->count();
        // }
        $selectedlogs=OrthoLog::latest()->get();
        return view('hospital.ortholog.logs.index',compact("page",'selectedlogs','catcount','sitecount'));
    }
    public function getfilteredlog(Request $request)
    {
        $orthologcategories=orthologcategories();
        $enddate=date('Y-m-d', strtotime($request->enddate. ' + 1 days'));
        $orthologsites=orthologsites();
        $catcount=[];
        $sitecount=[];
        if(empty($request->categories)){
            //all
            $selectedlogs=OrthoLog::whereBetween('created_at',[$request->startdate,$enddate])->latest()->get();
            foreach($orthologcategories as $cat){
                $catcount[$cat]=OrthoLog::whereBetween('created_at',[$request->startdate,$enddate])->where('category',$cat)->count();
            }
            $total=OrthoLog::whereBetween('created_at',[$request->startdate,$enddate])->sum('surgical_time');
            $logs=OrthoLog::all();
            $count=$logs->count();
            if($count>0){
                $mean=round($total/$count,2);
            }
            else{
                $mean=0;
            }
            
        }
        elseif(!empty($request->categories)){
            //selected cat and all site
            $selectedlogs=OrthoLog::whereBetween('created_at',[$request->startdate,$enddate])->whereIn('category',$request->categories)->latest()->get();
            foreach($orthologcategories as $cat){
                $catcount[$cat]=OrthoLog::whereBetween('created_at',[$request->startdate,$enddate])->whereIn('category',$request->categories)->where('category',$cat)->count();
            }
            $total=OrthoLog::whereBetween('created_at',[$request->startdate,$enddate])->whereIn('category',$request->categories)->where('category',$cat)->sum('surgical_time');
            $logs=OrthoLog::all();
            $count=$logs->count();
            if($count>0){
                $mean=round($total/$count,2);
            }
            else{
                $mean=0;
            }
        }
        
        $data['tablecontent']= view('hospital.ortholog.logs.list',compact('selectedlogs'))->render();
        $data['catcount']= view('hospital.ortholog.logs.categoriesloopforfilter',compact('catcount'))->render();
        $data['total']= $total;
        $data['count']=$count;
        $data['mean']= $mean;
        return $data;

    }
    public function dashboardfilter(Request $request)
    {
        $startdate=$request->startdate;
        $enddate=$request->enddate;
        $total=OrthoLog::whereBetween('created_at',[$request->startdate,$request->enddate])->sum('surgical_time');
        $logs=OrthoLog::whereBetween('created_at',[$request->startdate,$request->enddate])->get();
        $count=$logs->count();
        if($count>0){
            $mean=round($total/$count,2);
        }
        else{
            $mean=0;
        }
        return [$total,$count,$mean,$request->startdate,$request->enddate];
    }
    public function newortholog()
    {
        $page="orthologindex";
        $srsquestions=Srs22Question::query()->get();
        $japanesequestions=JapaneseQuestion::query()->get();
        $oswestryquestions=OswestryQuestion::query()->get();
        

        return view('hospital.ortholog.logs.new',compact("page",'srsquestions','japanesequestions','oswestryquestions'));
    }
    public function storeortholog(Request $request)
    {
        // dd($request->all());
        $dob=null;
        // if(!is_null($request->dob_date) && !is_null($request->dob_month) && !is_null($request->dob_year)){
        //         $dob=$request->dob_year.'-'.$request->dob_month.'-'.$request->dob_date;
        // }
        // $id=Patient::create([
        //     'user_id'=>\Auth::user()->id,
        //     'name'=>$request->name,
        //     'age'=>$request->age,
        //     'sex'=>$request->sex,
        //     'uhid'=>$request->uhid,
        //     'dob'=>$dob,
        //     'phone'=>$request->phone_no,
        //     'email'=>$request->emailid,
        //     'address'=>$request->address,
        //     'occupation'=>$request->occupation,
        //     'bed_no'=>$request->bed_no,
        //     'diagnosis'=>$request->diagnosis,
        //     'ortholog'=>1,
        // ])->id;
        // asdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasds
        if(Patient::where("uhid",$request->uhid)->exists()){
            if(!is_null($request->dob_date) && !is_null($request->dob_month) && !is_null($request->dob_year)){
                $dob=$request->dob_year.'-'.$request->dob_month.'-'.$request->dob_date;
            }
            Patient::where("uhid",$request->uhid)->update([
                'user_id'=>\Auth::user()->id,
                'name'=>$request->name,
                'age'=>$request->age,
                'sex'=>$request->sex,
                'dob'=>$dob,
                'phone'=>$request->phone_no,
                'email'=>$request->emailid,
                'address'=>$request->address,
                'occupation'=>$request->occupation,
                'bed_no'=>$request->bed_no,
                'diagnosis'=>$request->diagnosis,
                'ortholog'=>1,
            ]);
            $patient=Patient::where("uhid",$request->uhid)->first();
            $id=$patient->id;
        }
        else{
            if(!is_null($request->dob_date) && !is_null($request->dob_month) && !is_null($request->dob_year)){
                $dob=$request->dob_year.'-'.$request->dob_month.'-'.$request->dob_date;
            }
            $id=Patient::create([
                'user_id'=>\Auth::user()->id,
                'name'=>$request->name,
                'age'=>$request->age,
                'sex'=>$request->sex,
                'uhid'=>$request->uhid,
                'dob'=>$dob,
                'phone'=>$request->phone_no,
                'email'=>$request->emailid,
                'address'=>$request->address,
                'occupation'=>$request->occupation,
                'bed_no'=>$request->bed_no,
                'diagnosis'=>$request->diagnosis,
                'ortholog'=>1,
            ])->id;
            $patient=Patient::where("uhid",$request->uhid)->first();
        }
        // asdasdasdasdasdasdasdasdasdasdasdasasdasdasdasdasdasasd
        if($request->category=="Traumatic"){
            $ortho_id=OrthoLog::create([
                'patient_id'=>$id,
                "category"=>$request->category,
                "trauma_site"=>$request->trauma_site,
            ])->id;
        }else if($request->category=="Infection"){
            $ortho_id=OrthoLog::create([
                'patient_id'=>$id,
                "category"=>$request->category,
                "infection_type"=>$request->infection_type,
                "tb_mdr"=>$request->tb_mdr,
                "tb_hpe"=>$request->tb_hpe,
                "tb_gene"=>$request->tb_gene,
                "tb_cs"=>$request->tb_cs,
                "tb_culture"=>$request->tb_culture,
                "tb_pyogenic_bacteria"=>$request->tb_pyogenic_bacteria,
                "tb_pyogenic_antibiotic"=>$request->tb_pyogenic_antibiotic,
                "infection_site"=>$request->infection_site,
            ])->id;
        }
        else if($request->category=="Deformity"){
            if($request->deformity_type=='Scoliosis'){
                $ortho_id=OrthoLog::create([
                    'patient_id'=>$id,
                    "category"=>$request->category,
                    "deformity_type"=>$request->deformity_type,
                    "scoliosis_type"=>$request->scoliosis_type,
                    "winter_classification"=>$request->winter_classification,
                    "winter_classification_failure_formation"=>$request->winter_classification_failure_formation,
                    "winter_classification_failure_of_segmentation"=>$request->winter_classification_failure_of_segmentation,
                ])->id;
                
                Patient::whereId($id)->update(['scoliosis'=>1]);
                // Copy data to scoliosis too.
                OrthoLog::whereId($ortho_id)->update([
                    "operative_details"=>$request->operative_details,
                    "diagnosis"=>$request->diagnosis,
                    "level"=>$request->level,
                    "treatment_procedure"=>$request->treatment_procedure,
                    "comorbidities"=>$request->comorbidities,
                    "surgeons"=>$request->surgeons,
                    "implant"=>$request->implant,
                    "surgical_time"=>$request->surgical_time,
                    "blood_loss"=>$request->blood_loss,
                    "doa"=>(!is_null($request->doa))?date('Y-m-d',strtotime($request->doa)):null,
                    "doo"=>(!is_null($request->doo))?date('Y-m-d',strtotime($request->doo)):null,
                    "dod"=>(!is_null($request->dod))?date('Y-m-d',strtotime($request->dod)):null,
                    "postopcourses"=>$request->postopcourses,
                    "postopcourses_other"=>$request->postopcourses_other,
                ]);
                
                //check stage 1 start
                \Session::flash('flash_message',"Patient details updated. Redirected to unfilled form.");
                if(!$patient->srsExist(1)){
                    return redirect("/srs22/new/1/".$patient->id);
                }
                else{
                    if(!$patient->proformaExist(1)){
                        return redirect("/proforma/new/1/".$patient->id);
                    }
                    else{//check stage 2 start
                        if(!$patient->srsExist(2)){
                            return redirect("/srs22/new/2/".$patient->id);
                        }
                        else{
                            if(!$patient->proformaExist(2)){
                                return redirect("/proforma/new/2/".$patient->id);
                            }
                            else{//check stage 3 start
                                if(!$patient->srsExist(3)){
                                    return redirect("/srs22/new/3/".$patient->id);
                                }
                                else{
                                    if(!$patient->proformaExist(3)){
                                        return redirect("/proforma/new/3/".$patient->id);
                                    }
                                    else{//check stage 4 start
                                        if(!$patient->srsExist(4)){
                                            return redirect("/srs22/new/4/".$patient->id);
                                        }
                                        else{
                                            if(!$patient->proformaExist(4)){
                                                return redirect("/proforma/new/4/".$patient->id);
                                            }
                                            else{//Redirect after final stage start
                                                return redirect()->route('scoliosispatients');
                                            }//Redirect after final stage end
                                        }
                                    }//check stage 4 end
                                }
                            }//check stage 3 end
                        }
                    }//check stage 2 end
                }
                //check for stage 1 end
                // Copy data to scoliosis too.
                
            }
            else if($request->deformity_type=='Kyphosis'){
                $ortho_id=OrthoLog::create([
                    'patient_id'=>$id,
                    "category"=>$request->category,
                    "deformity_type"=>$request->deformity_type,
                    "kyphosis_type"=>$request->kyphosis_type,
                    "kyphosis_angle"=>$request->kyphosis_angle,
                    "sagital_shift"=>$request->sagital_shift,
                    "kyphosis_pi"=>$request->kyphosis_pi,
                    "kyphosis_pt"=>$request->kyphosis_pt,
                    "kyphosis_ss"=>$request->kyphosis_ss,
                    "kyphosis_tk"=>$request->kyphosis_tk,
                    "kyphosis_ll"=>$request->kyphosis_ll,
                ])->id;
            }
        }
        else if($request->category=="Degenerative"){
            if($request->degenerative_site=='Lumbar'){
                $ortho_id=OrthoLog::create([
                    'patient_id'=>$id,
                    "category"=>$request->category,
                    "degenerative_site"=>$request->degenerative_site,
                    "imagefinding"=>!is_null($request->imagefinding)?implode(",",$request->imagefinding):null,
                    "imagefinding_other"=>$request->imagefindings_other,
                    "lumbar_pi"=>$request->lumbar_pi,
                    "lumbar_pt"=>$request->lumbar_pt,
                    "lumbar_ss"=>$request->lumbar_ss,
                    "lumbar_tk"=>$request->lumbar_tk,
                    "lumbar_ll"=>$request->lumbar_ll,
                ])->id;
                $oswestdate=date('Y-m-d',strtotime($request->oswestdate_of_questionnaire));
                $oswestryquestions=OswestryQuestion::query()->get();
                foreach($oswestryquestions as $oswestry){
                    $score=null;
                    $option_id=$request->{'oswest'.$oswestry->id};
                    if(!is_null($option_id)){
                        $score=OswestryOption::find($option_id)->score;
                    }
                    PatientOswestry::create([
                        'date'=>$oswestdate,
                        'ortho_log_id'=>$ortho_id,
                        "user_id"=>\Auth::user()->id,
                        'patient_id'=>$id,
                        'oswestry_question_id'=>$oswestry->id,
                        'oswestry_option_id'=>$option_id,
                        'score'=>$score
                    ]);
                }
                // Oswestry low back disability (questionnaire)
            }
            else if($request->degenerative_site=='Cervical'){
                // dd($request->all());
                $ortho_id=OrthoLog::create([
                    'patient_id'=>$id,
                    "category"=>$request->category,
                    "degenerative_site"=>$request->degenerative_site,
                    "cervicalimagefinding"=>!is_null($request->cervicalimagefinding)?implode(",",$request->cervicalimagefinding):null,
                    "cervicalimagefinding_other"=>$request->cervicalimagefinding_other,
                ])->id;
                $japanesedate=date('Y-m-d',strtotime($request->japanesedate_of_questionnaire));
                $japanesequestions=JapaneseQuestion::query()->get();
                foreach($japanesequestions as $japanese){
                    $score=null;
                    $option_id=$request->{'japanese'.$japanese->id};
                    if(!is_null($option_id)){
                        $score=JapaneseOption::find($option_id)->score;
                    }
                    PatientJapanese::create([
                        'date'=>$japanesedate,
                        'ortho_log_id'=>$ortho_id,
                        "user_id"=>\Auth::user()->id,
                        'patient_id'=>$id,
                        'japanese_question_id'=>$japanese->id,
                        'japanese_option_id'=>$option_id,
                        'score'=>$score
                    ]);
                }
            }
        }
        else if($request->category=="Tumours"){
            $ortho_id=OrthoLog::create([
                'patient_id'=>$id,
                "category"=>$request->category,
                "tumour_type"=>$request->tumour_type,
            ])->id;
        }
        else if($request->category=="Misc"){
            $ortho_id=OrthoLog::create([
                'patient_id'=>$id,
                "category"=>$request->category,
            ])->id;
        }
        
        OrthoLog::whereId($ortho_id)->update([
            "operative_details"=>$request->operative_details,
            "diagnosis"=>$request->diagnosis,
            "level"=>$request->level,
            "treatment_procedure"=>$request->treatment_procedure,
            "comorbidities"=>$request->comorbidities,
            "surgeons"=>$request->surgeons,
            "implant"=>$request->implant,
            "surgical_time"=>$request->surgical_time,
            "blood_loss"=>$request->blood_loss,
            "doa"=>(!is_null($request->doa))?date('Y-m-d',strtotime($request->doa)):null,
            "doo"=>(!is_null($request->doo))?date('Y-m-d',strtotime($request->doo)):null,
            "dod"=>(!is_null($request->dod))?date('Y-m-d',strtotime($request->dod)):null,
            "postopcourses"=>$request->postopcourses,
            "postopcourses_other"=>$request->postopcourses_other,
        ]);
        \Session::flash('flash_message','Log added for '.$request->name.': '.$request->uhid);
        return redirect()->route('logindex');
    }
    public function orthologprofile($id)
    {
        $log=OrthoLog::find($id);
        $page="orthologindex";
        $srsquestions=Srs22Question::query()->get();
        $japanesequestions=JapaneseQuestion::query()->get();
        $oswestryquestions=OswestryQuestion::query()->get();
        $stage=getNextSrsStage($log->patient_id);
        $patientsrs=PatientSrs22::where("stage",$stage)->where("patient_id",$log->patient_id)->get();
        $patientjapanese=PatientJapanese::where("ortho_log_id",$log->id)->get();
        $patientoswestry=PatientOswestry::where("ortho_log_id",$log->id)->get();
        return view('hospital.ortholog.logs.logprofile',compact("page",'log',"srsquestions","japanesequestions","oswestryquestions","patientsrs","patientjapanese","patientoswestry"));
    }
    public function orthologedit($id)
    {
        $log=OrthoLog::find($id);
        $page="orthologindex";
        $srsquestions=Srs22Question::query()->get();
        $japanesequestions=JapaneseQuestion::query()->get();
        $oswestryquestions=OswestryQuestion::query()->get();
        $stage=getNextSrsStage($log->patient_id);
        $patientsrs=PatientSrs22::where("stage",$stage)->where("patient_id",$log->patient_id)->get();
        $patientjapanese=PatientJapanese::where("ortho_log_id",$log->id)->get();
        $patientoswestry=PatientOswestry::where("ortho_log_id",$log->id)->get();
        
        return view('hospital.ortholog.logs.edit',compact("page",'log',"srsquestions","japanesequestions","oswestryquestions","patientsrs","patientjapanese","patientoswestry"));
    }
    public function updateortholog($ortho_id,Request $request)
    {
         // dd($request->all());
         $dob=null;
         OrthoLog::whereId($ortho_id)->update([
            "trauma_site"=>null,
            "infection_type"=>null,
            "tb_mdr"=>null,
            "tb_hpe"=>null,
            "tb_gene"=>null,
            "tb_cs"=>null,
            "tb_culture"=>null,
            "tb_pyogenic_bacteria"=>null,
            "tb_pyogenic_antibiotic"=>null,
            "infection_site"=>null,
            "scoliosis_type"=>null,
            "winter_classification"=>null,
            "winter_classification_failure_formation"=>null,
            "winter_classification_failure_of_segmentation"=>null,
            "deformity_type"=>null,
            "kyphosis_type"=>null,
            "kyphosis_angle"=>null,
            "sagital_shift"=>null,
            "kyphosis_pi"=>null,
            "kyphosis_pt"=>null,
            "kyphosis_ss"=>null,
            "kyphosis_tk"=>null,
            "kyphosis_ll"=>null,
            "degenerative_site"=>null,
            "imagefinding"=>null,
            "imagefinding_other"=>null,
            "lumbar_pi"=>null,
            "lumbar_pt"=>null,
            "lumbar_ss"=>null,
            "lumbar_tk"=>null,
            "lumbar_ll"=>null,
            "cervicalimagefinding"=>null,
            "cervicalimagefinding_other"=>null,
            "tumour_type"=>null,
            "operative_details"=>null,
            "diagnosis"=>null,
            "level"=>null,
            "treatment_procedure"=>null,
            "comorbidities"=>null,
            "surgeons"=>null,
            "implant"=>null,
            "surgical_time"=>null,
            "blood_loss"=>null,
            "doa"=>null,
            "doo"=>null,
            "dod"=>null,
            "postopcourses"=>null,
            "postopcourses_other"=>null,
        ]);
         
         // asdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasds
         
             if(!is_null($request->dob_date) && !is_null($request->dob_month) && !is_null($request->dob_year)){
                 $dob=$request->dob_year.'-'.$request->dob_month.'-'.$request->dob_date;
             }
             Patient::where("uhid",$request->uhid)->update([
                 'user_id'=>\Auth::user()->id,
                 'name'=>$request->name,
                 'age'=>$request->age,
                 'sex'=>$request->sex,
                 'dob'=>$dob,
                 'phone'=>$request->phone_no,
                 'email'=>$request->emailid,
                 'address'=>$request->address,
                 'occupation'=>$request->occupation,
                 'bed_no'=>$request->bed_no,
                 'diagnosis'=>$request->diagnosis,
                 'ortholog'=>1,
             ]);
             $patient=Patient::where("uhid",$request->uhid)->first();
             $id=$patient->id;
         
         // asdasdasdasdasdasdasdasdasdasdasdasasdasdasdasdasdasasd
         if($request->category=="Traumatic"){
             $ortho_id=OrthoLog::whereId($ortho_id)->update([
                 "category"=>$request->category,
                 "trauma_site"=>$request->trauma_site,
             ])->id;
         }else if($request->category=="Infection"){
             OrthoLog::whereId($ortho_id)->update([
                 "category"=>$request->category,
                 "infection_type"=>$request->infection_type,
                 "tb_mdr"=>$request->tb_mdr,
                 "tb_hpe"=>$request->tb_hpe,
                 "tb_gene"=>$request->tb_gene,
                 "tb_cs"=>$request->tb_cs,
                 "tb_culture"=>$request->tb_culture,
                 "tb_pyogenic_bacteria"=>$request->tb_pyogenic_bacteria,
                 "tb_pyogenic_antibiotic"=>$request->tb_pyogenic_antibiotic,
                 "infection_site"=>$request->infection_site,
             ]);
         }
         else if($request->category=="Deformity"){
             if($request->deformity_type=='Scoliosis'){
                 OrthoLog::whereId($ortho_id)->update([
                     "category"=>$request->category,
                     "deformity_type"=>$request->deformity_type,
                     "scoliosis_type"=>$request->scoliosis_type,
                     "winter_classification"=>$request->winter_classification,
                     "winter_classification_failure_formation"=>$request->winter_classification_failure_formation,
                     "winter_classification_failure_of_segmentation"=>$request->winter_classification_failure_of_segmentation,
                 ]);
                 
                 Patient::whereId($id)->update(['scoliosis'=>1]);
                 // Copy data to scoliosis too.
                 OrthoLog::whereId($ortho_id)->update([
                    "operative_details"=>$request->operative_details,
                    "diagnosis"=>$request->diagnosis,
                    "level"=>$request->level,
                    "treatment_procedure"=>$request->treatment_procedure,
                    "comorbidities"=>$request->comorbidities,
                    "surgeons"=>$request->surgeons,
                    "implant"=>$request->implant,
                    "surgical_time"=>$request->surgical_time,
                    "blood_loss"=>$request->blood_loss,
                    "doa"=>(!is_null($request->doa))?date('Y-m-d',strtotime($request->doa)):null,
                    "doo"=>(!is_null($request->doo))?date('Y-m-d',strtotime($request->doo)):null,
                    "dod"=>(!is_null($request->dod))?date('Y-m-d',strtotime($request->dod)):null,
                    "postopcourses"=>$request->postopcourses,
                    "postopcourses_other"=>$request->postopcourses_other,
                ]);
                 //check stage 1 start
                 \Session::flash('flash_message',"Patient details updated. Redirected to unfilled form.");
                 if(!$patient->srsExist(1)){
                     return redirect("/srs22/new/1/".$patient->id);
                 }
                 else{
                     if(!$patient->proformaExist(1)){
                         return redirect("/proforma/new/1/".$patient->id);
                     }
                     else{//check stage 2 start
                         if(!$patient->srsExist(2)){
                             return redirect("/srs22/new/2/".$patient->id);
                         }
                         else{
                             if(!$patient->proformaExist(2)){
                                 return redirect("/proforma/new/2/".$patient->id);
                             }
                             else{//check stage 3 start
                                 if(!$patient->srsExist(3)){
                                     return redirect("/srs22/new/3/".$patient->id);
                                 }
                                 else{
                                     if(!$patient->proformaExist(3)){
                                         return redirect("/proforma/new/3/".$patient->id);
                                     }
                                     else{//check stage 4 start
                                         if(!$patient->srsExist(4)){
                                             return redirect("/srs22/new/4/".$patient->id);
                                         }
                                         else{
                                             if(!$patient->proformaExist(4)){
                                                 return redirect("/proforma/new/4/".$patient->id);
                                             }
                                             else{//Redirect after final stage start
                                                 return redirect()->route('scoliosispatients');
                                             }//Redirect after final stage end
                                         }
                                     }//check stage 4 end
                                 }
                             }//check stage 3 end
                         }
                     }//check stage 2 end
                 }
                 //check for stage 1 end
                 // Copy data to scoliosis too.
                 
             }
             else if($request->deformity_type=='Kyphosis'){
                 OrthoLog::whereId($ortho_id)->update([
                     "category"=>$request->category,
                     "deformity_type"=>$request->deformity_type,
                     "kyphosis_type"=>$request->kyphosis_type,
                     "kyphosis_angle"=>$request->kyphosis_angle,
                     "sagital_shift"=>$request->sagital_shift,
                     "kyphosis_pi"=>$request->kyphosis_pi,
                     "kyphosis_pt"=>$request->kyphosis_pt,
                     "kyphosis_ss"=>$request->kyphosis_ss,
                     "kyphosis_tk"=>$request->kyphosis_tk,
                     "kyphosis_ll"=>$request->kyphosis_ll,
                 ]);
             }
         }
         else if($request->category=="Degenerative"){
            PatientOswestry::where('ortho_log_id',$ortho_id)->delete();
            PatientJapanese::where('ortho_log_id',$ortho_id)->delete();
             if($request->degenerative_site=='Lumbar'){
                 OrthoLog::whereId($ortho_id)->update([
                     "category"=>$request->category,
                     "degenerative_site"=>$request->degenerative_site,
                     "imagefinding"=>!is_null($request->imagefinding)?implode(",",$request->imagefinding):null,
                     "imagefinding_other"=>$request->imagefindings_other,
                     "lumbar_pi"=>$request->lumbar_pi,
                     "lumbar_pt"=>$request->lumbar_pt,
                     "lumbar_ss"=>$request->lumbar_ss,
                     "lumbar_tk"=>$request->lumbar_tk,
                     "lumbar_ll"=>$request->lumbar_ll,
                 ]);
                 $oswestdate=date('Y-m-d',strtotime($request->oswestdate_of_questionnaire));
                 $oswestryquestions=OswestryQuestion::query()->get();
                 foreach($oswestryquestions as $oswestry){
                     $score=null;
                     $option_id=$request->{'oswest'.$oswestry->id};
                     if(!is_null($option_id)){
                         $score=OswestryOption::find($option_id)->score;
                     }
                     PatientOswestry::create([
                         'date'=>$oswestdate,
                         'ortho_log_id'=>$ortho_id,
                         "user_id"=>\Auth::user()->id,
                         'patient_id'=>$id,
                         'oswestry_question_id'=>$oswestry->id,
                         'oswestry_option_id'=>$option_id,
                         'score'=>$score
                     ]);
                 }
                 // Oswestry low back disability (questionnaire)
             }
             else if($request->degenerative_site=='Cervical'){
                 // dd($request->all());
                 OrthoLog::whereId($ortho_id)->update([
                     "category"=>$request->category,
                     "degenerative_site"=>$request->degenerative_site,
                     "cervicalimagefinding"=>!is_null($request->cervicalimagefinding)?implode(",",$request->cervicalimagefinding):null,
                     "cervicalimagefinding_other"=>$request->cervicalimagefinding_other,
                 ]);
                 $japanesedate=date('Y-m-d',strtotime($request->japanesedate_of_questionnaire));
                 $japanesequestions=JapaneseQuestion::query()->get();
                 foreach($japanesequestions as $japanese){
                     $score=null;
                     $option_id=$request->{'japanese'.$japanese->id};
                     if(!is_null($option_id)){
                         $score=JapaneseOption::find($option_id)->score;
                     }
                     PatientJapanese::create([
                         'date'=>$japanesedate,
                         'ortho_log_id'=>$ortho_id,
                         "user_id"=>\Auth::user()->id,
                         'patient_id'=>$id,
                         'japanese_question_id'=>$japanese->id,
                         'japanese_option_id'=>$option_id,
                         'score'=>$score
                     ]);
                 }
             }
         }
         else if($request->category=="Tumours"){
             $ortho_id=OrthoLog::whereId($ortho_id)->update([
                 "category"=>$request->category,
                 "tumour_type"=>$request->tumour_type,
             ])->id;
         }
         else if($request->category=="Misc"){
             $ortho_id=OrthoLog::whereId($ortho_id)->update([
                 "category"=>$request->category,
             ])->id;
         }
         OrthoLog::whereId($ortho_id)->update([
             "operative_details"=>$request->operative_details,
             "diagnosis"=>$request->diagnosis,
             "level"=>$request->level,
             "treatment_procedure"=>$request->treatment_procedure,
             "comorbidities"=>$request->comorbidities,
             "surgeons"=>$request->surgeons,
             "implant"=>$request->implant,
             "surgical_time"=>$request->surgical_time,
             "blood_loss"=>$request->blood_loss,
             "doa"=>(!is_null($request->doa))?date('Y-m-d',strtotime($request->doa)):null,
             "doo"=>(!is_null($request->doo))?date('Y-m-d',strtotime($request->doo)):null,
             "dod"=>(!is_null($request->dod))?date('Y-m-d',strtotime($request->dod)):null,
             "postopcourses"=>$request->postopcourses,
             "postopcourses_other"=>$request->postopcourses_other,
         ]);
        \Session::flash('flash_message','Log updated for '.$request->name.': '.$request->uhid);
        return redirect()->route('logindex');
    }
    public function deleteorthorecord(Request $request){
        PatientJapanese::whereIn("ortho_log_id",$request->id)->delete();
        PatientOswestry::whereIn("ortho_log_id",$request->id)->delete();
        OrthoLog::whereIn("id",$request->id)->delete();
        \Session::flash('flash_message',"Patient's Ortho log deleted");

    }
}
