<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;

class SuperadminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkrole:superadmin,2,3,4,5,6,7,8');
    }
    public function index()
    {
        $page="users";
        $users=User::latest()->get();

        return view('hospital.users.index',compact("page",'users'));
    }
    public function newuser(){
        $page="users";
        return view('hospital.users.new',compact("page"));
    }
    public function createuser(Request $request){
        $this->validate($request, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'role' => ['required', 'string'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            ]);
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'role' => $request->role,
            'password' => Hash::make($request->password),
            ]);
            \Session::flash('flash_message','User Created');
            return redirect()->route('users');
        }
    public function edituser($id){
        $page="users";
        $user=User::findOrFail($id);
        return view('hospital.users.edit',compact("page",'user'));
    }
    public function updateuser($id,Request $request){
        $this->validate($request, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email,'.$id],
            'role' => ['required', 'string'],
        ]);
        User::whereId($id)->update([
            'name' => $request->name,
            'email' => $request->email,
            'role' => $request->role,
            'password' => Hash::make($request->password),
        ]);
        if(!is_null($request->password)){
            $this->validate($request, [
                'password' => ['required', 'string', 'min:6', 'confirmed'],
            ]);
            User::whereId($id)->update([
                'password' => Hash::make($request->password),
            ]);
        }
        \Session::flash('flash_message','User details updated');
        return redirect()->route('users');
    }
    public function deleteusers(Request $request){
        User::whereIn("id",$request->id)->update([
            'email'=>'DEL_'.date('Y_m_d_H_i_s')
        ]);
        User::whereIn("id",$request->id)->delete();
        // Patient::whereIn("id",$request->id)->delete();
        \Session::flash('flash_message',"User(s) deleted");

    }
    
}
