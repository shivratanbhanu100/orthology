<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use App\Patient;
use App\PatientSrs22;
use App\PatientPerforma;
use App\Srs22Question;
use App\Srs22Option;
use App\Charts\PieChart;
use Carbon\Carbon;

class UnitadminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkrole:scoliosisadmin,orthoadmin,superadmin,4,5,6,7,8');
    }
    public function properredirect(){
        // if(userRole('scoliosisadmin')) {
        //     return redirect()->route('orthodash');
        //     // return redirect()->route('scoliodash');
        //   }
        // if(userRole('orthoadmin')) {
        // }
        return redirect()->route('orthodash');
    }
    public function dashboard()
    {
        $page="scoliosisdashboard";
        //gender chart
        $sexwiselogs = Patient::selectRaw("sex,count(*) as total")->where('scoliosis',1)->groupBy('sex')
            ->get();
            $sexdata=[];
        foreach($sexwiselogs as $log){
            $sexdata[$log->sex]=$log->total;
        }
        $sexfinaldata = collect($sexdata);
        $chartsex = new PieChart;
        $chartsex->labels($sexfinaldata->keys());
        $chartsex->dataset('Sex', 'pie', $sexfinaldata->values())->color(['#036cb5','#fbaf3a',"#000000"]);
        //Age group
        $agewiselogs = Patient::selectRaw("age,count(*) as total")->where('scoliosis',1)->groupBy('age')
            ->get();
            $agedata=[];
        foreach($agewiselogs as $log){
            $agedata[$log->age]=$log->total;
        }
        $agefinaldata = collect($agedata);
        $chartage = new PieChart;
        $chartage->labels($agefinaldata->keys());
        $chartage->dataset('Age', 'bar', $agefinaldata->values())->color('#036cb5');
        $startdate=date('Y-m-d', strtotime('-6 months', strtotime(date('Y-m-d'))));
        $enddate=date('Y-m-d');
        return view('hospital.dashboard.index',compact("page",'chartsex','chartage','startdate','enddate'));
    }
    public function dashboardfilter(Request $request)
    {
        $startdate=$request->startdate;
        $enddate=$request->enddate;
        
        return view('hospital.dashboard.dashboardmeans',compact('startdate','enddate'));
    }
    public function patientrecords()
    {
        $page="patientrecord";
        $patients=Patient::where('scoliosis',1)->get();
        return view('hospital.patientrecord.index',compact("page",'patients'));
        
    }
    public function newproforma($stage,$id)
    {
        $page="patientrecord";
        $patient=Patient::findOrFail($id);
        return view('hospital.patientrecord.newproforma',compact("page",'patient','stage')); 
    }
    public function addproforma(Request $request)
    {
        
        $patient_id=$request->patient_id;
        $stage=$request->stage;
        $date=date('Y-m-d',strtotime($request->date_of_proforma));
        PatientPerforma::create([
            "user_id"=>\Auth::user()->id,
            'patient_id'=>$request->patient_id,
            'stage'=>$request->stage,
            'date'=>$date,
            'scoliosis_type'=>$request->scoliosis_type,
            'skin'=>$request->skin,
            'shoulder_level_difference'=>$request->shoulder_level_difference,
            'rib_hump'=>$request->rib_hump,
            'arm_span'=>$request->arm_span,
            'sitting_height'=>$request->sitting_height,
            'limb_length'=>$request->limb_length,
            'motor_dtr'=>$request->motor_dtr,
            'sensory'=>$request->sensory,
            'autonomic'=>$request->autonomic,
            'associated_anomalies'=>$request->associated_anomalies,
            'lenke_classification'=>$request->lenke_classification,
            'winters_classification'=>$request->winters_classification,
            'failure_formation'=>$request->failure_formation,
            'failure_of_segmentation'=>$request->failure_of_segmentation,
            'apex'=>$request->apex,
            'apical_vertical_translation'=>$request->apical_vertical_translation,
            'apical_rotation'=>$request->apical_rotation,
            'upper_lower_end_vertebra'=>$request->upper_lower_end_vertebra,
            'cobb_angle'=>$request->cobb_angle,
            'bending_cobb'=>$request->bending_cobb,
            'secondary_apex'=>$request->secondary_apex,
            'secondary_apical_vertical_translation'=>$request->secondary_apical_vertical_translation,
            'secondary_apical_rotation'=>$request->secondary_apical_rotation,
            'secondary_upper_lower_end_vertebra'=>$request->secondary_upper_lower_end_vertebra,
            'secondary_cobb_angle'=>$request->secondary_cobb_angle,
            'secondary_bending_cobb'=>$request->secondary_bending_cobb,
            'trunk_shift'=>$request->trunk_shift,
            'thoracic_kyphosis'=>$request->thoracic_kyphosis,
            'lumbar_lordosis'=>$request->lumbar_lordosis,
            'sagittal_shift'=>$request->sagittal_shift,
            'pelvic_tilt'=>$request->pelvic_tilt,
            'pelvic_incidence'=>$request->pelvic_incidence,
            'sacral_slope'=>$request->sacral_slope,
            'radiographic_shoulder_height'=>$request->radiographic_shoulder_height,
            'psa'=>$request->psa,
            'post_operative_findings'=>$request->post_operative_findings,
            'screw_loosening_breakage'=>$request->screw_loosening_breakage,
            'mri_findings'=>implode(',', $request->mri_findings),
            'mri_findings_other'=>$request->mri_findings_other,
            'neurosurgical_procedure'=>$request->neurosurgical_procedure,
            'functional_score'=>$request->functional_score,
            'self_image'=>$request->self_image,
            'mental_health'=>$request->mental_health,
            'pain'=>$request->pain,
            'satisfaction_with_management'=>$request->satisfaction_with_management,
            'functional_mean'=>$request->functional_mean,
        ]);
        \Session::flash('flash_message',"Patient performa saved.");
        // if($request->dashboard==0){
        //     if($stage<4){
        //         $nextstage=$stage+1;
        //         return redirect("/srs22/new/".$nextstage."/".$patient_id);
        //     }
        //     else{
        //         return redirect()->route('scoliosispatients');
        //     }
        // }
        // else{
        // }
        if(userRole('orthoadmin')){
            return redirect()->route('logindex');
        }
        return redirect()->route('scoliosispatients');
         
    }
    public function newsrs($stage,$id)
    {
        $page="patientrecord";
        $patient=Patient::findOrFail($id);
        $srs=PatientSrs22::where("stage",$stage)->where("patient_id",$id)->exists();
        if($srs){
            return redirect("/srs22/edit/".$stage."/".$id);
        }
        $srsquestions=Srs22Question::all();
        // dd($srsquestions);
        return view('hospital.patientrecord.newsrs',compact("page",'patient','srsquestions','stage')); 
    }
    public function addsrs(Request $request)
    {
        $page="patientrecord";
        // dd($request->all());
        $patient_id=$request->patient_id;
        $stage=$request->stage;
        $date=date('Y-m-d',strtotime($request->date_of_questionnaire));
        $srsquestions=Srs22Question::query()->get();
        foreach($srsquestions as $srs){
            $score=null;
            $option_id=$request->{'q'.$srs->id};
            if(!is_null($option_id)){
                $score=Srs22Option::find($option_id)->score;
            }
            PatientSrs22::create([
                'date'=>$date,
                "user_id"=>\Auth::user()->id,
                'stage'=>$stage,
                'patient_id'=>$patient_id,
                'question_category'=>$srs->question_category,
                'srs22_question_id'=>$srs->id,
                'srs22_option_id'=>$option_id,
                'score'=>$score
            ]);
        }
        // dd($srsquestions);
        \Session::flash('flash_message',"Patient SRS22r questionnaire saved.");
        if($request->dashboard==0){
            if($stage<4){
                $nextstage=$stage;
                return redirect("/proforma/new/".$nextstage."/".$patient_id);
            }
            else{
                if(userRole('orthoadmin')){
                    return redirect()->route('logindex');
                }
                return redirect()->route('scoliosispatients');
            }
        }
        else{
            if(userRole('orthoadmin')){
                return redirect()->route('logindex');
            }
            return redirect()->route('scoliosispatients');
        }
    }
    public function editproforma($stage,$patient_id)
    {   
        $page="patientrecord";
        $patient=Patient::findOrFail($patient_id);
        $srs=PatientSrs22::where("stage",$stage)->where("patient_id",$patient_id)->exists();
        if(!$srs){
            return redirect("/srs22/new/".$stage."/".$patient_id);
        }
        if(!$patient->proformaExist($stage)){
            return abort(404);
        }
        return view('hospital.patientrecord.editproforma',compact("page",'stage','patient')); 
    }
    public function updateproforma(Request $request)
    {   
        $patient_id=$request->patient_id;
        $stage=$request->stage;
        $date=date('Y-m-d',strtotime($request->date_of_proforma));
        PatientPerforma::where("patient_id",$patient_id)->where("stage",$stage)->update([
            "user_id"=>\Auth::user()->id,
            'date'=>$date,
            'scoliosis_type'=>$request->scoliosis_type,
            'skin'=>$request->skin,
            'shoulder_level_difference'=>$request->shoulder_level_difference,
            'rib_hump'=>$request->rib_hump,
            'arm_span'=>$request->arm_span,
            'sitting_height'=>$request->sitting_height,
            'limb_length'=>$request->limb_length,
            'motor_dtr'=>$request->motor_dtr,
            'sensory'=>$request->sensory,
            'autonomic'=>$request->autonomic,
            'associated_anomalies'=>$request->associated_anomalies,
            'lenke_classification'=>$request->lenke_classification,
            'winters_classification'=>$request->winters_classification,
            'failure_formation'=>$request->failure_formation,
            'failure_of_segmentation'=>$request->failure_of_segmentation,
            'apex'=>$request->apex,
            'apical_vertical_translation'=>$request->apical_vertical_translation,
            'apical_rotation'=>$request->apical_rotation,
            'upper_lower_end_vertebra'=>$request->upper_lower_end_vertebra,
            'cobb_angle'=>$request->cobb_angle,
            'bending_cobb'=>$request->bending_cobb,
            'secondary_apex'=>$request->secondary_apex,
            'secondary_apical_vertical_translation'=>$request->secondary_apical_vertical_translation,
            'secondary_apical_rotation'=>$request->secondary_apical_rotation,
            'secondary_upper_lower_end_vertebra'=>$request->secondary_upper_lower_end_vertebra,
            'secondary_cobb_angle'=>$request->secondary_cobb_angle,
            'secondary_bending_cobb'=>$request->secondary_bending_cobb,
            'trunk_shift'=>$request->trunk_shift,
            'thoracic_kyphosis'=>$request->thoracic_kyphosis,
            'lumbar_lordosis'=>$request->lumbar_lordosis,
            'sagittal_shift'=>$request->sagittal_shift,
            'pelvic_tilt'=>$request->pelvic_tilt,
            'pelvic_incidence'=>$request->pelvic_incidence,
            'sacral_slope'=>$request->sacral_slope,
            'radiographic_shoulder_height'=>$request->radiographic_shoulder_height,
            'psa'=>$request->psa,
            'post_operative_findings'=>$request->post_operative_findings,
            'screw_loosening_breakage'=>$request->screw_loosening_breakage,
            'mri_findings'=>implode(',', $request->mri_findings),
            'mri_findings_other'=>$request->mri_findings_other,
            'neurosurgical_procedure'=>$request->neurosurgical_procedure,
            'functional_score'=>$request->functional_score,
            'self_image'=>$request->self_image,
            'mental_health'=>$request->mental_health,
            'pain'=>$request->pain,
            'satisfaction_with_management'=>$request->satisfaction_with_management,
            'functional_mean'=>$request->functional_mean,
        ]);
        \Session::flash('flash_message',"Patient proforma details updated.");
        if($request->dashboard==0){
            return back();
        }
        else{
            if(userRole('orthoadmin')){
                return redirect()->route('logindex');
            }
            return redirect()->route('scoliosispatients');
        }
    }
    public function editsrs($stage,$patient_id)
    {
        $page="patientrecord";
        $patient=Patient::findOrFail($patient_id);
        $srs=PatientSrs22::where("stage",$stage)->where("patient_id",$patient_id)->exists();
        if(!$srs){
            abort(404);
        }
        $srsquestions=Srs22Question::query()->get();
        return view('hospital.patientrecord.editsrs',compact("page","patient","stage",'srsquestions')); 
    }
    public function newpatient()
    {
        $page="patientrecord";
        return view('hospital.patientrecord.newpatient',compact("page")); 
    }
    public function addpatient(Request $request)
    {
        $page="patientrecord";
        $dob=null;
        if(Patient::where("uhid",$request->uhid)->exists()){
            if(!is_null($request->dob_date) && !is_null($request->dob_month) && !is_null($request->dob_year)){
                $dob=$request->dob_year.'-'.$request->dob_month.'-'.$request->dob_date;
            }
            Patient::where("uhid",$request->uhid)->update([
                'user_id'=>\Auth::user()->id,
                'name'=>$request->patient_name,
                'age'=>$request->age,
                'sex'=>$request->sex,
                'dob'=>$dob,
                'diagnosis'=>$request->diagnosis,
                'scoliosis'=>1,
            ]);
            if($request->dashboard!=0){
                \Session::flash('flash_message',"Patient details updated.");
                if(userRole('orthoadmin')){
                    return redirect()->route('logindex');
                }
                return redirect()->route('scoliosispatients');
            }
            $patient=Patient::where("uhid",$request->uhid)->first();
            //check stage 1 start
            \Session::flash('flash_message',"Patient details updated. Redirected to unfilled form.");
            if(!$patient->srsExist(1)){
                return redirect("/srs22/new/1/".$patient->id);
            }
            else{
                if(!$patient->proformaExist(1)){
                    return redirect("/proforma/new/1/".$patient->id);
                }
                else{//check stage 2 start
                    if(!$patient->srsExist(2)){
                        return redirect("/srs22/new/2/".$patient->id);
                    }
                    else{
                        if(!$patient->proformaExist(2)){
                            return redirect("/proforma/new/2/".$patient->id);
                        }
                        else{//check stage 3 start
                            if(!$patient->srsExist(3)){
                                return redirect("/srs22/new/3/".$patient->id);
                            }
                            else{
                                if(!$patient->proformaExist(3)){
                                    return redirect("/proforma/new/3/".$patient->id);
                                }
                                else{//check stage 4 start
                                    if(!$patient->srsExist(4)){
                                        return redirect("/srs22/new/4/".$patient->id);
                                    }
                                    else{
                                        if(!$patient->proformaExist(4)){
                                            return redirect("/proforma/new/4/".$patient->id);
                                        }
                                        else{//Redirect after final stage start
                                            if(userRole('orthoadmin')){
                                                return redirect()->route('logindex');
                                            }
                                            return redirect()->route('scoliosispatients');
                                        }//Redirect after final stage end
                                    }
                                }//check stage 4 end
                            }
                        }//check stage 3 end
                    }
                }//check stage 2 end
            }
            //check for stage 1 end
            
        }
        else{
            if(!is_null($request->dob_date) && !is_null($request->dob_month) && !is_null($request->dob_year)){
                $dob=$request->dob_year.'-'.$request->dob_month.'-'.$request->dob_date;
            }
            $id=Patient::create([
                'user_id'=>\Auth::user()->id,
                'name'=>$request->patient_name,
                'age'=>$request->age,
                'sex'=>$request->sex,
                'uhid'=>$request->uhid,
                'dob'=>$dob,
                'diagnosis'=>$request->diagnosis,
                'scoliosis'=>1,
            ])->id;
            if($request->dashboard==0){
                \Session::flash('flash_message',"Patient details saved. Please fill the SRS22r questionnaire below.");
                return redirect("/srs22/new/1/".$id);
            }
            else{
                \Session::flash('flash_message',"Patient details saved.");
                if(userRole('orthoadmin')){
                    return redirect()->route('logindex');
                }
                return redirect()->route('scoliosispatients');
            }
        }
    }
    public function deletepatientrecord(Request $request){
        PatientPerforma::whereIn("patient_id",$request->id)->delete();
        PatientSrs22::whereIn("patient_id",$request->id)->delete();
        // Patient::whereIn("id",$request->id)->delete();
        \Session::flash('flash_message',"Patient data deleted");

    }
    public function checkuniqueuhid(Request $request)
    {
        $uhid=$request->uhid;
        $patient=Patient::where("uhid",$uhid)->exists(); 
        if($patient){
            $patientdetail=Patient::where("uhid",$uhid)->first();
            return [0,$patientdetail];
        }
        return [1];
    }
    public function viewrecord($id)
    {
        $page="patientrecord";
        $patient=Patient::findOrFail($id);
        return view('hospital.patientrecord.viewrecord',compact("page","patient")); 
    }
}
