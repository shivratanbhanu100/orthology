<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OswestryQuestion extends Model
{
    protected $guarded=[];
    public function options(){
        return $this->hasMany(OswestryOption::class)->orderBy('sequence');
    }
}
