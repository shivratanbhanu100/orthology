<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientSrs22 extends Model
{
    protected $guarded=[];
    protected $dates=['date'];

    public function patient(){
        return $this->belongsTo(Patient::class,'patient_id');
    }
    public function question(){
        return $this->belongsTo(Srs22Question::class,'srs22_question_id');
    }
    public function option(){
        return $this->belongsTo(Srs22Option::class,'srs22_option_id')->withDefault();
    }
    public function user(){
        return $this->belongsTo(User::class,'user_id')->withTrashed()->withDefault();
    }
}
