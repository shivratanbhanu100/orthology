## Usage
- To get SSI/hais type template in bootstrap 4
- npm is required
- run `composer install`
- run `npm install && npm run dev`
- run `cp .env.example .env && php artisan key:generate`
